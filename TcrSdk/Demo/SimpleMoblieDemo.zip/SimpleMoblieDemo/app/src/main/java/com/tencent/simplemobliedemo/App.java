package com.tencent.simplemobliedemo;

import android.app.Application;
import android.util.Log;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.TcrSdk;

/**
 * 应用程序
 */
public class App extends Application {

    private static final String TAG = "App";

    @Override
    public void onCreate() {
        super.onCreate();

        // 初始化和业务后台交互的类
        CloudRenderBiz.getInstance().init(this);

        // 初始化云游sdk
        TcrSdk.getInstance().init(this, null, new AsyncCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                Log.i(TAG, "init SDK success");
            }

            @Override
            public void onFailure(int code, String msg) {
                Log.e(TAG, "init SDK failed:" + code + " msg:" + msg);
            }
        });
    }
}

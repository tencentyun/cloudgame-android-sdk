package com.tencent.simplemobliedemo.server.gson;

import com.google.gson.annotations.SerializedName;

public class StartResponse extends Response {

    @SerializedName("SessionDescribe")
    public SessionDescribe sessionDescribe;

    public static class SessionDescribe {

        @SerializedName("ServerSession")
        public String serverSession;

        @Override
        public String toString() {
            return "SessionDescribe{"
                    + "serverSession='"
                    + serverSession + '\''
                    + '}';
        }
    }

}

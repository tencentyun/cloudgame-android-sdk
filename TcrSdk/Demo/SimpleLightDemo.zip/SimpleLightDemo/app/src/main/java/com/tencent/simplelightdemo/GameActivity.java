package com.tencent.simplelightdemo;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import com.google.gson.Gson;
import com.tencent.simplelightdemo.server.CloudGameApi;
import com.tencent.simplelightdemo.server.gson.GameStartResponse;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.PcTouchHandler;
import com.tencent.tcr.sdk.api.TcrRenderView;
import com.tencent.tcr.sdk.api.TcrRenderViewType;
import com.tencent.tcr.sdk.api.TcrSdk;
import com.tencent.tcr.sdk.api.TcrSession;
import com.tencent.tcr.sdk.api.TcrSessionListener;
import com.tencent.tcr.sdk.api.config.TcrSessionConfig;


/**
 * 该类演示了如何初始化TcrSdk，创建会话、初始化会话、启动端手游，并将云游画面展示到界面上的基础流程。<br>
 *
 * <p>
 * 要使用TcrSdk，你需要先调用{@link TcrSdk#init(Context, String, AsyncCallback)}接口初始化TcrSdk,<br>
 * 在{@link AsyncCallback#onSuccess(Object)} 回调以后才能做进一步操作，例如创建{@link TcrSession}以及{@link TcrRenderView}。
 * </p>
 *
 * 在创建出{@link TcrSession}之后便可以开始初始化会话，并和云端实例进行交互。<br>
 * 具体的流程如下:
 *
 * <pre>
 * {@code
 *     ┌──────────────┐  ┌────────────┐ ┌────────────┐  ┌───────────┐
 *     │ GameActivity │  │ TcrSession │ │ App Server │  │ Cloud Api │
 *     └──────┬───────┘  └──────┬─────┘ └──────┬─────┘  └─────┬─────┘
 *            │      init()     │              │              │
 *            ├────────────────►│              │              │
 *            │                 ├─────┐        │              │
 *            │                 │     │        │              │
 *            │   onSuccess()   │◄────┘        │              │
 *            │◄────────────────┤              │              │
 *            │                 │              │              │
 *            │    startGame(clientSession)    │              │
 *            ├─────────────────┬─────────────►│              │
 *            │                 │              │   tryLock    │
 *            │                 │              ├─────────────►│
 *            │                 │              │              │
 *            │                 │              │createSession │
 *            │                 │              ├─────────────►│
 *            │                 │              │              │
 *            │    onSuccess(serverSession)    │              │
 *            │◄────────────────┬──────────────┤              │
 *            │                 │              │              │
 *            │      start()    │              │              │
 *            ├────────────────►│              │              │tai
 *            │                 │              │              │
 *                SDK调用流程                       后台交互流程
 * }
 * </pre>
 *
 * <p>
 * 1.调用{@link TcrSession#init(AsyncCallback)}初始化会话，在回调中获取到{@code clientSession}。<br>
 * 2.调用业务后台接口, 将{@code clientSession}传递给云端实例，并获取{@code serverSession}。<br>
 * 3.拿到{@code serverSession}之后，调用{@link TcrSession#start(String, AsyncCallback)}启动会话。<br>
 * 4.当会话启动成功之后用户便可以和云端实例进行交互。<br>
 * </p>
 *
 *
 * <p>
 * 详细的TcrSdk接口如何使用，请参考文档<br>
 *
 * @see <a href="https://tencentyun.github.io/cloudgame-android-sdk/tcrsdk/index.html">TcrSdK API</a>
 *         </p>
 */
public class GameActivity extends Activity {

    private static final String TAG = "GameActivity";

    /**
     * 会话启动回调。<br>
     *
     * 当会话启动成功时会回调{@link AsyncCallback#onSuccess(Object)}, 只有在该回调发生后您才可与云端进行交互。<br>
     *
     * 当会话启动失败时会回调{@link AsyncCallback#onFailure(int, String)}}, 通常是因为{@link TcrSession#start(String,
     * AsyncCallback)}中传入的{@code serverSession}错误导致。<br>
     * 初次对接您需要检查{@code serverSession} 是否符合预期。
     */
    private final AsyncCallback<Void> mStartSessionCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            // 从该回调发生以后客户端才可与云端进行交互。
            Log.i(TAG, "start session success..");
        }

        @Override
        public void onFailure(int code, String msg) {
            Log.e(TAG, "start session failure, code:" + code + "  msg:" + msg);
        }
    };

    /**
     * 渲染视图
     */
    private TcrRenderView mRenderView;

    /**
     * 云渲染会话
     */
    private TcrSession mTcrSession;

    /**
     * 初始化会话回调。<br>
     *
     * 初始化成功时触发{@link AsyncCallback#onSuccess(Object)}回调, 返回的结果是用于服务端请求的ClientSession。<br>
     *
     * 初始化失败时触发{@link AsyncCallback#onFailure(int, String)}回调，此时无法使用SDK。
     */
    private final AsyncCallback<String> mInitSessionCallback = new AsyncCallback<String>() {
        @Override
        public void onSuccess(String clientSession) {
            Log.i(TAG, "init session success, clientSession:" + clientSession);

            // 会话初始化成功后拿到clientSession， 请求后台启动游戏并获取ServerSession
            CloudGameApi.getInstance().startGame(clientSession, response -> {
                Log.i(TAG, "start game success: " + response);
                // 用从服务端获取到的server session启动会话
                GameStartResponse result = new Gson().fromJson(response.toString(), GameStartResponse.class);
                if (result.code == 0) {
                    mTcrSession.start(result.sessionDescribe.serverSession, mStartSessionCallback);
                }
            }, error -> Log.e(TAG, "start game failed:" + error));
        }

        @Override
        public void onFailure(int code, String msg) {
            Log.e(TAG, "onFailure code:" + code + " msg:" + msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initWindow();
        setContentView(R.layout.activity_pcgame);
        initTcr();
    }

    private void initWindow() {
        // 不显示标题栏
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 全屏展示
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // 屏幕常亮
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /**
     * 初始化云游相关逻辑，包括TcrSession和TcrRenderView
     */
    private void initTcr() {
        // 为TcrSession创建配置参数对象。参考https://tencentyun.github.io/cloudgame-android-sdk/tcrsdk/com/tencent/tcr/sdk/api/config/TcrSessionConfig.Builder.html
        TcrSessionConfig tcrSessionConfig = TcrSessionConfig.builder().connectTimeout(25000).idleThreshold(30)
                .enableAudioTrack(true).build();
        // 创建会话对象
        mTcrSession = TcrSdk.getInstance().createTcrSession(tcrSessionConfig);
        if (mTcrSession == null) {
            Log.e(TAG, "initTcr() mTcrSession null");
            return;
        }
        // 初始化会话
        mTcrSession.init(mInitSessionCallback);
        // 监听该会话触发的事件
        mTcrSession.setListener(new TcrSessionListener() {
            @Override
            public void onError(int errorCode, String errorMsg) {
                Log.e(TAG, "initTcr() onError() code:" + errorCode + " msg:" + errorMsg);
            }

            @Override
            public void onEvent(String event, String data) {
            }
        });

        // 创建渲染视图
        mRenderView = TcrSdk.getInstance()
                .createTcrRenderView(GameActivity.this, mTcrSession, TcrRenderViewType.SURFACE);
        if (mRenderView == null) {
            Log.e(TAG, "initTcr() mRenderView null");
            return;
        }
        // 给渲染视图设置触摸处理对象, PCTouchHandler会将视图上的触摸事件透传给云端
        PcTouchHandler mPcTouchHandler = new PcTouchHandler();
        mRenderView.setOnTouchListener(mPcTouchHandler);
        // 将渲染视图添加到界面上
        ((FrameLayout) GameActivity.this.findViewById(R.id.main)).addView(mRenderView);

        // 为会话设置渲染视图
        mTcrSession.setRenderView(mRenderView);
    }

}
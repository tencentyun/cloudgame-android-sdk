package com.tencent.simplelightdemo.server.gson;

import com.google.gson.annotations.SerializedName;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

/**
 * 请求业务后台的公共参数
 */
public class Request {

    public static final String SOLT = "DLaB%$bfAc!@ds";
    @SerializedName("RequestId")
    public String requestId;
    @SerializedName("UserId")
    public String userId;
    @SerializedName("TimeStamp")
    public long timeStamp;

    public Request(String userId) {
        this.userId = userId;
        this.requestId = UUID.randomUUID().toString();
        this.timeStamp = System.currentTimeMillis();
    }

    /**
     * 使用SHA256对文本内容{@code input}进行加密。
     */
    protected static String getSHA256(String input) {
        MessageDigest messageDigest;
        String encodestr = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(input.getBytes(StandardCharsets.UTF_8));
            encodestr = byte2Hex(messageDigest.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return encodestr;
    }

    /**
     * 将字节流转为16进制字符
     */
    private static String byte2Hex(byte[] input) {
        StringBuilder stringBuilder = new StringBuilder();
        String temp;
        for (byte b : input) {
            temp = Integer.toHexString(b & 0xFF);
            if (temp.length() == 1) {
                stringBuilder.append("0");
            }
            stringBuilder.append(temp);
        }
        return stringBuilder.toString();
    }

    @Override
    public String toString() {
        return "Request{" +
                "requestId='" + requestId + '\'' +
                ", userId='" + userId + '\'' +
                ", timeStamp=" + timeStamp +
                '}';
    }
}

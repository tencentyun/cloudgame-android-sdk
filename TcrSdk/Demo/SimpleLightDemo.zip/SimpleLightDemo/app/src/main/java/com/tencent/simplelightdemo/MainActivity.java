package com.tencent.simplelightdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.TcrSdk;
import java.io.File;

/**
 * 该类作为APP入口。演示了如何通过网络下载云游SDK插件和初始化SDK。
 */
public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";
    // 插件文件
    private File mPluginFile;
    // 初始化SDK按钮
    private Button mInitButton;
    // 启动云游按钮
    private Button mStartButton;
    // 加载过程信息显示框
    private TextView mMessageTextView;
    // 是否需要下载插件
    private boolean mNeedDownload = false;
    /**
     * 初始化SDK回调
     */
    private final AsyncCallback<Void> mInitSdkCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            Log.i(TAG, "init SDK success");
            MainActivity.this.runOnUiThread(() -> {
                mInitButton.setEnabled(false);
                mStartButton.setEnabled(true);
                mMessageTextView.append("初始化SDK成功，您可以点击按钮进入云游。\n");
            });
        }

        @Override
        public void onFailure(int code, String msg) {
            // 插件校验失败，需重新下载
            if (code == 1) {
                MainActivity.this.runOnUiThread(() -> {
                    mNeedDownload = true;
                    mMessageTextView.append("初始化SDK失败: 插件校验失败。请点击按钮重新下载。\n");
                });
            }
            Log.e(TAG, "init SDK failed:" + code + " msg:" + msg);
        }
    };
    // 插件downloadManager
    private DownloadManager mDownloadManager;
    /**
     * 下载状态广播接收器，下载成功后初始化SDK
     */
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            Cursor cursor = mDownloadManager.query(new Query().setFilterById(id));
            if (cursor.moveToFirst()) {
                @SuppressLint("Range")
                int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    Log.i(TAG, "download plugin successful");
                    mMessageTextView.append("插件下载成功，开始初始化SDK\n");
                    mNeedDownload = false;
                    TcrSdk.getInstance().init(getApplicationContext(), mPluginFile.getAbsolutePath(), mInitSdkCallback);
                }
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 初始化UI组件
        mInitButton = this.findViewById(R.id.initSDK);
        mInitButton.setOnClickListener(v -> {
            // 下载插件并初始化云游SDK
            initSDKPlugin();
        });
        mStartButton = this.findViewById(R.id.startGame);
        mStartButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RenderActivity.class);
            startActivity(intent);
        });
        mMessageTextView = this.findViewById(R.id.message_show);

        // 初始化插件文件
        mPluginFile = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "plugin");
        // 注册广播接收器
        registerReceiver(mReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        // 初始化和业务后台交互的类
        CloudRenderBiz.getInstance().init(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
    }

    /**
     * 下载SDK插件，下载完成后初始化SDK
     */
    private void initSDKPlugin() {
        if (mPluginFile.exists() && !mNeedDownload) {
            mMessageTextView.append("插件已存在,开始初始化SDK\n");
            TcrSdk.getInstance().init(getApplicationContext(), mPluginFile.getAbsolutePath(), mInitSdkCallback);
        } else {
            mMessageTextView.append("下载插件中...\n");
            if (!downLoadPlugin()) {
                mMessageTextView.append("插件下载失败，downloadManager初始化失败\n");
            }
        }
    }

    /**
     * 下载插件
     */
    private boolean downLoadPlugin() {
        String downloadUrl = TcrSdk.getPluginUrl();
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        request.setDestinationUri(Uri.fromFile(mPluginFile));
        // 初始化DownloadManager
        mDownloadManager = (DownloadManager) this.getSystemService(Context.DOWNLOAD_SERVICE);
        if (mDownloadManager == null) {
            Log.e(TAG, "cannot get DownloadManger");
            return false;
        }
        Log.i(TAG, "download:" + downloadUrl);
        mDownloadManager.enqueue(request);
        return true;
    }

}

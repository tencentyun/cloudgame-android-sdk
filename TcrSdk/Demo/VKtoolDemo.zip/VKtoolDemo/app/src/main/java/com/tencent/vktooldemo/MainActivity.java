package com.tencent.vktooldemo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.TcrSdk;
import com.tencent.tcr.sdk.api.TcrSession;
import com.tencent.tcr.sdk.api.TcrSession.Observer;
import com.tencent.tcr.sdk.api.TcrSessionConfig;
import com.tencent.tcr.sdk.api.data.CursorState;
import com.tencent.tcr.sdk.api.data.ScreenConfig;
import com.tencent.tcr.sdk.api.data.StatsInfo;
import com.tencent.tcr.sdk.api.view.MobileTouchListener;
import com.tencent.tcr.sdk.api.view.PcClickListener;
import com.tencent.tcr.sdk.api.view.PcTouchListener;
import com.tencent.tcr.sdk.api.view.TcrRenderView;
import com.tencent.tcr.sdk.api.view.TcrRenderView.TcrRenderViewType;
import com.tencent.tcr.sdk.api.view.TcrRenderView.VideoRotation;
import com.tencent.tcrgamepad.GamepadManager;
import com.tencent.tcrgui.keyboard.KeyboardView;
import com.tencent.vktooldemo.data.StartGameResponse;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;


/**
 * 该类演示了如何初始化TcrSdk，创建会话、请求远端会话、启动云应用，并将云应用画面展示到界面上的基础流程。<br>
 *
 * <p>
 * 要使用TcrSdk，你需要先调用{@link TcrSdk#init(Context, String, AsyncCallback)}接口初始化TcrSdk,<br>
 * 在{@link AsyncCallback#onSuccess(Object)} 回调以后才能做进一步操作，例如创建{@link TcrSession}以及{@link TcrRenderView}。
 * </p>
 *
 * 在启动会话{@link TcrSession#start(String)}后才可以与云端实例进行交互。<br>
 * 具体的流程如下:
 *
 * <pre>
 * {@code
 *     ┌──────────────┐  ┌────────────┐ ┌────────────┐  ┌───────────┐
 *     │ MainActivity │  │ TcrSession │ │ App Server │  │ Cloud Api │
 *     └──────┬───────┘  └──────┬─────┘ └──────┬─────┘  └─────┬─────┘
 *            │ setObserver()   │              │              │
 *            ├────────────────►│              │              │
 *            │                 ├─────┐        │              │
 *            │                 │     │        │              │
 *            │   Event.INITED  │◄────┘        │              │
 *            │◄────────────────┤              │              │
 *            │                 │              │              │
 *            │    startGame(clientSession)    │              │
 *            ├─────────────────┬─────────────►│              │
 *            │                 │              │   tryLock    │
 *            │                 │              ├─────────────►│
 *            │                 │              │              │
 *            │                 │              │createSession │
 *            │                 │              ├─────────────►│
 *            │                 │              │              │
 *            │    onSuccess(serverSession)    │              │
 *            │◄────────────────┬──────────────┤              │
 *            │                 │              │              │
 *            │      start()    │              │              │
 *            ├────────────────►│              │              │
 *            │                 │              │              │
 *                SDK调用流程                       后台交互流程
 * }
 * </pre>
 *
 * <p>
 * 1.调用{@link TcrSdk#init(Context, String, AsyncCallback)}初始化SDK，初始化成功后创建TcrSession,
 * 并通过{@link TcrSessionConfig.Builder#observer(Observer)}将Observer设置好，通过Observer的回调拿到TcrSession对外的通知<br>
 * 2.通过Observer的回调得到TcrSession初始化成功{@link TcrSession.Event#STATE_INITED}的事件后，将事件传递的数据解析为clientSession<br>
 * 3.调用业务后台接口, 将{@code clientSession}传递给云端实例，并获取{@code serverSession}。<br>
 * 4.拿到{@code serverSession}之后，调用{@link TcrSession#start(String)}启动会话。<br>
 * 5.当会话启动成功之后用户便可以和云端实例进行交互。<br>
 * </p>
 *
 *
 * <p>
 * 详细的TcrSdk接口如何使用，请参考文档<br>
 * 业务后台的搭建，请参考链接<br>
 * @see <a href="https://tencentyun.github.io/cloudgame-android-sdk/tcrsdk/index.html">TcrSdK API</a>
 * @see <a href="https://github.com/tencentyun/gs-server-demo">搭建业务后台</a></p>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private final int MOBILE_GAME = 1;
    private final int PC_GAME = 2;
    private final DecimalFormat mDf = new DecimalFormat("#.##");
    /**
     * 渲染视图
     */
    private TcrRenderView mRenderView;
    /**
     * 云渲染会话
     */
    private TcrSession mTcrSession;
    /**
     * 虚拟按键入口
     */
    private GamepadManager mGamePadManager;
    /**
     * 虚拟按键配置json文件
     */
    private String mCustomGamePadCfg;
    /**
     * 性能数据视图
     */
    private TextView mStatsValueTextView;
    // 键盘视图的父容器
    private RelativeLayout mKeyboardParent;
    // 键盘视图
    private KeyboardView mKeyboardView;
    // Button选择列
    LinearLayout mButtonList;
    // 虚拟键盘视图的显示状态：true显示、false隐藏
    private boolean keyboardShowing = false;
    // 虚拟按键视图的显示状态：true显示、false隐藏
    private boolean gamePadShowing = false;
    // 虚拟按键视图的编辑状态：true编辑态、false非编辑态
    private boolean gamePadEditShowing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initWindow();
        setContentView(R.layout.activity_main);
        mStatsValueTextView = findViewById(R.id.stats_value);
        initTcr();
        initButtonList();
        initGamePad();
        initKeyboard();
    }

    private void initWindow() {
        // 不显示标题栏
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 全屏展示
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // 屏幕常亮
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /**
     * 初始化云游相关逻辑，包括TcrSession和TcrRenderView
     */
    private void initTcr() {
        // 初始化TcrSdk，初始化成功后创建TcrSession
        TcrSdk.getInstance().init(this, null, new AsyncCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                Log.i(TAG, "init SDK success");
                showToast("sdk 初始化成功", Toast.LENGTH_SHORT);
                // 为TcrSession创建配置参数对象。参考https://tencentyun.github.io/cloudgame-android-sdk/tcrsdk/com/tencent/tcr/sdk/api/config/TcrSessionConfig.Builder.html
                TcrSessionConfig tcrSessionConfig = TcrSessionConfig.builder()
                        .observer(mSessionEventObserver)
                        .connectTimeout(25000)
                        .idleThreshold(30)
                        .build();
                // 创建会话对象
                mTcrSession = TcrSdk.getInstance().createTcrSession(tcrSessionConfig);
                if (mTcrSession == null) {
                    Log.e(TAG, "mTcrSession = null");
                    showToast("创建TcrSession失败，请查看日志", Toast.LENGTH_SHORT);
                    return;
                }
                // 创建和初始化渲染视图
                runOnUiThread(() -> initTcrRenderView());
            }

            @Override
            public void onFailure(int code, String msg) {
                String errorMsg = "init SDK failed:" + code + " msg:" + msg;
                Log.e(TAG, errorMsg);
                showToast(errorMsg, Toast.LENGTH_LONG);
            }
        });
    }

    /**
     * 初始化渲染视图
     */
    private void initTcrRenderView() {
        // 创建渲染视图
        mRenderView = TcrSdk.getInstance()
                .createTcrRenderView(MainActivity.this, mTcrSession, TcrRenderViewType.SURFACE);
        mTcrSession.setRenderView(mRenderView);
        if (mRenderView == null) {
            Log.e(TAG, "mRenderView = null");
            showToast("创建TcrRenderView失败,请查看日志", Toast.LENGTH_SHORT);
            return;
        }
        // 为会话设置渲染视图
        mTcrSession.setRenderView(mRenderView);
        // 将渲染视图添加到界面上
        ((FrameLayout) MainActivity.this.findViewById(R.id.render_view_parent)).addView(mRenderView);

    }

    /**
     * 初始化设置选择列表,包括两个按钮，分别用于打开关闭虚拟键盘和自定义虚拟按键
     */
    private void initButtonList() {
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        mButtonList = new LinearLayout(this);
        mButtonList.setLayoutParams(lp);
        mButtonList.setOrientation(LinearLayout.VERTICAL);
        // 切换虚拟按键视图的编辑状态的按钮
        Button mGamePadEditButton = new Button(this);
        mGamePadEditButton.setText("编辑虚拟按键");
        mGamePadEditButton.setBackgroundColor(100);
        mGamePadEditButton.setLayoutParams(lp);
        mGamePadEditButton.setOnClickListener(view -> switchEditStatus(!gamePadEditShowing));
        // 切换虚拟按键显示状态的按钮
        Button mGamePadButton = new Button(this);
        mGamePadButton.setText("虚拟按键");
        mGamePadButton.setBackgroundColor(100);
        mGamePadButton.setLayoutParams(lp);
        mGamePadButton.setOnClickListener(view -> showCustomGamePad(!gamePadShowing));
        // 切换虚拟键盘显示状态的按钮
        Button mKeyboardButton = new Button(this);
        mKeyboardButton.setText("虚拟键盘");
        mKeyboardButton.setBackgroundColor(100);
        mKeyboardButton.setLayoutParams(lp);
        mKeyboardButton.setOnClickListener(view -> showKeyboard(!keyboardShowing));
        mButtonList.addView(mGamePadEditButton);
        mButtonList.addView(mGamePadButton);
        mButtonList.addView(mKeyboardButton);
        // 添加到游戏视图上
        mRenderView.addView(mButtonList);
    }

    /**
     * 初始化虚拟键盘
     */
    private void initKeyboard() {
        mKeyboardParent = new RelativeLayout(this);
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        addContentView(mKeyboardParent,lp);
        mKeyboardView = new KeyboardView(this);
        RelativeLayout.LayoutParams kbLp = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        kbLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        mKeyboardView.setLayoutParams(kbLp);
        mKeyboardParent.addView(mKeyboardView);
        mKeyboardParent.setVisibility(View.INVISIBLE);
    }

    /**
     * 初始化自定义编辑虚拟按键视图
     */
    private void initGamePad() {
        mGamePadManager = new GamepadManager(this);
        mGamePadManager.setEditListener((isChanged, newCfg) -> {
            if (isChanged) {
                mCustomGamePadCfg = newCfg;
            }
            switchEditStatus(false);
        });
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        addContentView(mGamePadManager, lp);
        mCustomGamePadCfg = readConfigFile(this, "lol_5v5.cfg");
    }

    /**
     * 切换虚拟按键视图的编辑状态
     *
     * @param enable true，编辑态 false，非编辑态
     */
    private void switchEditStatus(boolean enable) {
        if (!gamePadShowing) {
            return;
        }
        if (enable) {
            mGamePadManager.editGamepad(mCustomGamePadCfg);
            mButtonList.setVisibility(View.GONE);
        } else {
            mButtonList.setVisibility(View.VISIBLE);
            mGamePadManager.showGamepad(mCustomGamePadCfg); // 退出编辑态后加载布局
        }
        gamePadEditShowing = enable;
    }

    /**
     * 切换虚拟按键视图的显示状态
     *
     * @param enable true，显示 false，隐藏
     */
    private void showCustomGamePad(boolean enable) {
        if (enable) {
            mKeyboardParent.setVisibility(View.GONE);
            keyboardShowing = false;
            mGamePadManager.setVisibility(View.VISIBLE);
            mGamePadManager.showGamepad(mCustomGamePadCfg);
        } else {
            mGamePadManager.setVisibility(View.GONE);
        }
        gamePadShowing = enable;
    }

    /**
     * 切换虚拟键盘视图的显示状态
     *
     * @param enable true，显示 false，隐藏
     */
    private void showKeyboard(boolean enable) {
        if (enable) {
            mGamePadManager.setVisibility(View.GONE);
            gamePadShowing = false;
            mKeyboardParent.setVisibility(View.VISIBLE);
            mKeyboardView.resetKeyboard();
            // 展开输入法时重置云端大小写
            mTcrSession.getKeyboard().resetKeyboardCapsLock();
        } else {
            mKeyboardParent.setVisibility(View.GONE);
        }
        keyboardShowing = enable;
    }

    /**
     * 读取配置文件
     *
     * @param fileName 文件名
     * @return 返回String类型JsonConfig内容
     */
    private static String readConfigFile(Context context,String fileName) {
        try {
            AssetManager am = context.getAssets();
            InputStream is = am.open(fileName);
            InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
            char[] input = new char[is.available()];
            isr.read(input);
            isr.close();
            is.close();
            return new String(input);
        } catch (Exception e) {
            Log.e(TAG, "readConfigFile failed:" + e);
        }
        return null;
    }

    /**
     * 通过http请求业务后台并获取ServerSession，拿到ServerSession后启动会话<br>
     * 如果您需要启动云应用请调用CloudRenderBiz.getInstance().startProject
     */
    private void requestServerSession(String clientSession) {
        Log.i(TAG, "init session success:" + clientSession);

        CloudRenderBiz.getInstance().startGame(clientSession, response -> {
            Log.i(TAG, "Request ServerSession success, response=" + response.toString());
            // 用从服务端获取到的server session启动会话
            StartGameResponse result = new Gson().fromJson(response.toString(), StartGameResponse.class);
            if (result.code == 0) {
                boolean res = mTcrSession.start(result.sessionDescribe.serverSession);
                if (!res) {
                    Log.e(TAG, "start session failed");
                    showToast("连接失败，请查看日志", Toast.LENGTH_SHORT);
                }
                showToast("连接成功", Toast.LENGTH_SHORT);
            } else {
                String showMessage = "";
                switch (result.code) {
                    case 10000:
                        showMessage = "sign校验错误";
                        break;
                    case 10001:
                        showMessage = "缺少必要参数";
                        break;
                    case 10200:
                        showMessage = "创建会话失败";
                        break;
                    case 10202:
                        showMessage = "锁定并发失败，无资源";
                        break;
                    default:
                }
                showToast(showMessage + result.msg, Toast.LENGTH_LONG);
            }
        }, error -> Log.i(TAG, "Request ServerSession success, response=" + error.toString()));
    }

    /**
     * 观察TcrSession通知出的各类事件，处理各类事件通知的消息和数据
     *
     * @see TcrSession.Event
     */
    private final TcrSession.Observer mSessionEventObserver = new TcrSession.Observer() {
        @Override
        public void onEvent(TcrSession.Event event, Object eventData) {
            switch (event) {
                case STATE_INITED:
                    // 回调数据中拿到client session并请求ServerSession
                    String clientSession = (String) eventData;
                    requestServerSession(clientSession);
                    break;
                case STATE_CONNECTED:
                    // 连接成功后设置操作模式
                    // 与云端的交互需在此事件回调后开始调用接口
                    runOnUiThread(() -> setTouchHandler(mTcrSession, mRenderView, PC_GAME));
                    break;
                case STATE_RECONNECTING:
                    showToast("重连中...", Toast.LENGTH_LONG);
                    break;
                case STATE_CLOSED:
                    showToast("会话关闭", Toast.LENGTH_SHORT);
                    finish();
                    break;
                case SCREEN_CONFIG_CHANGE:
                    ScreenConfig screenConfig = (ScreenConfig) eventData;
                    if (screenConfig == null) {
                        Log.e(TAG, "screenConfig parse error");
                        break;
                    }
                    updateRotation(screenConfig);
                    updateOrientation(screenConfig);
                    break;
                case CLIENT_STATS:
                    StatsInfo statsInfo = (StatsInfo) eventData;
                    runOnUiThread(new Runnable() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void run() {
                            mStatsValueTextView.setText(
                                    "   fps: " + statsInfo.fps + "   bitrate: " + mDf.format(
                                            statsInfo.bitrate / 1024.0 / 1024.0)
                                            + "Mb/s   rtt: " + statsInfo.rtt + "ms");
                        }
                    });
                    break;
                case CURSOR_STATE_CHANGE:
                    CursorState cursorState = (CursorState) eventData;
                    Log.i(TAG, "cursor showing state changed, " + cursorState.toString());
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * 旋转屏幕方向, 以便本地的屏幕方向和云端保持一致<br>
     * 注意: 请确保Manifest中的Activity有android:configChanges="orientation|screenSize"配置, 避免Activity因旋转而被销毁.<br>
     *
     * @param config 云端的屏幕配置
     */
    @SuppressLint("SourceLockedOrientationActivity")
    private void updateOrientation(ScreenConfig config) {
        Log.i(TAG, "updateOrientation:" + config.orientation);
        if (config.orientation.equals("portrait")) {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if (config.orientation.equals("landscape")) {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
    }

    /**
     * 根据云端屏幕配置旋转视频画面
     */
    private void updateRotation(ScreenConfig config) {
        if (config.videoWidth > config.videoHeight) {
            if (config.orientation.equals("portrait")) {
                mRenderView.setVideoRotation(VideoRotation.ROTATION_90);
            }
        } else {
            if (config.orientation.equals("landscape")) {
                mRenderView.setVideoRotation(VideoRotation.ROTATION_270);
            }
        }
    }

    /**
     * 为不同的云端实例设置处理器
     * <p>
     * 对于云端PC应用可以使用{@link PcTouchListener}
     * (云端PC应用在支持windows多点触摸时可使用{@link MobileTouchListener})
     * </p>
     * 对于手游要使用{@link MobileTouchListener}
     */
    private void setTouchHandler(TcrSession session, TcrRenderView renderView, int gameType) {
        switch (gameType) {
            case MOBILE_GAME:
                renderView.setOnTouchListener(new MobileTouchListener(session));
                break;
            case PC_GAME:
                PcTouchListener pcTouchListener = new PcTouchListener(session);
                pcTouchListener.getZoomHandler().setZoomRatio(1f, 5f);
                renderView.setOnTouchListener(pcTouchListener);

                pcTouchListener.setShortClickListener(new PcClickListener(session));
                break;
            default:
                Log.e(TAG, "UNKNOWN DeviceMode!!");
        }
    }

    private void showToast(String msg, int duration) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, duration).show());
    }
}
package com.tencent.vktooldemo;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.PcTouchHandler;
import com.tencent.tcr.sdk.api.TcrRenderView;
import com.tencent.tcr.sdk.api.TcrRenderViewType;
import com.tencent.tcr.sdk.api.TcrSdk;
import com.tencent.tcr.sdk.api.TcrSession;
import com.tencent.tcr.sdk.api.TcrSessionListener;
import com.tencent.tcr.sdk.api.config.TcrSessionConfig;
import com.tencent.tcrgamepad.GamepadManager;
import com.tencent.tcrgui.keyboard.KeyboardView;
import com.tencent.vktooldemo.server.CloudGameApi;
import com.tencent.vktooldemo.server.gson.StartResponse;
import java.io.InputStream;
import java.io.InputStreamReader;


/**
 * 该类演示了如何初始化TcrSdk，创建会话、初始化会话、启动云手游，并将云游画面展示到界面上的基础流程。<br>
 *
 * <p>
 * 要使用TcrSdk，你需要先调用{@link TcrSdk#init(Context, String, AsyncCallback)}接口初始化TcrSdk,<br>
 * 在{@link AsyncCallback#onSuccess(Object)} 回调以后才能做进一步操作，例如创建{@link TcrSession}以及{@link TcrRenderView}。
 * </p>
 *
 * 在创建出{@link TcrSession}之后便可以开始初始化会话，并和云端实例进行交互。<br>
 * 具体的流程如下:
 *
 * <pre>
 * {@code
 *     ┌──────────────┐  ┌────────────┐ ┌────────────┐  ┌───────────┐
 *     │ GameActivity │  │ TcrSession │ │ App Server │  │ Cloud Api │
 *     └──────┬───────┘  └──────┬─────┘ └──────┬─────┘  └─────┬─────┘
 *            │      init()     │              │              │
 *            ├────────────────►│              │              │
 *            │                 ├─────┐        │              │
 *            │                 │     │        │              │
 *            │   onSuccess()   │◄────┘        │              │
 *            │◄────────────────┤              │              │
 *            │                 │              │              │
 *            │    startGame(clientSession)    │              │
 *            ├─────────────────┬─────────────►│              │
 *            │                 │              │   tryLock    │
 *            │                 │              ├─────────────►│
 *            │                 │              │              │
 *            │                 │              │createSession │
 *            │                 │              ├─────────────►│
 *            │                 │              │              │
 *            │    onSuccess(serverSession)    │              │
 *            │◄────────────────┬──────────────┤              │
 *            │                 │              │              │
 *            │      start()    │              │              │
 *            ├────────────────►│              │              │
 *            │                 │              │              │
 *                SDK调用流程                       后台交互流程
 * }
 * </pre>
 *
 * <p>
 * 1.调用{@link TcrSession#init(AsyncCallback)}初始化会话，在回调中获取到{@code clientSession}。<br>
 * 2.调用业务后台接口, 将{@code clientSession}传递给云端实例，并获取{@code serverSession}。<br>
 * 3.拿到{@code serverSession}之后，调用{@link TcrSession#start(String, AsyncCallback)}启动会话。<br>
 * 4.当会话启动成功之后用户便可以和云端实例进行交互。<br>
 * </p>
 *
 *
 * <p>
 * 详细的TcrSdk接口如何使用，请参考文档<br>
 *
 * @see <a href="https://tencentyun.github.io/cloudgame-android-sdk/tcrsdk/index.html">TcrSdK API</a>
 *         </p>
 */
public class GameActivity extends AppCompatActivity {

    private static final String TAG = "GameActivity";

    /**
     * 会话启动回调。<br>
     *
     * 当会话启动成功时会回调{@link AsyncCallback#onSuccess(Object)}, 只有在该回调发生后您才可与云端进行交互。<br>
     *
     * 当会话启动失败时会回调{@link AsyncCallback#onFailure(int, String)}}, 通常是因为{@link TcrSession#start(String,
     * AsyncCallback)}中传入的{@code serverSession}错误导致。<br>
     * 初次对接您需要检查{@code serverSession} 是否符合预期。
     */
    private final AsyncCallback<Void> mStartSessionCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            // 从该回调发生以后客户端才可与云端进行交互。
            Log.i(TAG, "start session success..");
        }

        @Override
        public void onFailure(int code, String msg) {
            Log.e(TAG, "start session failure, code:" + code + "  msg:" + msg);
        }
    };
    /**
     * 渲染视图
     */
    private TcrRenderView mRenderView;
    /**
     * 云渲染会话
     */
    private TcrSession mTcrSession;
    /**
     * 虚拟按键入口
     */
    private GamepadManager mGamePadManager;
    /**
     * 虚拟按键配置json文件
     */
    private String mCustomGamePadCfg;
    // 键盘视图的父容器
    private RelativeLayout mKeyboardParent;
    // 键盘视图
    private KeyboardView mKeyboardView;
    // Button选择列
    LinearLayout mButtonList;
    // 切换虚拟键盘显示状态的按钮
    private Button mKeyboardButton;
    // 虚拟键盘视图的显示状态：true显示、false隐藏
    private boolean keyboardShowing = false;
    // 切换虚拟按键显示状态的按钮
    private Button mGamePadButton;
    // 虚拟按键视图的显示状态：true显示、false隐藏
    private boolean gamePadShowing = false;
    // 切换虚拟按键视图的编辑状态的按钮
    private Button mGamePadEditButton;
    // 虚拟按键视图的编辑状态：true编辑态、false非编辑态
    private boolean gamePadEditShowing = false;

    /**
     * 初始化会话回调。<br>
     *
     * 初始化成功时触发{@link AsyncCallback#onSuccess(Object)}回调, 返回的结果是用于服务端请求的ClientSession。<br>
     *
     * 初始化失败时触发{@link AsyncCallback#onFailure(int, String)}回调，此时无法使用SDK。
     */
    private final AsyncCallback<String> mInitSessionCallback = new AsyncCallback<String>() {
        @Override
        public void onSuccess(String clientSession) {
            Log.i(TAG, "init session success, clientSession:" + clientSession);

            // 会话初始化成功后拿到clientSession， 请求后台启动游戏并获取ServerSession
            CloudGameApi.getInstance().startGame(clientSession, response -> {
                Log.i(TAG, "start game success: " + response);

                // 会话初始化成功后拿到clientSession， 请求后台启动游戏或启动应用并获取ServerSession
                // 如果您需要启动云应用请调用startCAR
                StartResponse result = new Gson().fromJson(response.toString(), StartResponse.class);
                if (result.code == 0) {
                    mTcrSession.start(result.sessionDescribe.serverSession, mStartSessionCallback);
                } else {
                    String showMessage = "";
                    switch (result.code) {
                        case 10300:
                            showMessage = "创建会话失败";
                            break;
                        case 10302:
                            showMessage = "锁定并发失败，无资源 ";
                            break;
                        case 10303:
                            showMessage = "游戏启动中 ";
                            break;
                        default:
                    }
                    Toast.makeText(getApplicationContext(), showMessage + result.msg, Toast.LENGTH_LONG).show();
                }
            }, error -> Log.e(TAG, "start game failed:" + error));
        }

        @Override
        public void onFailure(int code, String msg) {
            Log.e(TAG, "onFailure code:" + code + " msg:" + msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initWindow();
        setContentView(R.layout.activity_pcgame);
        initTcr();
        initButtonList();
        initGamePad();
        initKeyboard();
    }

    private void initWindow() {
        // 不显示标题栏
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 全屏展示
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // 屏幕常亮
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /**
     * 初始化云游相关逻辑，包括TcrSession和TcrRenderView
     */
    private void initTcr() {
        // 为TcrSession创建配置参数对象。参考https://tencentyun.github.io/cloudgame-android-sdk/tcrsdk/com/tencent/tcr/sdk/api/config/TcrSessionConfig.Builder.html
        TcrSessionConfig tcrSessionConfig = TcrSessionConfig.builder().connectTimeout(25000).idleThreshold(30)
                .enableAudioTrack(true).build();
        // 创建会话对象
        mTcrSession = TcrSdk.getInstance().createTcrSession(tcrSessionConfig);
        if (mTcrSession == null) {
            Log.e(TAG, "initTcr() mTcrSession null");
            return;
        }
        // 初始化会话
        mTcrSession.init(mInitSessionCallback);
        // 监听该会话触发的事件
        mTcrSession.setListener(new TcrSessionListener() {
            @Override
            public void onError(int errorCode, String errorMsg) {
                Log.e(TAG, "initTcr() onError() code:" + errorCode + " msg:" + errorMsg);
            }

            @Override
            public void onEvent(String event, String data) {
            }
        });

        // 创建渲染视图
        mRenderView = TcrSdk.getInstance()
                .createTcrRenderView(GameActivity.this, mTcrSession, TcrRenderViewType.SURFACE);
        if (mRenderView == null) {
            Log.e(TAG, "initTcr() mRenderView null");
            return;
        }
        // 给渲染视图设置触摸处理对象, PCTouchHandler会将视图上的触摸事件透传给云端
        mRenderView.setOnTouchListener(new PcTouchHandler());
        // 将渲染视图添加到界面上
         ((FrameLayout) GameActivity.this.findViewById(R.id.main)).addView(mRenderView);
        // 为会话设置渲染视图
        mTcrSession.setRenderView(mRenderView);
    }

    /**
     * 初始化设置选择列表,包括两个按钮，分别用于打开关闭虚拟键盘和自定义虚拟按键
     */
    private void initButtonList() {
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
        mButtonList = new LinearLayout(this);
        mButtonList.setLayoutParams(lp);
        mButtonList.setOrientation(LinearLayout.VERTICAL);
        mGamePadEditButton = new Button(this);
        mGamePadEditButton.setText("编辑虚拟按键");
        mGamePadEditButton.setBackgroundColor(100);
        mGamePadEditButton.setLayoutParams(lp);
        mGamePadEditButton.setOnClickListener(view -> switchEditStatus(!gamePadEditShowing));
        mGamePadButton = new Button(this);
        mGamePadButton.setText("虚拟按键");
        mGamePadButton.setBackgroundColor(100);
        mGamePadButton.setLayoutParams(lp);
        mGamePadButton.setOnClickListener(view -> showCustomGamePad(!gamePadShowing));
        mKeyboardButton = new Button(this);
        mKeyboardButton.setText("虚拟键盘");
        mKeyboardButton.setBackgroundColor(100);
        mKeyboardButton.setLayoutParams(lp);
        mKeyboardButton.setOnClickListener(view -> showKeyboard(!keyboardShowing));
        mButtonList.addView(mGamePadEditButton);
        mButtonList.addView(mGamePadButton);
        mButtonList.addView(mKeyboardButton);
        // 添加到游戏视图上
        mRenderView.addView(mButtonList);
    }

    /**
     * 初始化虚拟键盘
     */
    private void initKeyboard() {
        mKeyboardParent = new RelativeLayout(this);
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        addContentView(mKeyboardParent,lp);
        mKeyboardView = new KeyboardView(this);
        RelativeLayout.LayoutParams kbLp = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        kbLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        mKeyboardView.setLayoutParams(kbLp);
        mKeyboardParent.addView(mKeyboardView);
        mKeyboardParent.setVisibility(View.INVISIBLE);
    }

    /**
     * 初始化自定义编辑虚拟按键视图
     */
    private void initGamePad() {
        mGamePadManager = new GamepadManager(this);
        mGamePadManager.setEditListener((isChanged, newCfg) -> {
            if (isChanged) {
                mCustomGamePadCfg = newCfg;
            }
            switchEditStatus(false);
        });
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        addContentView(mGamePadManager, lp);
        mCustomGamePadCfg = readConfigFile(this, "lol_5v5.cfg");
    }

    /**
     * 切换虚拟按键视图的编辑状态
     *
     * @param enable true，编辑态 false，非编辑态
     */
    private void switchEditStatus(boolean enable) {
        if (!gamePadShowing) {
            return;
        }
        if (enable) {
            mGamePadManager.editGamepad(mCustomGamePadCfg);
            mButtonList.setVisibility(View.GONE);
        } else {
            mButtonList.setVisibility(View.VISIBLE);
            mGamePadManager.showGamepad(mCustomGamePadCfg); // 退出编辑态后加载布局
        }
        gamePadEditShowing = enable;
    }

    /**
     * 切换虚拟按键视图的显示状态
     *
     * @param enable true，显示 false，隐藏
     */
    private void showCustomGamePad(boolean enable) {
        if (enable) {
            mKeyboardParent.setVisibility(View.GONE);
            keyboardShowing = false;
            mGamePadManager.setVisibility(View.VISIBLE);
            mGamePadManager.showGamepad(mCustomGamePadCfg);
        } else {
            mGamePadManager.setVisibility(View.GONE);
        }
        gamePadShowing = enable;
    }

    /**
     * 切换虚拟键盘视图的显示状态
     *
     * @param enable true，显示 false，隐藏
     */
    private void showKeyboard(boolean enable) {
        if (enable) {
            mGamePadManager.setVisibility(View.GONE);
            gamePadShowing = false;
            mKeyboardParent.setVisibility(View.VISIBLE);
            mKeyboardView.resetKeyboard();
            // 展开输入法时重置云端大小写
            TcrSdk.getInstance().getCurrentSession().getKeyBoard().resetCapsLock();
        } else {
            mKeyboardParent.setVisibility(View.GONE);
        }
        keyboardShowing = enable;
    }

    /**
     * 读取配置文件
     *
     * @param fileName 文件名
     * @return 返回String类型JsonConfig内容
     */
    private static String readConfigFile(Context context,String fileName) {
        try {
            AssetManager am = context.getAssets();
            InputStream is = am.open(fileName);
            InputStreamReader isr = new InputStreamReader(is, "utf-8");
            char input[] = new char[is.available()];
            isr.read(input);
            isr.close();
            is.close();
            return new String(input);
        } catch (Exception e) {
            Log.e(TAG, "readConfigFile failed:" + e);
        }
        return null;
    }

}
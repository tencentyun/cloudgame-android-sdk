package com.tencent.advancedemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button RenderButton = findViewById(R.id.button2);
        RenderButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CustomRenderActivity.class);
            startActivity(intent);
        });
        Button DecodeButton = findViewById(R.id.button);
        DecodeButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MediaCodecActivity.class);
            startActivity(intent);
        });
    }

}

package com.tencent.tcr.micro;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.tencent.bugly.crashreport.CrashReport;
import com.tencent.tcr.micro.sdk.MicroContext;
import com.tencent.tcr.micro.sdk.biz.MicroCloudGameBiz;
import com.tencent.tcr.micro.sdk.biz.MicroCloudGameBiz.MicroCloudGameListener;
import com.tencent.tcr.micro.sdk.biz.MicroHotUpdateBiz;
import com.tencent.tcr.micro.sdk.biz.MicroHotUpdateBiz.MicroHotUpdateListener;
import com.tencent.tcr.micro.sdk.constant.MicroConstant;
import com.tencent.tcr.micro.sdk.constant.ResponseCode;
import com.tencent.tcr.micro.sdk.utils.FileUtils;
import com.tencent.tcr.micro.sdk.utils.MicroUtils;
import com.tencent.tcr.micro.sdk.utils.SharedPreferenceUtils;
import com.tencent.tcr.micro.sdk.view.MicroCloudGameViewHelper;
import com.tencent.tcr.micro.ui.MicroCustomDialog;
import com.tencent.tcr.micro.ui.MicroCustomDialog.DialogClickListener;
import com.tencent.tcr.micro.ui.MicroFullDownloadSpeedDialog;
import com.tencent.tcr.micro.ui.MicroLoadingView;
import com.tencent.tcr.micro.ui.MicroProgressFloatView;
import com.tencent.tcr.micro.ui.R;

/**
 * 该Activity需要微端App继承，实现云试玩、静默下载、热更新等功能。
 * 同时，该类中有微端的各种状态，客户可以根据需要调整界面显示的逻辑。
 */
public abstract class MicroBaseActivity extends Activity {

    private static final String TAG = "MicroBaseActivity";

    private static boolean sBuglyInited;

    // 打开本地文件浏览器的请求码
    private static final int REQUEST_CODE = 1001;

    // 生命周期状态
    private int mLifeStatus;

    // 是否开始全速下载
    private boolean isFullSpeedDownload;

    // UI部分
    private ConstraintLayout mContainer;
    private MicroCloudGameViewHelper mCloudGameViewHelper;
    // 悬浮球
    private MicroProgressFloatView mProgressFloatWindow;
    // 游戏加载界面
    private MicroLoadingView mMicroLoadingView;
    //重启弹窗
    private MicroCustomDialog mRestartDialog;
    // 安装弹窗
    private MicroCustomDialog mInstallDialog;
    // 全速下载弹窗
    private MicroFullDownloadSpeedDialog mFullSpeedDownloadDialog;
    // 热更新错误弹窗
    private MicroCustomDialog mHotUpdateErrorDialog;
    // 选择本地调试文件弹窗
    private MicroCustomDialog mPickUpLocalDebugFileDialog;
    // 网络无连接弹窗
    private MicroCustomDialog mNetworkErrorDialog;
    // 云游戏错误弹窗
    private MicroCustomDialog mCloudGameErrorDialog;

    private final MicroCloudGameListener mMicroCloudGameListener = new MicroCloudGameListener() {
        // 云游戏状态回调
        // 云游sdk开始初始化
        @Override
        public void onInitSdkStart() {
            Log.i(TAG, "onInitSdkStart: ");
            mMicroLoadingView.setGameLoadingProgress(20);
            mMicroLoadingView.setGameLoadingText("正在加载游戏");
        }

        // 云游sdk初始化成功
        @Override
        public void onSdkInitSuccess() {
            Log.i(TAG, "onSdkInitSuccess: ");
            runOnUiThread(this::onSdkInitSuccessInner);
        }

        private void onSdkInitSuccessInner() {
            mMicroLoadingView.setGameLoadingProgress(40);
            mCloudGameViewHelper = new MicroCloudGameViewHelper(MicroBaseActivity.this);
            View gameView = mCloudGameViewHelper.getGameView();
            mContainer.addView(gameView);
            gameView.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (gameView.getViewTreeObserver().isAlive()) {
                        // 防止多次触发，触发之后将监听移除
                        gameView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        String resolution = gameView.getMeasuredWidth() + "x" + gameView.getMeasuredHeight();
                        Log.i(TAG, "gameView resolution=" + resolution);
                        MicroCloudGameBiz.getInstance().setResolution(resolution);
                        // 这里设置Resolution之后才开始排队，是因为排队成功后startCloudGame()需要有Resolution信息。
                        // 并行执行的话需要处理同步等待很麻烦，所以我们设计为串行执行。
                        MicroCloudGameBiz.getInstance().startEnqueue();
                    }
                }
            });
        }

        // 云游sdk初始化失败
        @Override
        public void onSdkInitFailure(int errorCode) {
            Log.e(TAG, "onSdkInitFailure: " + errorCode);
            runOnUiThread(() -> {
                if (mLifeStatus >= 1 && mLifeStatus <= 3) {
                    showCloudGameErrorDialog(String.valueOf(errorCode));
                }
            });
        }

        // 排队中
        @Override
        public void onQueuing(int index) {
            mMicroLoadingView.setGameLoadingText("正在排队，前方还有" + index + "人，请耐心等待");
        }

        // 排队成功
        @Override
        public void onEnqueueSuccess() {
            Log.i(TAG, "onEnqueueSuccess: ");
            updateFloatWindowStatus();
            mMicroLoadingView.setGameLoadingText("排队成功，正在启动游戏");
        }

        // 排队失败
        @Override
        public void onEnqueueFailed(String errorType) {
            Log.e(TAG, "onEnqueueFailed: " + errorType);
            if (mLifeStatus >= 1 && mLifeStatus <= 3) {
                showCloudGameErrorDialog(String.valueOf(errorType));
            }
        }

        // 云游戏session返回成功
        @Override
        public void onStartGameSuccess() {
            Log.i(TAG, "onStartGameSuccess: ");
            mMicroLoadingView.setGameLoadingProgress(60);
        }

        // 云游戏启动失败
        @Override
        public void onStartGameFailed(String errorType) {
            Log.e(TAG, "onStartGameFailed: " + errorType);
            if (mLifeStatus >= 1 && mLifeStatus <= 3) {
                showCloudGameErrorDialog(errorType);
            }
        }

        // 云游戏连接失败
        @Override
        public void onSdkConnectionFailure(int errorCode) {
            Log.e(TAG, "onSdkConnectionFailure: " + errorCode);
            if (mLifeStatus >= 1 && mLifeStatus <= 3) {
                showCloudGameErrorDialog(String.valueOf(errorCode));
            }
        }

        // 云游戏连接成功
        @Override
        public void onSdkConnectionSuccess() {
            Log.i(TAG, "onSdkConnectionSuccess: ");
            mMicroLoadingView.setGameLoadingProgress(80);
        }

        // 云游戏首帧出现
        @Override
        public void onDrawFirstFrame() {
            Log.i(TAG, "onDrawFirstFrame: ");
            mMicroLoadingView.setGameLoadingProgress(100);
            mMicroLoadingView.setViewShow(false);
        }

        @SuppressLint("SourceLockedOrientationActivity")
        @Override
        public void onConfigurationChanged(String orientation, int width, int height) {
            Log.i(TAG, "onConfigurationChanged: o=" + orientation + " w=" + width + " h=" + height);

            // 和云端保持相同的屏幕方向, 不相同则强制旋转
            if ("portrait".equals(orientation)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
            mCloudGameViewHelper.updateRotation(orientation, width, height);
        }

        // 云游戏rtt和Fps信息变化
        @Override
        public void onCloudGameStatusChange(long rtt) {
            if (mProgressFloatWindow.isShowing()) {
                mProgressFloatWindow.setCloudGameInfo(rtt + "ms");
            }

            // 根据当前的云游戏rtt检测当前的网络情况，根据网络情况来设置最大的下载速度
            MicroHotUpdateBiz.getInstance().checkNetWorkCondition(isFullSpeedDownload, rtt);
        }

        // 微端和云端的数据通道连接成功
        @Override
        public void onDataChannelConnectSuccess() {
            Log.i(TAG, "onDataChannelConnectSuccess: ");
            MicroBaseActivity.this.onDataChannelConnectSuccess();
        }

        // 收到数据通道的消息
        @Override
        public void onReceiveCloudGameMessage(String data) {
            Log.i(TAG, "onReceiveCloudGameMessage: " + data);
            MicroBaseActivity.this.onReceiveCloudGameMessage(data);
        }

        // 由于游戏在后台放置时间过久导致云游实例被释放了，连接失败需要客户处理
        @Override
        public void onCloudGameStopped(String stopCode) {
            Log.i(TAG, "onCloudGameStoped: " + stopCode);
            // 游戏长时间未操作，云端实例被释放，会弹窗提示游戏出错了，用户体验不好。
            // 重连失败默认情况直接重新启动游戏，客户也可以根据自己需求进行弹窗提示。
            MicroUtils.restartGame(getApplicationContext());
        }

        // 准备释放云端游戏实例
        // 释放的时候需要等待云端返回释放结果，需要添加一个loading界面，防止等待时间太长卡住
        @Override
        public void onStopGameStart() {
            Log.i(TAG, "onStopGameStart: ");
            mMicroLoadingView.setGameLoadingText("正在释放云端游戏，请稍候～");
            mMicroLoadingView.setGameLoadingBackground(0);
            mMicroLoadingView.setProgressBarShow(false);
            mMicroLoadingView.setViewShow(true);
        }

        // 云端游戏停止成功，把loading界面隐藏
        @Override
        public void onStopGameSuccess() {
            Log.i(TAG, "onStopGameSuccess: ");
            mMicroLoadingView.setViewShow(false);
        }
    };

    private final MicroHotUpdateListener mMicroHotUpdateListener = new MicroHotUpdateListener() {

        // 开始下载补丁包
        @Override
        public void onDownloadStart() {
            Log.i(TAG, "onDownloadStart: ");
            if (isFullSpeedDownload) {
                // 点击了全速下载，就不限速
                MicroHotUpdateBiz.getInstance().setDownloadSpeed(0);
            }
        }

        // 下载状态

        /**
         * 下载中
         *
         * @param percent 当前下载百分比
         * @param downloadSize 已经下载的大小
         * @param fileSize 文件总大小
         */
        @Override
        public void onDownloadRunning(int percent, long downloadSize, long fileSize) {
            Log.i(TAG, "onDownloadRunning: percent=" + percent + ", downloadSize=" + downloadSize);
            // 更新全速下载弹窗
            if (mFullSpeedDownloadDialog.isShowing()) {
                mFullSpeedDownloadDialog.setDownload(downloadSize);
                mFullSpeedDownloadDialog.setTotal(fileSize);
                mFullSpeedDownloadDialog.setProgress(percent);
            }

            // 更新悬浮球
            if (mProgressFloatWindow.isShowing()) {
                mProgressFloatWindow.setProgress(percent);
                mProgressFloatWindow.setCurrentStatus(MicroHotUpdateBiz.getInstance().getCurrentStatus());
            }
        }

        // 下载成功
        @Override
        public void onDownloadSuccess() {
            Log.i(TAG, "onDownloadSuccess: ");
            if (isFullSpeedDownload) {
                // 恢复因全速下载而暂停的云游戏
                MicroCloudGameBiz.getInstance().resumeCloudGame();
            }

            if (mFullSpeedDownloadDialog.isShowing()) {
                mFullSpeedDownloadDialog.setProgress(100);
                mFullSpeedDownloadDialog.dismiss();
            }

            if (mProgressFloatWindow.isShowing()) {
                mProgressFloatWindow.setProgress(100);
                mProgressFloatWindow.setCurrentStatus(MicroHotUpdateBiz.getInstance().getCurrentStatus());
            }

            if (!MicroConstant.HOT_UPDATE) {
                showInstallDialog();
            }
        }

        // 下载失败
        @Override
        public void onDownloadFailed(Exception e) {
            Log.e(TAG, "onDownloadFailed: " + (e != null ? e.getMessage() : "UNKNOWN"));
            updateFloatWindowStatus();
        }

        // 本地调试时将补丁包从共享存储空间拷贝到应用自身存储空间成功
        @Override
        public void onCopyPatchSuccess() {
            updateFloatWindowStatus();
        }

        // 静默更新状态
        // 开始热更新
        @Override
        public void onApplyPatchStart() {
            Log.i(TAG, "onApplyPatchStart: ");
            updateFloatWindowStatus();
        }

        // 热更新加载成功
        @Override
        public void onPatchSuccess() {
            Log.i(TAG, "onPatchSuccess: ");
            updateFloatWindowStatus();

            // 弹出重启窗口
            if (mLifeStatus >= 1 && mLifeStatus <= 3) {
                showRestartDialog();
            }
        }

        // 热更新加载失败
        @Override
        public void onPatchFailed(String reason) {
            Log.e(TAG, "onPatchFailed: " + reason);
            updateFloatWindowStatus();
            if (mLifeStatus >= 1 && mLifeStatus <= 3 && !mRestartDialog.isShowing()) {
                showHotUpdateErrorDialog();
            }
        }

        // 覆盖安装模式下，开始安装apk
        @Override
        public void onInstallApkStart() {
            Log.i(TAG, "onInstallApkStart: ");
            updateFloatWindowStatus();
            MicroUtils.install(MicroBaseActivity.this, MicroContext.getInstance().getSavedUpdateFilePath());
        }
    };

    /**
     * 此方法可以将云端收到的数据传递给微端APP，需要微端APP重写
     *
     * @param data 云端回复的数据
     */
    protected abstract void onReceiveCloudGameMessage(String data);

    /**
     * 此方法通知微端APP数据通道连接成功，需要微端APP重写
     */
    protected abstract void onDataChannelConnectSuccess();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);
        // 初始化bugly
        // 4854991687该AppId是我们为微端工程申请的
        // 如果您想要观测微端工程的crash情况，您可以申请自己的AppId
        // 申请地址https://bugly.qq.com/v2/index
        // 申请之后替换为您的AppId
        // 应用启动后防止多次初始化bugly
        if (!sBuglyInited) {
            CrashReport.initCrashReport(getApplicationContext(), "4854991687", true);
            sBuglyInited = true;
        }
        initWindow();
        initView();
        init();
    }

    @Override
    protected void onRestart() {
        Log.i(TAG, "onRestart: ");
        super.onRestart();
        mLifeStatus = 2;
    }

    @Override
    protected void onResume() {
        Log.i(TAG, "onResume: ");
        super.onResume();
        mLifeStatus = 3;
        MicroCloudGameBiz.getInstance().resumeCloudGame();
    }

    @Override
    protected void onPause() {
        Log.i(TAG, "onPause: ");
        super.onPause();
        mLifeStatus = 4;
    }

    @Override
    protected void onStop() {
        Log.i(TAG, "onStop: ");
        super.onStop();
        mLifeStatus = 5;
        MicroCloudGameBiz.getInstance().pauseCloudGame();
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG, "onDestroy: ");
        super.onDestroy();
        mLifeStatus = 6;
        unregisterReceiver(mNetworkChangeReceiver);
        // 释放gameView
        if (mCloudGameViewHelper != null) {
            mCloudGameViewHelper.releaseGameView();
        }
    }

    @Override
    public void onBackPressed() {
        Log.i(TAG, "onBackPressed: ");
        MicroCloudGameBiz.getInstance().sendKeyToCloudGame(MicroConstant.KEY_BACK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult: " + requestCode);
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null || resultCode != Activity.RESULT_OK) {
            return;
        }

        if (requestCode == REQUEST_CODE) {
            // 需要将补丁包从共享存储空间拷贝到app目录
            MicroHotUpdateBiz.getInstance().copyPatchToSdcard(data.getData());
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            // 云游戏过程中把系统UI隐藏，保证全屏显示
            MicroUtils.hideSystemUi(this);
        }
    }

    private void initWindow() {
        Log.i(TAG, "initWindow: ");
        // 全屏展示
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private void init() {
        Log.i(TAG, "init: ");
        // initConfig时可以传入额外参数，参数为"test data for cloud game"，经过base64编码变为"dGVzdCBkYXRhIGZvciBjbG91ZCBnYW1l"
        // 参数的大小限制为Android中intent传输的数据最大值，不需要传递额外参数可以使用initConfig的单参数方法。
        MicroContext.getInstance().initConfig(MicroUtils.getVersionName(this), "dGVzdCBkYXRhIGZvciBjbG91ZCBnYW1l");

        // 注册云游戏的监听器
        MicroCloudGameBiz.getInstance().setMicroCloudGameListener(mMicroCloudGameListener);
        // 注册热更新的监听器
        MicroHotUpdateBiz.getInstance().setMicroHotUpdateListener(mMicroHotUpdateListener);

        // 初始化微端的Context
        MicroContext.getInstance().init(getApplicationContext());
        // 初始化云游戏业务逻辑模块
        MicroCloudGameBiz.getInstance().init(getApplicationContext());
        // 初始化热更新业务逻辑模块
        MicroHotUpdateBiz.getInstance().init(getApplicationContext());
        Log.d(TAG, "init: activity resolution=" + MicroUtils.getActivityResolution(this));

        // 展示启动界面
        showLoadingView();

        // 注册网络变化广播
        IntentFilter filter = new IntentFilter();
        // 监听网络的连接和断开
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(mNetworkChangeReceiver, filter);

        // 如果发现补丁包加载之后连续崩溃两次，就不再加载补丁，只进行云游戏
        // 有可能出现覆盖安装新的微端导致崩溃，所以第一次崩溃之后会尝试重新加载补丁包，只会重试一次
        if (SharedPreferenceUtils.get(this, MicroConstant.CRASH_TIME, 0) >= 2) {
            Log.e(TAG, "patch is not run success, don't need to download");
            if (mProgressFloatWindow != null && mProgressFloatWindow.isShowing()) {
                mProgressFloatWindow.dismiss();
            }
            return;
        }

        // 本地补丁包存在时加载本地补丁包，不存在则直接开始下载
        if (FileUtils.fileIsExists(MicroConstant.LOCAL_DEBUG_PATCH)) {
            showFilePickUpDialog();
        } else {
            // 当前下载时机处于Activity启动阶段，客户可以根据自己需要选择合适时机下载
            MicroHotUpdateBiz.getInstance().startDownload();
        }
    }

    private void initView() {
        Log.i(TAG, "initView: ");
        setContentView(R.layout.activity_micro_base);
        mLifeStatus = 1;
        mContainer = findViewById(R.id.micro_container);
        // 统一初始化微端的UI，客户可以根据需要修改改类的内容
        MicroUISettings.getInstance().init(this);
        // 展示悬浮球
        showFloatWindow();
    }

    /**
     * 设置悬浮窗界面
     *
     * @param floatWindow 悬浮窗{@link MicroProgressFloatView}
     */
    public void setProgressFloatWindow(@NonNull MicroProgressFloatView floatWindow) {
        Log.i(TAG, "setProgressFloatWindow: " + floatWindow);
        mProgressFloatWindow = floatWindow;
    }

    /**
     * 设置加载界面
     *
     * @param microLoadingView 加载界面{@link MicroLoadingView}
     */
    public void setLoadingView(@NonNull MicroLoadingView microLoadingView) {
        Log.i(TAG, "setLoadingView: " + microLoadingView);
        mMicroLoadingView = microLoadingView;
    }

    /**
     * 设置云游出错弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setCloudGameErrorDialog(@NonNull MicroCustomDialog dialog) {
        mCloudGameErrorDialog = dialog;
        mCloudGameErrorDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                MicroUtils.restartGame(getApplicationContext());
            }

            @Override
            public void onNegativeClick() {
                Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }

    /**
     * 设置网络出错弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setNetworkErrorDialog(@NonNull MicroCustomDialog dialog) {
        mNetworkErrorDialog = dialog;
        mNetworkErrorDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }

            @Override
            public void onNegativeClick() {
                mNetworkErrorDialog.dismiss();
            }
        });
    }

    /**
     * 设置本地调试弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setPickUpLocalDebugFileDialog(@NonNull MicroCustomDialog dialog) {
        mPickUpLocalDebugFileDialog = dialog;
        mPickUpLocalDebugFileDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                showFileSelectView();
            }

            @Override
            public void onNegativeClick() {
                mPickUpLocalDebugFileDialog.dismiss();
                // 点击取消加载本地补丁包，则去下载云端补丁包
                MicroHotUpdateBiz.getInstance().startDownload();
            }
        });
    }

    /**
     * 设置更新失败弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setHotUpdateErrorDialog(@NonNull MicroCustomDialog dialog) {
        mHotUpdateErrorDialog = dialog;
        mHotUpdateErrorDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                // 热更新失败了，去浏览器下载完整apk
                showFullApkDownloadView();
            }

            @Override
            public void onNegativeClick() {
                // 不想下载，就继续玩游戏
                mHotUpdateErrorDialog.dismiss();
            }
        });
    }

    /**
     * 设置安装提示弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setInstallDialog(@NonNull MicroCustomDialog dialog) {
        mInstallDialog = dialog;
        mInstallDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                MicroHotUpdateBiz.getInstance().installApk(1000);
            }

            @Override
            public void onNegativeClick() {
                MicroHotUpdateBiz.getInstance().installApk(5 * 60 * 1000);
            }
        });
    }

    /**
     * 设置重启弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setRestartDialog(@NonNull MicroCustomDialog dialog) {
        mRestartDialog = dialog;
        mRestartDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                MicroHotUpdateBiz.getInstance().restartApp(1000);
            }

            @Override
            public void onNegativeClick() {
                MicroHotUpdateBiz.getInstance().restartApp(5 * 60 * 1000);
            }
        });
    }

    /**
     * 设置全速下载弹窗
     *
     * @param dialog {@link MicroCustomDialog}
     */
    public void setFullSpeedDownloadDialog(@NonNull MicroFullDownloadSpeedDialog dialog) {
        mFullSpeedDownloadDialog = dialog;
        mFullSpeedDownloadDialog.setClickListener(() -> {
            mFullSpeedDownloadDialog.dismiss();
            isFullSpeedDownload = false;
            MicroCloudGameBiz.getInstance().resumeCloudGame();
            MicroHotUpdateBiz.getInstance().setDownloadSpeed(MicroConstant.DOWNLOAD_SPEED_LOW);
        });
    }

    /**
     * 显示加载界面
     */
    private void showLoadingView() {
        Log.d(TAG, "showLoadingView: ");
        if (mContainer != null) {
            mContainer.addView(mMicroLoadingView);
        }
    }

    /**
     * 显示悬浮球
     */
    private void showFloatWindow() {
        Log.i(TAG, "showFloatWindow: ");
        if (mProgressFloatWindow != null && !mProgressFloatWindow.isShowing()) {
            mProgressFloatWindow.setCurrentStatus(MicroHotUpdateBiz.getInstance().getCurrentStatus());
            mProgressFloatWindow.show();
        }
    }

    // 显示系统文件选择器
    @SuppressLint("ObsoleteSdkInt")
    private void showFileSelectView() {
        Log.d(TAG, "showFileSelectView: ");
        Intent intent;
        if (VERSION.SDK_INT >= VERSION_CODES.KITKAT) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        } else {
            intent = new Intent(Intent.ACTION_GET_CONTENT);
        }
        // 过滤器只显示可以打开的结果
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if (VERSION.SDK_INT >= VERSION_CODES.O) {
            Uri uri = Uri.parse(MicroConstant.DOWNLOAD_URI);
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri);
        }
        // 仅显示apk类型的文件
        intent.setType("application/vnd.android.package-archive");
        startActivityForResult(intent, REQUEST_CODE);
    }

    // 跳转到浏览器去下载
    private void showFullApkDownloadView() {
        if (TextUtils.isEmpty(MicroConstant.APK_URL)) {
            Log.i(TAG, "apk url is null, return");
            return;
        }
        Uri uri = Uri.parse(MicroConstant.APK_URL);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        // 能够找到处理该intent的Activity才进行跳转
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.e(TAG, "open " + MicroConstant.APK_URL + " error");
        }
    }

    // 弹出本地包选择提示框
    private void showFilePickUpDialog() {
        if (mPickUpLocalDebugFileDialog != null && !mPickUpLocalDebugFileDialog.isShowing()) {
            if (MicroHotUpdateBiz.getInstance().getCurrentStatus() == MicroConstant.APPLY_PATCH_START) {
                return;
            }
            Log.i(TAG, "showFilePickUpDialog: ");
            mPickUpLocalDebugFileDialog.show();
        }
    }

    /**
     * 显示网络断开弹窗
     */
    private void showNetWorkDisconnectedDialog() {
        dismissNetworkDialogIfNeed();
        dismissGameErrorDialogIfNeed();
        if (mNetworkErrorDialog != null && !mNetworkErrorDialog.isShowing()) {
            Log.i(TAG, "showNetWorkDisconnectedDialog");
            mNetworkErrorDialog.show();
        }
    }

    private void showCloudGameErrorDialog(String errorType) {
        dismissGameErrorDialogIfNeed();
        dismissNetworkDialogIfNeed();
        if (mCloudGameErrorDialog != null && !mCloudGameErrorDialog.isShowing()) {
            Log.i(TAG, "showCloudGameErrorDialog: ");
            mCloudGameErrorDialog.setMessage("游戏出错了(" + errorType
                    + ")\n" + (ResponseCode.ERROR_MAP.get(errorType) == null ? ""
                    : ResponseCode.ERROR_MAP.get(errorType)));
            mCloudGameErrorDialog.show();
        }
    }

    private void dismissNetworkDialogIfNeed() {
        if (mNetworkErrorDialog != null && mNetworkErrorDialog.isShowing()) {
            mNetworkErrorDialog.dismiss();
        }
    }

    private void dismissGameErrorDialogIfNeed() {
        if (mCloudGameErrorDialog != null && mCloudGameErrorDialog.isShowing()) {
            mCloudGameErrorDialog.dismiss();
        }
    }

    /**
     * 显示安装应用弹窗
     */
    public void showInstallDialog() {
        Log.i(TAG, "showInstallDialog: ");
        if (mInstallDialog != null && !mInstallDialog.isShowing()) {
            if (mProgressFloatWindow != null) {
                mProgressFloatWindow.dismissDialogIfNeed();
            }
            mInstallDialog.show();
        }
    }

    /**
     * 显示重启弹窗
     */
    public void showRestartDialog() {
        Log.i(TAG, "showRestartDialog: ");
        if (mRestartDialog != null && !mRestartDialog.isShowing()) {
            if (mProgressFloatWindow != null) {
                mProgressFloatWindow.dismissDialogIfNeed();
            }
            mRestartDialog.show();
        }
    }

    /**
     * 全速下载弹窗
     */
    public void showFullSpeedDownloadDialog() {
        int currentStatus = MicroHotUpdateBiz.getInstance().getCurrentStatus();
        if (currentStatus == MicroConstant.DOWNLOAD_SUCCESS) {
            Toast.makeText(this, "下载已完成", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentStatus == MicroConstant.DOWNLOAD_FAILED) {
            Toast.makeText(this, "下载出错了，请稍后再试～", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentStatus == MicroConstant.APPLY_PATCH_START) {
            Toast.makeText(this, "正在加载补丁包，请稍后～", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mFullSpeedDownloadDialog != null && !mFullSpeedDownloadDialog.isShowing()) {
            Log.i(TAG, "showFullDownloadDialog: ");
            MicroCloudGameBiz.getInstance().pauseCloudGame();
            isFullSpeedDownload = true;
            // 0就是下载速度无限制
            MicroHotUpdateBiz.getInstance().setDownloadSpeed(0);
            mFullSpeedDownloadDialog.show();

            MicroHotUpdateBiz.getInstance().reportFullSpeedDownload();
        }
    }

    /**
     * 显示热更新错误弹窗
     */
    public void showHotUpdateErrorDialog() {
        if (mHotUpdateErrorDialog != null && !mHotUpdateErrorDialog.isShowing()) {
            Log.i(TAG, "showHotUpdateErrorDialog: ");
            mHotUpdateErrorDialog.show();
        }
    }

    /**
     * 获取当前微端状态
     *
     * @return 当前状态
     */
    public int getCurrentStatus() {
        return MicroHotUpdateBiz.getInstance().getCurrentStatus();
    }

    /**
     * 改变当前码率
     *
     * @param bitrate 要设置的码率
     */
    public void changeBitrate(int bitrate) {
        MicroCloudGameBiz.getInstance().changeBitRate(bitrate);
    }

    /**
     * 通过数据通道发送数据到云游戏
     *
     * @param data 要发送的数据
     */
    public void sendDataToCloudGame(@NonNull String data) {
        if (MicroCloudGameBiz.getInstance().isDataChannelConnected()) {
            Log.i(TAG, "local send data to cloud:" + data);
            MicroCloudGameBiz.getInstance().sendDataToCloudGame(data);
        } else {
            Log.e(TAG, "data channel is not connected, send msg failed");
        }
    }

    // 其他方法
    // 根据当前的状态更改悬浮球的显示
    private void updateFloatWindowStatus() {
        if (mProgressFloatWindow.isShowing()) {
            mProgressFloatWindow.setCurrentStatus(MicroHotUpdateBiz.getInstance().getCurrentStatus());
        }
    }

    // 监听网络变化
    private final BroadcastReceiver mNetworkChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                Log.i(TAG, "onReceive: " + action);
                if (!MicroUtils.isNetWorkConnected(getApplicationContext())) {
                    if (mLifeStatus >= 1 && mLifeStatus <= 3) {
                        showNetWorkDisconnectedDialog();
                    }

                    updateFloatWindowStatus();
                }
            }
        }
    };
}
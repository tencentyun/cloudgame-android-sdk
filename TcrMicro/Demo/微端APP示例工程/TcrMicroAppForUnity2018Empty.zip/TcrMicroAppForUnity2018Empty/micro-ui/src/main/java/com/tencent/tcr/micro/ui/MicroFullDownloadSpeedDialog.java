package com.tencent.tcr.micro.ui;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.tencent.tcr.micro.sdk.utils.MicroUtils;

/**
 * 点击全速下载之后的弹窗。
 * 用户可以选择定制化改UI。
 */
public class MicroFullDownloadSpeedDialog extends Dialog implements View.OnClickListener {

    private TextView numTotalView;
    private ProgressBar progressBar;

    private long mTotal;
    private long mDownload;
    private int mProgress;

    private BackGameClickListener mOnClickListener;

    public MicroFullDownloadSpeedDialog(Context context) {
        super(context, R.style.MicroCustomDialog);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.micro_download_dialog);
        setCancelable(false);
        numTotalView = findViewById(R.id.progress_msg);
        progressBar = findViewById(R.id.micro_dl_progress_bar);
        Button backView = findViewById(R.id.bt_back_game);
        backView.setOnClickListener(this);

        initView();
        MicroUtils.hideSystemUi(getWindow().getDecorView());
    }

    private void initView() {
        setTotal(mTotal);
        setDownload(mDownload);
        setProgress(mProgress);
    }

    /**
     * 设置下载总大小
     *
     * @param total 大小
     */
    public void setTotal(long total) {
        mTotal = total;
    }

    /**
     * 设置下载的大小
     *
     * @param num 下载的大小
     */
    public void setDownload(long num) {
        mDownload = num;
        if (numTotalView != null) {
            numTotalView.setText(String.format("%s/%s", MicroUtils.byteToMb(mDownload), MicroUtils.byteToMb(mTotal)));
        }
    }

    /**
     * 设置下载进度
     *
     * @param progress 进度
     */
    public void setProgress(int progress) {
        mProgress = progress;
        if (progressBar != null) {
            progressBar.setProgress(progress);
        }
    }

    /**
     * 设置点击监听
     *
     * @param clickListener 监听
     */
    public void setClickListener(BackGameClickListener clickListener) {
        mOnClickListener = clickListener;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.bt_back_game) {
            dismiss();
            if (mOnClickListener != null) {
                mOnClickListener.onBackGameClick();
            }
        }
    }

    public interface BackGameClickListener {

        /**
         * 点击回到游戏按钮
         */
        void onBackGameClick();
    }
}

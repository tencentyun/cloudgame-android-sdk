package com.tencent.tcr.micro.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.tencent.tcr.micro.sdk.constant.MicroConstant;

/**
 * 全速下载弹窗
 */
public class MultifunctionDialog extends Dialog implements View.OnClickListener {

    private MultifunctionClickListener mMultifunctionClickListener;

    private Button btnQualityNormal;
    private Button btnQualitySuper;
    private Button btnQualityOrigin;
    private int mCurrentQuality;

    public MultifunctionDialog(Context context) {
        super(context, R.style.MicroCustomDialog);
        mCurrentQuality = MicroConstant.BITRATE_ORIGIN;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window dialogWindow = getWindow();
        if (dialogWindow != null) {
            dialogWindow.setGravity(Gravity.CENTER);
        }
        setContentView(R.layout.micro_multi_dialog);
        btnQualityNormal = findViewById(R.id.micro_button_normal);
        btnQualitySuper = findViewById(R.id.micro_button_super);
        btnQualityOrigin = findViewById(R.id.micro_button_origin);
        ConstraintLayout btnFullDownload = findViewById(R.id.micro_full_download_container);

        btnFullDownload.setOnClickListener(this);
        btnQualityNormal.setOnClickListener(this);
        btnQualitySuper.setOnClickListener(this);
        btnQualityOrigin.setOnClickListener(this);

        initView();
    }

    private void initView() {
        updateQualityUI(mCurrentQuality);
    }

    public void updateQuality(int currentQuality) {
        mCurrentQuality = currentQuality;
        updateQualityUI(currentQuality);
    }

    private void updateQualityUI(int currentQuality) {
        if (btnQualityNormal != null && btnQualitySuper != null && btnQualityOrigin != null) {
            if (currentQuality == MicroConstant.BITRATE_NORMAL) {
                btnQualityOrigin.setTextColor(getContext().getResources().getColor(R.color.micro_white));
                btnQualitySuper.setTextColor(getContext().getResources().getColor(R.color.micro_white));
                btnQualityNormal.setTextColor(getContext().getResources().getColor(R.color.micro_blue));
            } else if (currentQuality == MicroConstant.BITRATE_SUPER) {
                btnQualityOrigin.setTextColor(getContext().getResources().getColor(R.color.micro_white));
                btnQualitySuper.setTextColor(getContext().getResources().getColor(R.color.micro_blue));
                btnQualityNormal.setTextColor(getContext().getResources().getColor(R.color.micro_white));
            } else {
                btnQualityOrigin.setTextColor(getContext().getResources().getColor(R.color.micro_blue));
                btnQualitySuper.setTextColor(getContext().getResources().getColor(R.color.micro_white));
                btnQualityNormal.setTextColor(getContext().getResources().getColor(R.color.micro_white));
            }
        }
    }


    /**
     * 设置点击监听
     *
     * @param multifunctionClickListener 监听
     */
    public void setDialogListener(MultifunctionClickListener multifunctionClickListener) {
        mMultifunctionClickListener = multifunctionClickListener;
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.micro_full_download_container) {
            mMultifunctionClickListener.onFullDownloadClick();
            dismiss();
        } else if (id == R.id.micro_button_normal) {
            updateQualityUI(MicroConstant.BITRATE_NORMAL);
            mMultifunctionClickListener.onQualityNormalClick();
            dismiss();
        } else if (id == R.id.micro_button_super) {
            updateQualityUI(MicroConstant.BITRATE_SUPER);
            mMultifunctionClickListener.onQualitySuperClick();
            dismiss();
        } else if (id == R.id.micro_button_origin) {
            updateQualityUI(MicroConstant.BITRATE_ORIGIN);
            mMultifunctionClickListener.onQualityOriginClick();
            dismiss();
        }
    }


    public interface MultifunctionClickListener {

        /**
         * 点击全速下载
         */
        void onFullDownloadClick();

        /**
         * 点击标清
         */
        void onQualityNormalClick();

        /**
         * 点击超清
         */
        void onQualitySuperClick();

        /**
         * 点击原画
         */
        void onQualityOriginClick();
    }
}

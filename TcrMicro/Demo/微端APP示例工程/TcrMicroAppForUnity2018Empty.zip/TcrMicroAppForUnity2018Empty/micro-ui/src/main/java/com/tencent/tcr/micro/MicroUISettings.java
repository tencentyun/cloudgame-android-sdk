package com.tencent.tcr.micro;

import android.util.Log;
import android.view.Gravity;
import com.tencent.tcr.micro.ui.MicroCustomDialog;
import com.tencent.tcr.micro.ui.MicroFullDownloadSpeedDialog;
import com.tencent.tcr.micro.ui.MicroLoadingView;
import com.tencent.tcr.micro.ui.MicroProgressFloatView;

/**
 * 该类负责初始化微端用到的UI
 * 包含加载界面、悬浮窗、和弹窗
 * 客户可以根据需求自定义修改对应的UI
 */
public class MicroUISettings {

    private static final String TAG = "MicroUI";

    private MicroUISettings() {
    }

    private static class Holder {

        private static final MicroUISettings sInstance = new MicroUISettings();
    }

    public static MicroUISettings getInstance() {
        return MicroUISettings.Holder.sInstance;
    }

    private MicroBaseActivity mActivity;

    public void init(MicroBaseActivity activity) {
        mActivity = activity;
        initLoadingView();
        initFloatView();
        initDialog();
    }

    private void initDialog() {
        Log.i(TAG, "initDialog: ");
        initRestartDialog();
        initHotUpdateErrorDialog();
        initPickUpLocalDebugFileDialog();
        initNetworkErrorDialog();
        initCloudGameErrorDialog();
        initFullSpeedDownloadDialog();
    }

    private void initCloudGameErrorDialog() {
        Log.i(TAG, "initCloudGameErrorDialog: ");
        MicroCustomDialog cloudGameErrorDialog = new MicroCustomDialog(mActivity);
        cloudGameErrorDialog.setMessageViewGravity(Gravity.CENTER);
        cloudGameErrorDialog.setPositionMsg("重试");
        cloudGameErrorDialog.setNegativeMsg("检查网络");
        mActivity.setCloudGameErrorDialog(cloudGameErrorDialog);
    }

    private void initNetworkErrorDialog() {
        Log.i(TAG, "initNetworkErrorDialog: ");
        MicroCustomDialog networkErrorDialog = new MicroCustomDialog(mActivity);
        networkErrorDialog.setMessageViewGravity(Gravity.CENTER);
        networkErrorDialog.setMessage("无网络连接，请检查网络!");
        networkErrorDialog.setPositionMsg("检查网络");
        networkErrorDialog.setCancelable(true);
        mActivity.setNetworkErrorDialog(networkErrorDialog);
    }

    private void initPickUpLocalDebugFileDialog() {
        Log.i(TAG, "initPickUpLocalDebugFileDialog: ");
        MicroCustomDialog pickUpLocalDebugFileDialog = new MicroCustomDialog(mActivity);
        pickUpLocalDebugFileDialog.setMessageViewGravity(Gravity.CENTER);
        pickUpLocalDebugFileDialog.setPositionMsg("加载补丁");
        pickUpLocalDebugFileDialog.setNegativeMsg("取消");
        pickUpLocalDebugFileDialog.setMessage("检测到本地补丁包，是否加载本地补丁...");
        pickUpLocalDebugFileDialog.setCancelable(false);
        mActivity.setPickUpLocalDebugFileDialog(pickUpLocalDebugFileDialog);
    }

    private void initHotUpdateErrorDialog() {
        Log.i(TAG, "initHotUpdateErrorDialog: ");
        MicroCustomDialog hotUpdateErrorDialog = new MicroCustomDialog(mActivity);
        hotUpdateErrorDialog.setMessageViewGravity(Gravity.CENTER);
        hotUpdateErrorDialog.setPositionMsg("去下载");
        hotUpdateErrorDialog.setNegativeMsg("继续游戏");
        hotUpdateErrorDialog.setMessage("游戏更新失败，请下载完整安装包体验高清游戏～");
        hotUpdateErrorDialog.setCancelable(true);
        mActivity.setHotUpdateErrorDialog(hotUpdateErrorDialog);
    }

    private void initRestartDialog() {
        Log.i(TAG, "initRestartDialog: ");
        MicroCustomDialog restartDialog = new MicroCustomDialog(mActivity);
        restartDialog.setCancelable(false);
        restartDialog.setNegativeMsg("5分钟后重启");
        restartDialog.setPositionMsg("立即重启");
        restartDialog.setMessage("游戏本地化完成，点击重启立即体验高清流畅版本！");
        mActivity.setRestartDialog(restartDialog);
    }

    private void initFullSpeedDownloadDialog() {
        Log.i(TAG, "initFullSpeedDownloadDialog: ");
        MicroFullDownloadSpeedDialog fullSpeedDownloadDialog = new MicroFullDownloadSpeedDialog(mActivity);
        fullSpeedDownloadDialog.setCancelable(false);
        mActivity.setFullSpeedDownloadDialog(fullSpeedDownloadDialog);
    }

    private void initFloatView() {
        Log.i(TAG, "initFloatView: ");
        MicroProgressFloatView microProgressFloatView = new MicroProgressFloatView(mActivity.getApplicationContext(),
                mActivity);
        mActivity.setProgressFloatWindow(microProgressFloatView);
    }

    private void initLoadingView() {
        Log.i(TAG, "initLoadingView: ");
        MicroLoadingView microLoadingView = new MicroLoadingView(mActivity);
        mActivity.setLoadingView(microLoadingView);
    }

}

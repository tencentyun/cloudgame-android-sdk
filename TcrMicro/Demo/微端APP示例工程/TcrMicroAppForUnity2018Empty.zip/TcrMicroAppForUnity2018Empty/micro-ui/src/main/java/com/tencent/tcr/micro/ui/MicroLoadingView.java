package com.tencent.tcr.micro.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * 游戏启动时的加载界面。
 * 客户可以根据需求自定义
 */
public class MicroLoadingView extends RelativeLayout {

    private final View gameLoadingContainer;
    private final TextView loadingProgressTextView;
    private final ProgressBar progressBar;

    public MicroLoadingView(Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.micro_loading_view, this, true);
        gameLoadingContainer = findViewById(R.id.game_loading_container);
        loadingProgressTextView = findViewById(R.id.game_progress_textview);
        progressBar = findViewById(R.id.game_progress_bar);
        setGameLoadingBackground(R.drawable.micro_loading);
        setGameLoadingProgress(0);
    }

    public void setGameLoadingProgress(int percent) {
        progressBar.setProgress(percent);
    }

    public void setGameLoadingText(String text) {
        loadingProgressTextView.setText(text);
    }

    public void setGameLoadingBackground(int resourceId) {
        if (resourceId == 0) {
            gameLoadingContainer.setBackground(null);
        } else {
            gameLoadingContainer.setBackgroundResource(resourceId);
        }
    }

    public void setProgressBarShow(boolean show) {
        if (show) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    public void setViewShow(boolean show) {
        if (show) {
            gameLoadingContainer.setVisibility(View.VISIBLE);
        } else {
            gameLoadingContainer.setVisibility(View.GONE);
        }
    }
}

package com.tencent.tcr.micro.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * 游戏启动时的加载界面。
 * 客户可以根据需求自定义
 */
public class MicroLoadingView extends RelativeLayout {

    private final View gameLoadingContainer;
    private final TextView loadingProgressTextView;
    private final View loadingProgressForeground;

    public MicroLoadingView(Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.micro_loading_view, this, true);
        gameLoadingContainer = findViewById(R.id.game_loading_container);
        loadingProgressTextView = findViewById(R.id.game_progress_textview);
        loadingProgressForeground = findViewById(R.id.game_progress_foreground);
        gameLoadingContainer.setBackgroundResource(R.drawable.micro_loading);
        loadingProgressForeground.setPivotX(0);
        setGameLoadingProgress(0);
    }

    public void setGameLoadingProgress(int percent) {
        loadingProgressForeground.setScaleX(percent / 100.0f);
    }

    public void setGameLoadingText(String text) {
        loadingProgressTextView.setText(text);
    }
    
    public void setViewShow(boolean show) {
        if (show) {
            gameLoadingContainer.setVisibility(View.VISIBLE);
        } else {
            gameLoadingContainer.setVisibility(View.GONE);
        }
    }
}

package com.tencent.tcr.micro.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.XmlResourceParser;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.TextView;
import com.tencent.tcr.micro.MicroBaseActivity;
import com.tencent.tcr.micro.sdk.constant.MicroConstant;
import com.tencent.tcr.micro.sdk.utils.SharedPreferenceUtils;
import java.text.MessageFormat;

/**
 * 悬浮球
 * 客户可以根据需求自定义。
 */
public class MicroProgressFloatView {

    public static final String TAG = "ProgressFloatView";
    public static final int LEFT = 0;
    public static final int RIGHT = 1;
    private static int mProgress = 0;

    private final MicroBaseActivity mActivity;
    private final Handler mHandler;
    private final Context mContext;
    private final Interpolator mLinearInterpolator;
    private WindowManager mWindowManager;
    private WindowManager.LayoutParams mParams;
    private View mFloatView;
    private TextView mCurrentStatTv;
    private TextView mProgressTv;
    private MultifunctionDialog mMicroMultifunctionDialog;

    // 线性加速器
    // 记录当前悬浮球在屏幕的位置
    private int mCurrentLocation = RIGHT;
    // 记录当前手指在屏幕的横坐标
    private float mCurrentXInScreen;
    // 记录当前手指在屏幕的纵坐标
    private float mCurrentYInScreen;
    // 记录当前手指按下时在屏幕的横坐标
    private float mCurrentXDownInScreen;
    // 记录当前手指按下时在屏幕的纵坐标
    private float mCurrentYDownInScreen;
    // 记录当前手指按下时相对悬浮按钮的横坐标
    private float mCurrentXInFloatView;
    // 记录当前手指按下时相对悬浮按钮的纵坐标
    private float mCurrentYInFloatView;
    private float mResetLocationPercent;
    // 当前屏幕宽度
    private int mScreenWidth;
    // 隐藏logo定时器
    private CountDownTimer mHideTimer;
    // 是否正在被拖动
    private boolean mIsBeingDragged = false;
    // 是否正在显示
    private boolean mIsShowing = false;
    // 当前微端状态
    private int mCurrentStatus;

    // 处理触摸事件
    @SuppressLint("ClickableViewAccessibility")
    private final View.OnTouchListener mTouchListener = (v, event) -> {
        Log.i(TAG, "onTouch : " + event.getAction());
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                onFingerDown(event);
                break;
            case MotionEvent.ACTION_MOVE:
                onFingerMove(event);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                onFingerUp();
                break;
            default:
                break;
        }
        return true;
    };

    public MicroProgressFloatView(Context context, MicroBaseActivity activity) {
        mContext = context;
        mActivity = activity;
        mHandler = new Handler(Looper.getMainLooper());
        mLinearInterpolator = new AccelerateInterpolator();
        initFloatView();
        initTimer();
        initFloatWindow();
    }

    private void initFloatView() {
        LayoutInflater inflater = LayoutInflater.from(mActivity);
        XmlResourceParser parser = mContext.getResources().getLayout(R.layout.micro_float_window);
        mFloatView = inflater.inflate(parser, null);
        mProgressTv = mFloatView.findViewById(R.id.float_progress_text);
        mCurrentStatTv = mFloatView.findViewById(R.id.float_download_stat);
        mFloatView.setOnTouchListener(mTouchListener);
    }

    private void initTimer() {
        mHideTimer = new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                //悬浮窗超过5秒没有操作的话会自动隐藏
                if (!mIsBeingDragged) {
                    mFloatView.setAlpha(0.5f);
                }
            }
        };
    }

    @SuppressLint("ObsoleteSdkInt")
    public void initFloatWindow() {
        mParams = new WindowManager.LayoutParams();
        if (mActivity != null) {
            mWindowManager = mActivity.getWindowManager();
            mParams.type = WindowManager.LayoutParams.TYPE_APPLICATION;
        } else {
            mWindowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
                    mParams.type = WindowManager.LayoutParams.TYPE_PHONE;
                } else {
                    mParams.type = WindowManager.LayoutParams.TYPE_TOAST;
                }
            } else {
                mParams.type = WindowManager.LayoutParams.TYPE_PHONE;
            }
        }
        Point point = new Point();
        mWindowManager.getDefaultDisplay().getSize(point);
        mScreenWidth = point.x;
        mParams.format = PixelFormat.RGBA_8888;
        mParams.gravity = Gravity.START | Gravity.TOP;
        mParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION;
        if (mCurrentLocation == LEFT) {
            mParams.x = 0;
        } else {
            mParams.x = mScreenWidth;
        }

        mParams.y = ((point.y) / 2) / 3;
        mParams.alpha = 1;
        mParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        mParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
    }

    // 手指按下悬浮球
    private void onFingerDown(MotionEvent event) {
        mIsBeingDragged = false;
        mHideTimer.cancel();
        mCurrentXInFloatView = event.getX();
        mCurrentYInFloatView = event.getY();
        mCurrentXDownInScreen = event.getRawX();
        mCurrentYDownInScreen = event.getRawY();
        mCurrentXInScreen = event.getRawX();
        mCurrentYInScreen = event.getRawY();
        mFloatView.setTranslationX(0);// 从缩进屏幕恢复正常
        mFloatView.setAlpha(1f);
    }

    // 手指移动悬浮球
    private void onFingerMove(MotionEvent event) {
        mIsBeingDragged = true;
        mCurrentXInScreen = event.getRawX();
        mCurrentYInScreen = event.getRawY();
        if (Math.abs(mCurrentXInScreen - mCurrentXDownInScreen) > mFloatView.getWidth() / 4f
                || Math.abs(mCurrentYInScreen - mCurrentYDownInScreen) > mFloatView.getWidth() / 4f) {
            //将 x y 设置为 view 的中心 本来在左上角
            mParams.x = (int) (mCurrentXInScreen - mCurrentXInFloatView);
            mParams.y = (int) (mCurrentYInScreen - mCurrentYInFloatView) - mFloatView.getHeight() / 2;
            updateView();
        }
    }

    /**
     * 手指松开悬浮球
     */
    private void onFingerUp() {
        if (mCurrentXInScreen <= mScreenWidth / 2f) {
            mCurrentLocation = LEFT;
        } else {
            mCurrentLocation = RIGHT;
        }

        addAnimator();

        // 这里需要判断如果如果手指所在位置和logo所在位置在一个宽度内则不移动,
        if (Math.abs(mCurrentXInScreen - mCurrentXDownInScreen) > mFloatView.getWidth() / 5f
                || Math.abs(mCurrentYInScreen - mCurrentYDownInScreen) > mFloatView.getHeight() / 5f) {
            mIsBeingDragged = false;
        } else {
            openFloatView();
        }
    }

    // 获取状态栏高度
    private int getStatusBarHeight() {
        int height = 0;
        int resourceId = mContext.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            height = mContext.getResources().getDimensionPixelSize(resourceId);
        }
        return height;
    }

    // 给悬浮球添加动画
    private void addAnimator() {
        //手指离开屏幕后 悬浮球自动回到 屏幕两侧
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(100);
        valueAnimator.setInterpolator(mLinearInterpolator);
        valueAnimator.setDuration(200);
        valueAnimator.addUpdateListener(animation -> {
            if (animation.getAnimatedValue() != null) {
                float value = (float) animation.getAnimatedValue();
                mResetLocationPercent = value / 100f;
                mHandler.post(() -> {
                    mIsBeingDragged = true;
                    updateViewLocation();
                });
            }
        });

        valueAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                mIsBeingDragged = false;
                mHideTimer.start();
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mIsBeingDragged = false;
                mHideTimer.start();
            }
        });

        if (!valueAnimator.isRunning()) {
            valueAnimator.start();
        }
    }

    // 更新悬浮球位置
    private void updateViewLocation() {
        if (mParams.x > 0 && mParams.x < mScreenWidth) {
            if (mCurrentLocation == LEFT) {
                float change = mCurrentXInScreen * mResetLocationPercent;
                mParams.x = (int) (mCurrentXInScreen - change);

            } else {
                float change = (mScreenWidth - mCurrentXInScreen) * mResetLocationPercent;
                mParams.x = (int) (mCurrentXInScreen + change);
            }
            updateView();
        }
        mIsBeingDragged = false;
    }

    private void updateView() {
        mIsBeingDragged = true;
        if (mParams.y - mFloatView.getHeight() / 2 <= 0) {
            int statusBarHeight = getStatusBarHeight();
            if (statusBarHeight > 0) {
                mParams.y = statusBarHeight;
            } else {
                mParams.y = 25;
            }
            mIsBeingDragged = true;
        }
        mWindowManager.updateViewLayout(mFloatView, mParams);
    }

    // 显示悬浮球
    public void show() {
        Log.i(TAG, "show: ");
        if (mIsShowing) {
            return;
        }
        if (mWindowManager != null && mParams != null && mFloatView != null) {
            mWindowManager.addView(mFloatView, mParams);
            mIsShowing = true;
        }
        if (mHideTimer == null) {
            initTimer();
        }
        mHideTimer.start();

        setProgress(mProgress);
        mCurrentStatus = mActivity.getCurrentStatus();
        setCurrentStatus(mCurrentStatus);
    }

    /**
     * 隐藏悬浮球
     */
    public void dismiss() {
        if (!mIsShowing) {
            return;
        }
        mFloatView.clearAnimation();
        mHideTimer.cancel();
        mWindowManager.removeViewImmediate(mFloatView);
        mIsBeingDragged = false;
        mIsShowing = false;
    }

    // 点击悬浮球
    private void openFloatView() {
        mCurrentStatus = mActivity.getCurrentStatus();

        switch (mCurrentStatus) {
            case MicroConstant.APPLY_PATCH_SUCCESS:
                // 重启游戏
                mActivity.showRestartDialog();
                break;
            case MicroConstant.PAUSED:
            case MicroConstant.DOWNLOAD_RUNNING:
            case MicroConstant.DOWNLOAD_FAILED:                // 下载失败时也显示云游设置菜单
            case MicroConstant.APPLY_PATCH_START:
            case MicroConstant.DOWNLOAD_SUCCESS:
                showSettingsDialog();
                break;
            case MicroConstant.APPLY_PATCH_FAILED:             // 加载失败
                mActivity.showHotUpdateErrorDialog();
                break;
            default:
                break;
        }
    }

    /**
     * 消除弹窗
     */
    public void dismissDialogIfNeed() {
        if (mMicroMultifunctionDialog != null && mMicroMultifunctionDialog.isShowing()) {
            mMicroMultifunctionDialog.dismiss();
        }
    }

    // 显示云游戏设置弹窗
    private void showSettingsDialog() {
        Log.i(TAG, "showMultifunctionDialog");
        if (mMicroMultifunctionDialog == null || !mMicroMultifunctionDialog.isShowing()) {
            mMicroMultifunctionDialog = new MultifunctionDialog(mActivity);
            int mCurrentBitrate = SharedPreferenceUtils.get(mContext,
                    MicroConstant.USER_BITRATE, MicroConstant.BITRATE_ORIGIN);
            mMicroMultifunctionDialog.updateQuality(mCurrentBitrate);
            mMicroMultifunctionDialog.setDialogListener(new MultifunctionDialog.MultifunctionClickListener() {
                @Override
                public void onFullDownloadClick() {
                    Log.i(TAG, "onFullDownloadClick: ");
                    mActivity.showFullSpeedDownloadDialog();
                }

                @Override
                public void onQualityNormalClick() {
                    mActivity.changeBitrate(MicroConstant.BITRATE_NORMAL);
                    mMicroMultifunctionDialog.updateQuality(MicroConstant.BITRATE_NORMAL);
                    SharedPreferenceUtils.put(mContext, MicroConstant.USER_BITRATE,
                            MicroConstant.BITRATE_NORMAL);
                }

                @Override
                public void onQualitySuperClick() {
                    mActivity.changeBitrate(MicroConstant.BITRATE_SUPER);
                    mMicroMultifunctionDialog.updateQuality(MicroConstant.BITRATE_SUPER);
                    SharedPreferenceUtils
                            .put(mContext, MicroConstant.USER_BITRATE, MicroConstant.BITRATE_SUPER);
                }

                @Override
                public void onQualityOriginClick() {
                    mActivity.changeBitrate(MicroConstant.BITRATE_ORIGIN);
                    mMicroMultifunctionDialog.updateQuality(MicroConstant.BITRATE_ORIGIN);
                    SharedPreferenceUtils.put(mContext, MicroConstant.USER_BITRATE,
                            MicroConstant.BITRATE_ORIGIN);
                }

            });
            mMicroMultifunctionDialog.show();
        }
    }

    /**
     * 设置当前云游戏状态信息
     *
     * @param info 云游戏状态信息
     */
    public void setCloudGameInfo(String info) {
        if (mCurrentStatus == MicroConstant.DOWNLOAD_RUNNING) {
            return;
        }

        mProgressTv.setVisibility(View.VISIBLE);
        mProgressTv.setText(info);
    }

    /**
     * 设置下载状态
     *
     * @param hotUpdateStatus 下载状态
     */
    @SuppressLint("DefaultLocale")
    public void setCurrentStatus(int hotUpdateStatus) {
        Log.i(TAG, "setCurrentStatus: " + hotUpdateStatus);
        mCurrentStatus = hotUpdateStatus;
        switch (hotUpdateStatus) {
            case MicroConstant.PAUSED:
            case MicroConstant.DOWNLOAD_FAILED:
            case MicroConstant.APPLY_PATCH_FAILED:
                mCurrentStatTv.setText("暂停");
                break;
            case MicroConstant.DOWNLOAD_RUNNING:
                mProgressTv.setVisibility(View.VISIBLE);
                mCurrentStatTv.setText("更新中");
                break;
            case MicroConstant.DOWNLOAD_SUCCESS:
                mCurrentStatTv.setText("安装");
                break;
            case MicroConstant.APPLY_PATCH_START:
                mCurrentStatTv.setText("更新中");
                break;
            case MicroConstant.APPLY_PATCH_SUCCESS:
                mCurrentStatTv.setText("完成");
                break;
            default:
                mCurrentStatTv.setText("");
                break;
        }
    }

    /**
     * 设置下载进度
     *
     * @param progress 进度
     */
    public void setProgress(int progress) {
        if (progress != mProgress) {
            mProgress = progress;
        }
        mProgressTv.setText(MessageFormat.format("{0}%", mProgress));
    }

    /**
     * 判断当前悬浮球是否显示
     *
     * @return 是否显示
     */
    public boolean isShowing() {
        return mIsShowing;
    }
}

#!/bin/bash

echo "### begin generate AndroidManifest"
java -jar tools/apktool_2.6.0.jar d hotUpdate/new.apk
cp new/AndroidManifest.xml hotUpdate
rm -rf new
echo "### end generate AndroidManifest"

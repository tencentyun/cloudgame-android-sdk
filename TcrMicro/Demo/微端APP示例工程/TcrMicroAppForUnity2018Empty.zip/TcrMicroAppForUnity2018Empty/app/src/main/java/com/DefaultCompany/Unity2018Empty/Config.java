package com.DefaultCompany.Unity2018Empty;

public class Config {

    // 游戏ID
    public static final String GAME_ID = "game-mkcru8bo";

    // Patch包下载地址
    public static final String PATCH_URL =
            "https://cg-sdk-1258344699.cos.ap-nanjing.myqcloud.com/micro/patch/TcrMicroAppForUnity2018Empty/"
                    + BuildConfig.PATCH_NAME;
    // 完整Apk下载地址
    public static final String APK_URL = "";
    // 与云端通信的端口号
    public static int PORT = 6666;
}

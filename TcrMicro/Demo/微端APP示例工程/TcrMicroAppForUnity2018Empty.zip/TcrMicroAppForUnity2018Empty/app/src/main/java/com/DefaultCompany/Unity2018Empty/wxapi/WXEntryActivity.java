package com.DefaultCompany.Unity2018Empty.wxapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.DefaultCompany.Unity2018Empty.UnityPlayerActivity;
import com.tencent.mm.opensdk.constants.ConstantsAPI;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.tcr.micro.login.WXBiz;

/**
 * 微信登录要求新建的Activity，用于接收微信的消息。
 * 此Activity演示如何进行微信登录穿透，主要用于获取微信用户的信息。
 */
public class WXEntryActivity extends Activity implements IWXAPIEventHandler {

    private static final String TAG = "WXEntryActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);

        try {
            Intent intent = getIntent();
            WXBiz.getInstance().getWXApi().handleIntent(intent, this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        Log.d(TAG, "onNewIntent: ");
        super.onNewIntent(intent);

        setIntent(intent);
        WXBiz.getInstance().getWXApi().handleIntent(intent, this);
    }

    @Override
    public void onReq(BaseReq req) {
        Log.d(TAG, "onReq: " + req);
    }

    @Override
    public void onResp(BaseResp resp) {
        Log.d(TAG, "onResp: " + resp);

        if (resp.getType() == ConstantsAPI.COMMAND_SENDAUTH) {
            SendAuth.Resp authResp = (SendAuth.Resp) resp;
            // 登录穿透修改：将获取到的code传递给云端app处理，此处不进行后续处理
            // WXBiz.getInstance().getToken(authResp.code);
            // 此处修改为将微信返回的authCode传递给可以发送给云端信息的Activity（demo中是UnityPlayerActivity）
            Intent intent = new Intent(WXEntryActivity.this, UnityPlayerActivity.class);
            intent.putExtra("authCode", authResp.code);
            startActivity(intent);
        }
        finish();
    }
}

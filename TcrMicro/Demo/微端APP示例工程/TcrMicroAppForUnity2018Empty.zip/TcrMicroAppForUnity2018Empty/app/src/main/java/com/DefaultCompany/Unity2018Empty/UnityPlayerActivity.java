package com.DefaultCompany.Unity2018Empty;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.tencent.tcr.micro.MicroBaseActivity;
import com.tencent.tcr.micro.login.LoginDialog.DialogClickListener;
import com.tencent.tcr.micro.login.WXBiz;
import org.json.JSONException;
import org.json.JSONObject;

public class UnityPlayerActivity extends MicroBaseActivity {

    private static final String TAG = "UnityPlayerActivity";

    private boolean isConnectSuccess = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);
        // 初始化微信相关逻辑
        WXBiz.getInstance().init(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        Log.d(TAG, "onNewIntent: " + intent.getStringExtra("authCode"));
        super.onNewIntent(intent);
        // 在这里接收WXEntryActivity传递过来的authCode
        if (intent.getStringExtra("authCode") != null) {
            sendLoginCall(intent.getStringExtra("authCode"));
        }
    }

    @Override
    protected void onReceiveCloudGameMessage(String data) {
        // 接收云端游戏的返回信息
        Log.d(TAG, "onReceiveCloudGameMessage: " + data);
        if ("login".equals(data)) {
            login();
        } else if ("pay".equals(data)) {
            pay();
        }
    }

    @Override
    protected void onDataChannelConnectSuccess() {
        Log.d(TAG, "onDataChannelConnectSuccess: ");
        // 连接成功后可以向云端游戏发送信息，例如登录或者支付的结果
        isConnectSuccess = true;
        sendConnectMsg();
        setDebugMode(true);
    }

    //向云端发送链接成功
    private void sendConnectMsg() {
        Log.d(TAG, "sendConnectMsg");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("connected", true);
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            Log.e(TAG, "sendConnectMsg exception, " + e.getMessage());
        }
    }

    private void setDebugMode(boolean isDebug) {
        Log.d(TAG, "setDebugMode" + isDebug);
        try {
            JSONObject jsonObject = new JSONObject();
            // 测试的云端apk中收到该字段为true，则会在云端将收到的信息通过Toast显示出来，方便调试
            // 客户也可以在自己的云端包中新增一个类似的开关，把收到的微端包信息show出来
            jsonObject.put("debug", isDebug);
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            Log.e(TAG, "sendConnectMsg exception, " + e.getMessage());
        }
    }

    // 处理支付操作
    private void pay() {
        Log.d(TAG, "pay: ");
    }

    // 处理登录操作
    private void login() {
        Log.d(TAG, "login: ");
        WXBiz.getInstance().showLoginDialog(this, new DialogClickListener() {
            @Override
            public void onPositiveClick() {
                WXBiz.getInstance().login();
            }

            @Override
            public void onNegativeClick() {
                finish();
            }
        });
    }

    // 获取到微信返回的authCode，通过数据通道传递给云端APP
    // 登录原始逻辑：打开游戏弹出登录窗口->用户点击登录->拉起本地微信->授权成功，获取authCode->继续执行之后逻辑
    // 登录穿透后：打开微端应用->进入云游戏->数据通道连接成功(onDataChannelConnectSuccess)->向云端发送{"connected", true}消息
    // ->云端收到{"connected", true}->云端发送login消息->微端收到login消息弹出登录窗口->用户点击登录->拉起本地微信
    // ->授权成功获取authCode->发送authCode到云端APP->云端APP收到authCode后，执行之后逻辑
    public void sendLoginCall(String authCode) {
        if (!isConnectSuccess) {
            Log.d(TAG, "未连接成功，不能向云端发送登录回调");
            return;
        }
        Log.d(TAG, "向云端发送登录回调");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("authCode", authCode);
            sendDataToCloudGame(jsonObject.toString());
        } catch (JSONException e) {
            Log.e(TAG, "sendLoginCall exception, " + e.getMessage());
        }
    }
}

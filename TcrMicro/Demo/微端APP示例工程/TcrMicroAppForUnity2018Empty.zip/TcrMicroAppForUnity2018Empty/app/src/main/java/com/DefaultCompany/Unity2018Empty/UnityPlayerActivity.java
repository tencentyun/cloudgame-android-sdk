package com.DefaultCompany.Unity2018Empty;

import android.os.Bundle;
import android.util.Log;
import com.tencent.tcr.micro.sdk.Constant;
import com.tencent.tcr.micro.sdk.MicroBaseActivity;
import org.json.JSONException;
import org.json.JSONObject;

public class UnityPlayerActivity extends MicroBaseActivity {

    private static final String TAG = Constant.TAG + "[MainActivity]";

    private boolean isConnectSuccess = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: ");
        // 注意：云游戏启动时带的参数必须经过base64编码，否则会抛出crash（IllegalArgumentException）
        // gameParas为可选参数，不需要携带直接可以使用initConfig(BuildConfig.VERSION)进行初始化。
        String gameParas = "dGVzdCBkYXRhIGZvciBjbG91ZCBnYW1l"; // 经过base64编码之后的字符串（test data for cloud game）
        initConfig(BuildConfig.VERSION, gameParas);    // 初始化配置必须在父类onCreate之前
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onReceiveCloudGameMessage(String data) {
        // 接收云端游戏的返回信息
        Log.d(TAG, "onReceiveCloudGameMessage: " + data);
        if ("login".equals(data)) {
            login();
        } else if ("pay".equals(data)) {
            pay();
        }
    }

    @Override
    protected void onDataChannelConnectSuccess() {
        // 连接成功后可以向云端游戏发送信息，例如登录或者支付的结果
        isConnectSuccess = true;
        sendConnectMsg();
    }

    //向云端发送链接成功
    private void sendConnectMsg() {
        Log.d(TAG, "向云端发送连接成功消息");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("connected", "连接成功");
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "sendConnectMsg exception");
        }
    }

    // 处理登录操作
    private void login() {
        Log.d(TAG, "login: ");
    }

    // 向云端发送登录回调,在登录成功后调用
    private void sendLoginCall(String authCode) {
        if (!isConnectSuccess) {
            Log.d(TAG, "未连接成功，不能向云端发送登录回调");
            return;
        }
        Log.d(TAG, "向云端发送登录回调");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("auth_code", authCode);
            sendDataToCloudGame(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e(TAG, "sendLoginCall exception");
        }
    }

    // 处理支付操作
    private void pay() {
        Log.d(TAG, "pay: ");
    }
}

package com.DefaultCompany.Unity2018Empty;

import android.os.Bundle;
import android.util.Log;
import com.tencent.micro.Constant;
import com.tencent.micro.MicroBaseActivity;

public class UnityPlayerActivity extends MicroBaseActivity {

    private static final String TAG = Constant.TAG + "[MainActivity]";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: ");
        initConfig(BuildConfig.VERSION, BuildConfig.PATCH_NAME);
        // 初始化配置必须在父类onCreate之前
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onReceiveCloudGameMessage(String data) {
        // TODO 在此处处理云端游戏的返回信息
        Log.d(TAG, "onReceiveCloudGameMessage: " + data);
    }

    @Override
    protected void onDataChannelConnectSuccess() {
        // TODO 连接成功后可以向云端游戏发送信息，例如登录或者支付的结果
        sendDataToCloudGame("this is test data from local");
    }
}

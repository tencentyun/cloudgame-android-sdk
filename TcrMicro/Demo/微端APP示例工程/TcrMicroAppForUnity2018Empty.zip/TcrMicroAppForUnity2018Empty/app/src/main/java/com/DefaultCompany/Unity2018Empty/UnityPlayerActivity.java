package com.DefaultCompany.Unity2018Empty;

import android.os.Bundle;
import android.util.Log;
import com.tencent.tcr.micro.MicroBaseActivity;
import org.json.JSONException;
import org.json.JSONObject;

public class UnityPlayerActivity extends MicroBaseActivity {

    private static final String TAG = "UnityPlayerActivity";

    private boolean isConnectSuccess = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onReceiveCloudGameMessage(String data) {
        // 接收云端游戏的返回信息
        Log.d(TAG, "onReceiveCloudGameMessage: " + data);
        if ("login".equals(data)) {
            login();
        } else if ("pay".equals(data)) {
            pay();
        }
    }

    @Override
    protected void onDataChannelConnectSuccess() {
        Log.d(TAG, "onDataChannelConnectSuccess: ");
        // 连接成功后可以向云端游戏发送信息，例如登录或者支付的结果
        isConnectSuccess = true;
        sendConnectMsg();
        setDebugMode(true);
    }

    //向云端发送链接成功
    private void sendConnectMsg() {
        Log.d(TAG, "sendConnectMsg");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("connected", true);
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            Log.e(TAG, "sendConnectMsg exception, " + e.getMessage());
        }
    }
    
    private void setDebugMode(boolean isDebug) {
        Log.d(TAG, "setDebugMode" + isDebug);
        try {
            JSONObject jsonObject = new JSONObject();
            // 测试的云端apk中收到该字段为true，则会在云端将收到的信息通过Toast显示出来，方便调试
            // 客户也可以在自己的云端包中新增一个类似的开关，把收到的微端包信息show出来
            jsonObject.put("debug", isDebug);
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            Log.e(TAG, "sendConnectMsg exception, " + e.getMessage());
        }
    }

    // 处理支付操作
    private void pay() {
        Log.d(TAG, "pay: ");
    }

    // 处理登录操作
    private void login() {
        Log.d(TAG, "login: ");
    }

    // 向云端发送登录回调,在登录成功后调用
    private void sendLoginCall(String authCode) {
        if (!isConnectSuccess) {
            Log.d(TAG, "未连接成功，不能向云端发送登录回调");
            return;
        }
        Log.d(TAG, "向云端发送登录回调");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("auth_code", authCode);
            sendDataToCloudGame(jsonObject.toString());
        } catch (JSONException e) {
            Log.e(TAG, "sendLoginCall exception, " + e.getMessage());
        }
    }
}

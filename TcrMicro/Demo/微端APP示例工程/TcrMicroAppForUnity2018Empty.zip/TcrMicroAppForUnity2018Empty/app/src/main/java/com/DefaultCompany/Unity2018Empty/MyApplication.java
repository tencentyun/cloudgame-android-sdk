package com.DefaultCompany.Unity2018Empty;


import android.app.Application;
import android.content.Context;
import android.util.Log;
import com.tencent.tcr.micro.sdk.Constant;

public class MyApplication extends Application {

    private static final String TAG = Constant.TAG + "[GameApp]";

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate: ");
        super.onCreate();
        Log.i(TAG, String.format("init Application version %s(%s)(%s)", BuildConfig.VERSION, BuildConfig.BUILD_TIME,
                BuildConfig.GIT_COMMIT));
    }

    @Override
    protected void attachBaseContext(Context base) {
        Log.d(TAG, "attachBaseContext: ");
        super.attachBaseContext(base);
    }
}

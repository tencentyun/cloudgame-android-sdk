#!/bin/bash

TOOLS_VERSION=""
# 修改为微端包的工程名
OLD_PROJECT="TcrMicroAppForUnity2018Empty"

if [ "$1" = "tools" ]; then
  cd ../TcrMicroTinker || exit
  ./gradlew buildTinkerSdk
  cd ../$OLD_PROJECT || exit
  TOOLS_VERSION="-debug"
  cp ../TcrMicroTinker/buildSdk/build/tinker-patch-cli-*.jar tools/tinker-patch-cli$TOOLS_VERSION.jar
fi

echo "### begin check"
java -jar tools/tinker-patch-cli$TOOLS_VERSION.jar -old hotUpdate/old.apk -patch hotUpdate/patch.apk -config tools/tinker_config.xml -out check_result
echo "### end check"

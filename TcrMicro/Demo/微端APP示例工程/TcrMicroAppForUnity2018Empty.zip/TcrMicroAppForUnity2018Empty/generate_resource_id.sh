#!/bin/bash
# 添加Android SDK 中aapt2的环境变量
export ANDROID_HOME=/Users/shawswyan/Library/Android/sdk
export PATH=${PATH}:${ANDROID_HOME}/build-tools/31.0.0

if [ $# -eq 0 ]; then
  echo "### You must use ./generateRDotTxt.sh apkPath"
  exit 1
fi
echo "### begin generate R.txt"
# 传入apk路径
aapt2 dump resources $1 --no-values | grep resource | sed 's/\// /' | awk '{printf "int "$3" "$4" "$2"\n"}' | sed 's/\./_/' >hotUpdate/R.txt
echo "### end generate R.txt"

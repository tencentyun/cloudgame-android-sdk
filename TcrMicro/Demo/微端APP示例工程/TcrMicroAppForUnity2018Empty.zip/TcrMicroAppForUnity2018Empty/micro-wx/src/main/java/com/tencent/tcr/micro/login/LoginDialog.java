package com.tencent.tcr.micro.login;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;

public class LoginDialog extends Dialog implements View.OnClickListener {

    private TextView messageView;
    private Button negativeButton;
    private Button positionButton;

    private DialogClickListener mDialogClickListener;
    
    private boolean showNegative = false;
    private boolean showPosition = false;
    private String negativeMsg;
    private String positionMsg;
    private String message;
    private int messageViewGravity = Gravity.START;


    public LoginDialog(@NonNull Context context) {
        super(context, R.style.MicroLoginDialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window dialogWindow = getWindow();
        if (dialogWindow != null) {
            dialogWindow.setGravity(Gravity.CENTER);
        }
        setContentView(R.layout.micro_login_dialog);
        messageView = findViewById(R.id.message_view);
        if (messageViewGravity > 0) {
            messageView.setGravity(messageViewGravity);
        }
        negativeButton = findViewById(R.id.micro_negative_button);
        positionButton = findViewById(R.id.micro_positive_button);
        negativeButton.setOnClickListener(this);
        positionButton.setOnClickListener(this);
        initView();
    }

    private void initView() {
        if (showNegative && negativeMsg != null) {
            negativeButton.setVisibility(View.VISIBLE);
            negativeButton.setText(negativeMsg);
        }
        if (showPosition && positionMsg != null) {
            positionButton.setVisibility(View.VISIBLE);
            positionButton.setText(positionMsg);
        }
        if (message != null) {
            messageView.setText(message);
        }
    }

    /**
     * 设置弹框显示的文字
     *
     * @param msg 文字
     */
    public void setMessage(String msg) {
        message = msg;
    }

    /**
     * 设置左边按钮显示的文字
     *
     * @param msg 信息
     */
    public void setNegativeMsg(String msg) {
        showNegative = true;
        negativeMsg = msg;
    }

    /**
     * 设置右边按钮显示的文字
     *
     * @param msg 信息
     */
    public void setPositionMsg(String msg) {
        showPosition = true;
        positionMsg = msg;
    }

    /**
     * 设置信息显示位置
     *
     * @param gravity 位置
     */
    public void setMessageViewGravity(int gravity) {
        messageViewGravity = gravity;
    }

    /**
     * 设置点击监听
     *
     * @param dialogListener 监听
     */
    public void setDialogListener(DialogClickListener dialogListener) {
        mDialogClickListener = dialogListener;
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.micro_negative_button) {
            dismiss();
            if (mDialogClickListener != null) {
                mDialogClickListener.onNegativeClick();
            }
        } else if (id == R.id.micro_positive_button) {
            dismiss();
            if (mDialogClickListener != null) {
                mDialogClickListener.onPositiveClick();
            }
        }
    }

    public interface DialogClickListener {

        /**
         * 点击右边按钮
         */
        void onPositiveClick();

        /**
         * 点击左边按钮
         */
        void onNegativeClick();
    }

}

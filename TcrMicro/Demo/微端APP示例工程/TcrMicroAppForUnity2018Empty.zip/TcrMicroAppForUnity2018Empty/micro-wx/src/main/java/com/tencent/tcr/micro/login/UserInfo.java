package com.tencent.tcr.micro.login;

public class UserInfo {

    private String accessToken;
    private String openId;
    private String refreshToken;
    private String scope;
    private String headimgurl;
    private String nickname;
    private String sex;
    private String province;
    private String city;
    private String country;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getHeadimgurl() {
        return headimgurl;
    }

    public void setHeadimgurl(String headimgurl) {
        this.headimgurl = headimgurl;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "UserInfo{"
                + "accessToken='" + accessToken + '\''
                + ", openId='" + openId + '\''
                + ", refreshToken='" + refreshToken + '\''
                + ", scope='" + scope + '\''
                + ", headimgurl='" + headimgurl + '\''
                + ", nickname='" + nickname + '\''
                + ", sex='" + sex + '\''
                + ", province='" + province + '\''
                + ", city='" + city + '\''
                + ", country='" + country + '\''
                + '}';
    }
}

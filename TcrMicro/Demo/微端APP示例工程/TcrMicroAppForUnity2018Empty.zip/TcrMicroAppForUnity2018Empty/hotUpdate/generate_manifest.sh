#!/bin/bash

if [ $# -eq 0 ]; then
  echo "### You must use ./generate_manifest.sh 游戏原始apk路径"
  exit 1
fi

echo "### begin generate AndroidManifest"
mkdir out
java -jar tools/apktool_2.6.0.jar d $1
cp AndroidUnity2018Empty-release/AndroidManifest.xml out
rm -rf AndroidUnity2018Empty-release
echo "### end generate AndroidManifest"

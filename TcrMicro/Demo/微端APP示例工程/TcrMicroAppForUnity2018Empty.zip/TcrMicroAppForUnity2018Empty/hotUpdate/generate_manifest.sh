#!/bin/bash

if [ $# -eq 0 ]; then
  echo "### You must use ./generate_manifest.sh 游戏原始apk路径"
  exit 1
fi

echo "### begin generate AndroidManifest"
mkdir out
java -jar tools/apktool_2.6.0.jar d $1 -o temp
cp temp/AndroidManifest.xml out
rm -rf temp
echo "### end generate AndroidManifest"

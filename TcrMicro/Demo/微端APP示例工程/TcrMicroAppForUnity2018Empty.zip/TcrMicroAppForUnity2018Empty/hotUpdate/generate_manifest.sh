#!/bin/bash

if [ $# -eq 0 ]; then
  echo "### You must use ./generate_manifest.sh 游戏原始apk路径"
  exit 1
fi

echo "### begin generate AndroidManifest"
mkdir out
java -jar tools/apktool_2.9.3.jar d $1 -o game
cp game/AndroidManifest.xml out
## 用游戏apk的清单文件替换微端demo的
cp out/AndroidManifest.xml ../app/src/main
echo "### end generate AndroidManifest"

#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./local_debug.sh 微端apk路径 补丁包路径"
  exit 1
fi

echo "try create /storage/emulated/0/Download folder"
# 设备启动时Download目录不存在, 需要提前创建否则push不上去
adb shell mkdir -p /storage/emulated/0/Download
echo "begin push $2 into /storage/emulated/0/Download"
adb push $2 /storage/emulated/0/Download/
echo "begin uninstall com.DefaultCompany.Unity2018Empty"
adb uninstall com.DefaultCompany.Unity2018Empty
echo "begin install $1"
adb install -r -d $1

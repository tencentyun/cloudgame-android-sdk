#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./local_debug.sh 微端apk路径 补丁包路径"
  exit 1
fi

echo "try create /storage/emulated/0/Download folder"
# 设备启动时Download目录不存在, 需要提前创建否则push不上去
adb shell mkdir -p /storage/emulated/0/Download

# push patch
echo "begin push $2 into /storage/emulated/0/Download"
adb push $2 /storage/emulated/0/Download/

# uninstall micro apk
PKG_EXISTS=`adb shell pm list packages | grep com.DefaultCompany.Unity2018Empty`
if test -n "$PKG_EXISTS"
then
  echo "begin uninstall com.DefaultCompany.Unity2018Empty"
  adb uninstall com.DefaultCompany.Unity2018Empty
fi

# install micro apk
echo "begin install $1"
adb install -t -r -d $1

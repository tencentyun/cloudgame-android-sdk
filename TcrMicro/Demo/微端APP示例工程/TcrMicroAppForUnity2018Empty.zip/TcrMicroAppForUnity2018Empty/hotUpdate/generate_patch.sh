#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./generate_patch.sh 游戏原始apk路径"
  exit 1
fi

# 删除游戏原始apk中的apache仓库【可选，如果发现游戏apk集成的apache仓库是stub，需要将此开关打开】
# 部分客户的游戏会把apache仓库的stub打入到apk中，导致热更新成功后出现java.lang.RuntimeException:Stub!的异常
# 参考Tinker的issues，https://github.com/Tencent/tinker/issues/957
# 9.0之前/system/framework/org.apache.http.legacy.boot.jar一直在bootclasspath 中，在9.0移除了。
# 这个jar包出现在app PathClassloader DexListPath 中。
# Tinker的热更新原理是优先从补丁包自定义的classLoader的DexListPath中寻找类，然后才会去宿主app的PathClassloader的DexListPath中寻找，
# 所以热更新成功后游戏优先找到了打入到apk中的apache stub，导致运行失败。
# 正常app安装运行时，会优先从bootclasspath（9.0之前）或者PathClassloader DexListPath中的org.apache.http.legacy.boot.jar中寻找，所以可以正常运行。
# 解决方法：
# 第一种可以不将apache仓库的stub打入apk中，在app的build.gradle文件中的android字段下新增useLibrary 'org.apache.http.legacy'，让apache仓库只参与app的编译。
# 第二种方法是在生成补丁时将游戏apk中的apache仓库移除，移除时使用./generate_patch.sh 游戏原始apk路径 true命令，其中第三个字段为true表示会检查游戏apk是否有apache仓库
if [ $2 ]
then
  need_repack=false
  # shellcheck disable=SC2045
  # 找到apache仓库并删掉
  for file in `ls game`
  do
    if [ -d game/$file/org/apache/http ]
    then
      need_repack=true
      echo "game/$file/org/apache/http 存在"
      rm -rf game/$file/org/apache/http
    fi
  done

  echo "need_repack=$need_repack"

  if [ ! -f game/dist/$1 ]
  then
    if [ $need_repack ]
    then
      echo "开始重打包"
      java -jar tools/apktool_2.6.0.jar b game
      # 生成补丁包可以不签名
      ##  jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -storepass testres -keypass testres -keystore ../app/keystore/micro.keystore -signedjar $1 game/dist/$1 testres
    fi
  fi

  if [ $need_repack ]
  then
    echo "开始拷贝重打包之后的包game/dist/$1到hotUpdate目录"
    # 把删掉apache仓库生成的apk替换原来的apk
    cp game/dist/$1 $1
  fi
fi

# 开始生成补丁包
# 生成补丁包时会根据游戏apk的清单文件自动生成微端工程需要的壳子组件，放在java目录下。
# 同时还会生成壳子组件需要的styles资源和清单文件中用到的xml资源。
# 这样可以简化接入步骤，在适配微端时无需手动创建大量的壳子组件。
echo "generate patch begin"
mkdir out
java -Dfile.encoding=UTF-8 -jar tools/tinker-patch-cli.jar -new $1 -config tools/tinker_config.xml -out java
mv java/patch_unsigned.apk java/patch.apk
mv java/patch.apk out
mv java/log.txt out
# shellcheck disable=SC2045
for file in `ls java/xml`
do
  echo "game/res/xml/$file"
  cp game/res/xml/$file ../app/src/main/res/xml
done
rm -rf java/xml
mv java/styles.xml ../app/src/main/res/values
rm -rf java/patch.apk
rm -rf java/*.txt
rm -rf java/*.zip
rm -rf java/tinker_result
rm -rf java/*-new
rm -rf java/*-old
### 将生成的壳子代码拷贝到app目录
cp -rf java/* ../app/src/main/java
echo "generate patch end"
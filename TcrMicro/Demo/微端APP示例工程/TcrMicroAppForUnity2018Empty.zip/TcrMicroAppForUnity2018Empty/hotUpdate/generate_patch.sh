#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./generate_patch.sh 游戏原始apk路径"
  exit 1
fi

echo "generate patch begin"
mkdir out
java -jar tools/tinker-patch-cli.jar -new $1 -config tools/tinker_config.xml -out patch_result
cp patch_result/patch_unsigned.apk out/patch.apk
cp patch_result/log.txt out
rm -rf patch_result

#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./generate_patch.sh 游戏原始apk路径"
  exit 1
fi

echo "generate patch begin"
mkdir out
java -jar tools/tinker-patch-cli.jar -new $1 -config tools/tinker_config.xml -out java
mv java/patch_unsigned.apk java/patch.apk
mv java/patch.apk out
mv java/log.txt out
rm -rf java/patch.apk
rm -rf java/*.txt
rm -rf java/*.zip
rm -rf java/tinker_result
rm -rf java/*-new
rm -rf java/*-old
## 将生成的壳子代码拷贝到app目录
cp -rf java/* ../app/src/main/java

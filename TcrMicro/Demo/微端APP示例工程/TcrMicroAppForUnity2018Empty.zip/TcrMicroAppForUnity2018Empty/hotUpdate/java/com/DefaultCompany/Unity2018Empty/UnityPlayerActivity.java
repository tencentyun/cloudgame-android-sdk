package com.DefaultCompany.Unity2018Empty;

import android.app.Activity;

public class UnityPlayerActivity extends Activity {

}

#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./generate_resource_id.sh 游戏原始apk路径"
  exit 1
fi
echo "### begin generate R.txt"
mkdir out
# 通过aapt2提取出资源id，注意在windows下修改为aapt2.exe
# MAC或者Linux用下面这条命令
./tools/aapt2 dump resources $1 --no-values | grep resource | sed 's/\// /' | awk '{printf "int "$3" "$4" "$2"\n"}' | sed 's/\./_/g' >out/R.txt
# windows操作系统用这条
#./tools/aapt2.exe dump resources $1 --no-values | grep resource | sed 's/\// /' | awk '{printf "int "$3" "$4" "$2"\n"}' | sed 's/\./_/g' >out/R.txt
echo "### end generate R.txt"

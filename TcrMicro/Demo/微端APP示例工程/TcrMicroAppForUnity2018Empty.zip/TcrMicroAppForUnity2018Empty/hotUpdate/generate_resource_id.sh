#!/bin/bash
# 添加Android SDK 中aapt2的环境变量
export ANDROID_HOME=/Users/shawswyan/Library/Android/sdk
export PATH=${PATH}:${ANDROID_HOME}/build-tools/31.0.0

if [ $# -eq 0 ]; then
  echo "### You must use ./generate_resource_id.sh 游戏原始apk路径"
  exit 1
fi
echo "### begin generate R.txt"
mkdir out
# 传入apk路径
aapt2 dump resources $1 --no-values | grep resource | sed 's/\// /' | awk '{printf "int "$3" "$4" "$2"\n"}' | sed 's/\./_/' >out/R.txt
echo "### end generate R.txt"

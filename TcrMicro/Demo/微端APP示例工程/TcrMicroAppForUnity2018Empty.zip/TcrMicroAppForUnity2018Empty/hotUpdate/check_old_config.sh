#!/bin/bash
if [ $# -eq 0 ]; then
  echo "### You must use ./check_old_config.sh 微端apk路径 游戏原始apk路径"
  exit 1
fi

echo "### begin check"
java -jar tools/tinker-patch-cli.jar -old $1 -patch $2 -config tools/tinker_config.xml -out check_result
echo "### end check"

package com.tencent.tcr.micro.login;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import androidx.annotation.NonNull;
import com.tencent.mm.opensdk.constants.ConstantsAPI;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.tencent.tcr.micro.login.LoginDialog.DialogClickListener;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * 该类模拟了微信请求后台的功能，通过微信回复的登录请求参数，通过请求微信给定的后台api，完成用户信息的获取。
 * demo中没有专门为微信请求写一个后台，只是模拟一个本地请求后台。
 * 该后台中封装了获取后台token，检验token，刷新token，获取用户信息的接口。
 */
public class WXBiz {

    private static final String TAG = "WXBiz";

    // APP_ID和APP_SECRET不建议在app中代码中展示，这里只是为了演示方便，对微信后台的请求放在了app内部
    private static final String APP_ID = "wx7060c36f4d3e64b2";
    private static final String APP_SECRET = "67d3e8e97d5d746feb5bfc8956cffa6c";
    private static final String WX_SERVER = "https://api.weixin.qq.com/";
    private static volatile boolean sInited = false;

    private static MyHandler handler;

    private Context mContext;
    // IWXAPI 是第三方 app 和微信通信的 openApi 接口
    private IWXAPI api;
    private ResultListener mResultListener;

    public static final int GET_TOKEN = 1;
    public static final int CHECK_TOKEN = 2;
    public static final int REFRESH_TOKEN = 3;
    public static final int GET_INFO = 4;
    public static final int GET_IMG = 5;

    private WXBiz() {
    }

    private static class Holder {

        @SuppressLint("StaticFieldLeak")
        private static final WXBiz sInstance = new WXBiz();
    }

    public static WXBiz getInstance() {
        return Holder.sInstance;
    }

    /**
     * 初始化微信后台模块，将应用注册到微信中。
     *
     * @param context 当前上下文
     */
    public void init(Context context) {
        if (sInited) {
            Log.i(TAG, "already init, return");
            return;
        }
        Log.d(TAG, "init WXLoginBiz");
        sInited = true;
        mContext = context.getApplicationContext();
        handler = new MyHandler(Looper.myLooper());

        // 通过 WXAPIFactory 工厂，获取 IWXAPI 的实例
        api = WXAPIFactory.createWXAPI(mContext, APP_ID, false);

        // 将应用的 appId 注册到微信
        api.registerApp(APP_ID);

        //建议动态监听微信启动广播进行注册到微信
        context.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                // 将该 app 注册到微信
                api.registerApp(APP_ID);
            }
        }, new IntentFilter(ConstantsAPI.ACTION_REFRESH_WXAPP));
    }

    /**
     * 获取微信后台api
     *
     * @return 微信后台api
     */
    public IWXAPI getWXApi() {
        return api;
    }

    public void setResultListener(ResultListener resultListener) {
        this.mResultListener = resultListener;
    }

    public void login() {
        Log.d(TAG, "login: ");
        // send oauth request
        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";
        req.state = "wechat_sdk_demo_test";
        api.sendReq(req);
    }

    /**
     * 弹出微信登录窗口
     *
     * @param context activity上下文
     * @param dialogClickListener dialog按钮监听
     */
    public void showLoginDialog(Context context, DialogClickListener dialogClickListener) {
        LoginDialog mLoginDialog;
        mLoginDialog = new LoginDialog(context);
        mLoginDialog.setCancelable(false);
        mLoginDialog.setPositionMsg("微信登录");
        mLoginDialog.setNegativeMsg("退出游戏");
        mLoginDialog.setMessage("登录游戏获取完整体验");
        mLoginDialog.setMessageViewGravity(Gravity.CENTER);
        mLoginDialog.setDialogListener(dialogClickListener);
        mLoginDialog.show();
    }

    public void getToken(String code) {
        Log.d(TAG, "getToken: " + code);
        sendWxAPI(handler, String.format(WX_SERVER + "sns/oauth2/access_token?"
                + "appid=%s&secret=%s&code=%s&grant_type=authorization_code", APP_ID, APP_SECRET, code), GET_TOKEN);
    }

    private static String getCode(String str) {
        String[] encodeList = {"GB2312", "ISO-8859-1", "UTF-8", "GBK", "Big5", "UTF-16LE", "Shift_JIS", "EUC-JP"};
        for (String s : encodeList) {
            try {
                if (str.equals(new String(str.getBytes(s), s))) {
                    return s;
                }
            } catch (Exception e) {
                Log.e(TAG, "getCode: " + e.getMessage());
            }
        }
        return "";
    }

    /**
     * 微信请求结果监听
     */
    public interface ResultListener {

        void onLoginSuccess(UserInfo userInfo);

        void onLoginFailed(String errorReason);
    }

    private static void sendWxAPI(Handler handler, String url, int msgTag) {
        Log.d(TAG, "sendWxAPI, url=" + url + ",msgTag=" + msgTag);
        HttpsThread httpsThread = new HttpsThread(handler, url, msgTag);
        httpsThread.start();
    }

    /**
     * 网络请求线程，每个请求会新建一个线程来进行操作。
     */
    private static class HttpsThread extends Thread {

        private final Handler handler;
        private final String httpsUrl;
        private final int msgTag;

        public HttpsThread(Handler handler, String url, int msgTag) {
            this.handler = handler;
            this.httpsUrl = url;
            this.msgTag = msgTag;
        }

        @Override
        public void run() {
            if (msgTag == GET_IMG) {
                try {
                    byte[] imgdata = httpURLConnectionGet(httpsUrl);
                    Message msg = Message.obtain();
                    msg.what = msgTag;
                    Bundle data = new Bundle();
                    data.putByteArray("imgdata", imgdata);
                    msg.setData(data);
                    handler.sendMessage(msg);
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            } else {
                int resCode;
                InputStream in;
                String httpResult;
                try {
                    URL url = new URL(httpsUrl);
                    URLConnection urlConnection = url.openConnection();
                    HttpsURLConnection httpsConn = (HttpsURLConnection) urlConnection;
                    httpsConn.setAllowUserInteraction(false);
                    httpsConn.setInstanceFollowRedirects(true);
                    httpsConn.setRequestMethod("GET");
                    httpsConn.connect();
                    resCode = httpsConn.getResponseCode();

                    if (resCode == HttpURLConnection.HTTP_OK) {
                        in = httpsConn.getInputStream();

                        BufferedReader reader = new BufferedReader(new InputStreamReader(
                                in, StandardCharsets.ISO_8859_1), 8);
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        in.close();
                        httpResult = sb.toString();
                        Log.i(TAG, httpResult);

                        Message msg = Message.obtain();
                        msg.what = msgTag;
                        Bundle data = new Bundle();
                        data.putString("result", httpResult);
                        msg.setData(data);
                        handler.sendMessage(msg);
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }

        private byte[] httpURLConnectionGet(String url) throws Exception {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            if (connection == null) {
                Log.e(TAG, "open connection failed.");
                return null;
            }
            int responseCode = connection.getResponseCode();
            if (responseCode >= 300) {
                connection.disconnect();
                Log.w(TAG, "dz[httpURLConnectionGet 300]");
                return null;
            }

            InputStream is = connection.getInputStream();
            byte[] data = readStream(is);
            connection.disconnect();

            return data;
        }

        private byte[] readStream(InputStream inStream) throws IOException {
            byte[] buffer = new byte[1024];
            int len;
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            while ((len = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, len);
            }
            byte[] data = outStream.toByteArray();
            outStream.close();
            inStream.close();
            return data;
        }
    }

    @SuppressLint("HandlerLeak")
    private class MyHandler extends Handler {

        private final UserInfo userInfo;

        public MyHandler(@NonNull Looper looper) {
            super(looper);
            userInfo = new UserInfo();
        }

        @Override
        public void handleMessage(Message msg) {
            int tag = msg.what;
            Bundle data = msg.getData();
            JSONObject json;
            switch (tag) {
                case GET_TOKEN:
                    Log.d(TAG, "handleMessage: GET_TOKEN");
                    try {
                        json = new JSONObject(data.getString("result"));
                        userInfo.setOpenId(json.getString("openid"));
                        userInfo.setAccessToken(json.getString("access_token"));
                        userInfo.setRefreshToken(json.getString("refresh_token"));
                        userInfo.setScope(json.getString("scope"));

                        sendWxAPI(handler, String.format(WX_SERVER + "sns/auth?access_token=%s&openid=%s",
                                userInfo.getAccessToken(), userInfo.getOpenId()), CHECK_TOKEN);

                    } catch (JSONException e) {
                        Log.e(TAG, e.getMessage());
                        mResultListener.onLoginFailed("Get token failed");
                    }
                    break;
                case CHECK_TOKEN: {
                    Log.d(TAG, "handleMessage: CHECK_TOKEN");
                    try {
                        json = new JSONObject(data.getString("result"));
                        int errcode = json.getInt("errcode");
                        if (errcode == 0) {
                            sendWxAPI(handler, String.format(WX_SERVER + "sns/userinfo?"
                                            + "access_token=%s&openid=%s", userInfo.getAccessToken(),
                                    userInfo.getOpenId()), GET_INFO);
                        } else {
                            sendWxAPI(handler,
                                    String.format(WX_SERVER + "sns/oauth2/refresh_token?"
                                                    + "appid=%s&grant_type=refresh_token&refresh_token=%s",
                                            APP_ID, userInfo.getRefreshToken()), REFRESH_TOKEN);
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, e.getMessage());
                        mResultListener.onLoginFailed("Check token failed");
                    }
                    break;
                }
                case REFRESH_TOKEN: {
                    Log.d(TAG, "handleMessage: REFRESH_TOKEN");
                    try {
                        json = new JSONObject(data.getString("result"));
                        userInfo.setOpenId(json.getString("openid"));
                        userInfo.setAccessToken(json.getString("access_token"));
                        userInfo.setAccessToken(json.getString("refresh_token"));
                        userInfo.setScope(json.getString("scope"));
                        sendWxAPI(handler, String.format(WX_SERVER + "sns/userinfo?"
                                        + "access_token=%s&openid=%s", userInfo.getAccessToken(),
                                userInfo.getOpenId()), GET_INFO);
                    } catch (JSONException e) {
                        Log.e(TAG, e.getMessage());
                        mResultListener.onLoginFailed("Refresh token failed");
                    }
                    break;
                }
                case GET_INFO: {
                    Log.d(TAG, "handleMessage: GET_INFO");
                    try {
                        json = new JSONObject(data.getString("result"));
                        userInfo.setHeadimgurl(json.getString("headimgurl"));
                        String encode = getCode(json.getString("nickname"));
                        userInfo.setNickname(new String(json.getString("nickname").getBytes(encode),
                                StandardCharsets.UTF_8));
                        userInfo.setSex(json.getString("sex"));
                        userInfo.setProvince(json.getString("province"));
                        userInfo.setCity(json.getString("city"));
                        userInfo.setCountry(json.getString("country"));
                        Log.d(TAG, userInfo.toString());
                        mResultListener.onLoginSuccess(userInfo);
                    } catch (JSONException | UnsupportedEncodingException e) {
                        Log.e(TAG, e.getMessage());
                        mResultListener.onLoginFailed("Get info failed");
                    }
                    break;
                }
                case GET_IMG: {
                    Log.d(TAG, "handleMessage: GET_IMG");
                    byte[] imgdata = data.getByteArray("imgdata");
                    Bitmap bitmap;
                    if (imgdata != null) {
                        bitmap = BitmapFactory.decodeByteArray(imgdata, 0, imgdata.length);
                    } else {
                        bitmap = null;
                        Log.e(TAG, "头像获取失败");
                        mResultListener.onLoginFailed("Get head image failed");
                    }
                    Log.d(TAG, "bitmap: " + (bitmap != null ? bitmap.getByteCount() : 0));
                    break;
                }
                default:
                    throw new IllegalStateException("Unexpected value: " + tag);
            }
        }
    }
}

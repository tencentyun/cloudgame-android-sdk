package com.DefaultCompany.Unity2018Empty;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;
import com.tencent.tcr.micro.cloudsdk.DataChannel;
import java.nio.charset.Charset;

public class SocketService extends Service {

    private static final String TAG = "SocketService";
    private static final int MSG_SHOW_TOAST = 0;
    private static final int MSG_STOP_SERVICE = 1;
    private DataChannel mDataChannel;
    private Handler mHandler;

    DataChannel.Listener listener = new DataChannel.Listener() {
        public void onReceive(byte[] buffer, int len) {
            // 从监听的端口接收到数据
            String dataFromRemote = new String(buffer, 0, len);
            Log.d(TAG, "receive local data=" + dataFromRemote);

            sendData(dataFromRemote);

            Message message = Message.obtain();
            message.what = MSG_SHOW_TOAST;
            message.obj = dataFromRemote;
            mHandler.sendMessage(message);
        }

        public void onException(Exception e) {
            Log.e(TAG, "onException: " + e.getMessage());
            // 数据接收或发送过程中出现异常
            // TODO 处理异常
        }
    };

    /**
     * 我们用是否设置了端口作为是否启动服务的依据
     *
     * @return true 如果能够解析出来端口号
     */
    public static boolean enable() {
        return getUdpPortFromProperty() > 0;
    }

    /**
     * 返回设置的udp端口
     *
     * @return udp端口,　测试写死为6666
     */
    public static int getUdpPortFromProperty() {
        return 6666;
    }

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate: ");
        super.onCreate();
        mHandler = new ServiceHandler();
        if (!enable()) {
            Log.i(TAG, "disable SocketService.");
            return;
        }

        mDataChannel = new DataChannel(listener, getUdpPortFromProperty());
        mDataChannel.open();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mDataChannel.close();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * 通过此方法向发送方回复数据
     * 必须在数据通道连接成功后使用
     * 必须在工作线程中使用
     *
     * @param data 要发送的数据
     */
    public void sendData(String data) {
        if (mDataChannel != null) {
            Log.d(TAG, "sendData to local:" + data);
            mDataChannel.send(data.getBytes(Charset.forName("UTF-8")));
        }
    }

    private final class ServiceHandler extends Handler {
        
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SHOW_TOAST:
                    Toast.makeText(getApplicationContext(), (String) msg.obj, Toast.LENGTH_SHORT).show();
                    break;
                case MSG_STOP_SERVICE:
                    stopSelf();
                    break;
                default:
                    break;
            }

        }
    }
}

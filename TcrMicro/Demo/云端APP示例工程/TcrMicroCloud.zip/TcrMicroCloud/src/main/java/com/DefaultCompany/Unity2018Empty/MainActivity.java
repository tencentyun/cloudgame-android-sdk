package com.DefaultCompany.Unity2018Empty;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;

/**
 * 该Activity演示了
 *
 * @see <a href="https://github.com/tencentyun/cloudgame-android-sdk/blob/master/TcrMicro/Doc/%E5%BE%AE%E7%AB%AF%E6%8E%A5%E5%85%A5%E6%8C%87%E5%8D%97.md>微端接入指南4.2小节</a>
 *         中数据通道连接之前如何传递参数。
 *         在微端连接之前，云端游戏一直会处在该Activity界面，
 *         当有微端接入该实例，云端容器会把微端带的额外参数通过广播的形式传递给CloudGamingReceiver，
 *         获取到额外参数GameParas之后可以通过intent带给需要的Activity。
 *         如果不需要带额外参数，可以忽略这个类，直接启动游戏的第一个Activity。
 */
public class MainActivity extends Activity {

    public static class CloudGamingReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String gameParas = intent.getStringExtra("GameParas");
            Log.i("CloudGamingReceiver", "GameParas:" + intent.getStringExtra("GameParas"));
            // 收到需要的参数后再启动游戏的第一个activity
            // 收到的参数是经过base64编码的，在微端工程的MicroBaseActivity#init方法中发送
            // 编码之前的原文是"test data for cloud game"，参数大小限制为Android中intent传输的数据最大值

            // 如果需要在本地对新增的额外参数进行调试，可以使用
            // adb shell am broadcast -a android.intent.action.CLOUD_GAMING_STARTED -e GameParas debug
            // 命令进入游戏主Activity
            if ("dGVzdCBkYXRhIGZvciBjbG91ZCBnYW1l".equals(gameParas) || "debug".equals(gameParas)) {
                Intent newIntent = new Intent(context, UnityPlayerActivity.class);
                context.startActivity(newIntent);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.CLOUD_GAMING_STARTED");
        registerReceiver(new CloudGamingReceiver(), intentFilter);
        // 启动数据通道通信服务，需要尽量早些启动这个服务，保证微端连接云端实例时该服务已经在运行。
        // 一般情况下云端app会提前在云服务器中启动，等待微端的连接。
        startService(new Intent(this, DataChannelService.class));
    }
}
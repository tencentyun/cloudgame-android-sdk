package com.DefaultCompany.Unity2018Empty;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import com.tencent.tcr.micro.cloudsdk.DataChannel;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import org.json.JSONObject;

public class DataChannelService extends Service {

    private static final String TAG = "DataChannelService";
    private static final int PORT = 6666; // 与微端通信的端口号，可以自己定义与微端配置保持一致

    private DataChannel mDataChannel; // 与微端通信的数据通道,数据通道的生命周期应该和应用保持一致
    private Handler mHandler;
    private boolean isConnectSuccess; // 是否与微端连接成功
    private boolean isDebug; //debug下可以将收到的微端消息弹窗显示

    DataChannel.Listener listener = new DataChannel.Listener() {
        @Override
        public void onReceive(byte[] buffer, int len) {
            // 从监听的端口接收到数据
            String dataFromRemote = new String(buffer, 0, len);
            Log.d(TAG, "receive local data=" + dataFromRemote);
            // 收到微端发送的消息证明数据通道已经连接成功
            isConnectSuccess = true;

            try {
                JSONObject receiveData = new JSONObject(dataFromRemote);
                // 接收微端传递的debug参数
                if (!receiveData.isNull("debug")) {
                    isDebug = receiveData.getBoolean("debug");
                }

                // debug为true时弹窗显示收到的信息
                showDataForTest("[==receive==]:" + dataFromRemote);

                // 只有在收到微端发送的{"connect":true}消息之后，才能向微端发送消息
                if (!receiveData.isNull("connected") && receiveData.getBoolean("connected")) {
                    sendData("login");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onException(Exception e) {
            Log.e(TAG, "onException: " + e.getMessage());
            // 数据接收或发送过程中出现异常
        }
    };

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate: ");
        super.onCreate();
        mHandler = new Handler(Looper.getMainLooper());
        initDataChannel();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    /**
     * 初始化数据通道
     * 可重入
     */
    public void initDataChannel() {
        Log.i(TAG, "initDataChannel: ");
        if (mDataChannel == null) {
            mDataChannel = new DataChannel(listener, PORT);
            mDataChannel.open();
        }
    }

    /**
     * 通过此方法向发送方回复数据
     * 必须在数据通道连接成功后使用
     * 必须在工作线程中使用
     *
     * @param data 要发送的数据
     */
    public void sendData(String data) {
        if (!isConnectSuccess) {
            Log.e(TAG, "micro app not connect");
            return;
        }

        if (mDataChannel == null) {
            Log.e(TAG, "dataChannel is null");
        }

        Log.d(TAG, "sendData to local:" + data);
        // debug为true时，发送数据也弹窗
        showDataForTest("[==send==]:" + data);
        new Thread(new Runnable() {
            @Override
            public void run() {
                mDataChannel.send(data.getBytes(StandardCharsets.UTF_8));
            }
        }).start();
    }

    /**
     * 将收到的数据通过Toast弹出来
     *
     * @param data 数据
     */
    private void showDataForTest(String data) {
        if (!isDebug) {
            return;
        }
        Log.i(TAG, "showDataForTest: " + data);
        mHandler.post(() -> Toast.makeText(getApplicationContext(), data, Toast.LENGTH_SHORT).show());
    }
}

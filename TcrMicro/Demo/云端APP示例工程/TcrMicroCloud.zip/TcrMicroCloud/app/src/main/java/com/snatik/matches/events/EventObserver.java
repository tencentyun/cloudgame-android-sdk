package com.snatik.matches.events;

import com.snatik.matches.events.engine.FlipDownCardsEvent;
import com.snatik.matches.events.engine.GameWonEvent;
import com.snatik.matches.events.engine.HidePairCardsEvent;
import com.snatik.matches.events.ui.BackGameEvent;
import com.snatik.matches.events.ui.DifficultySelectedEvent;
import com.snatik.matches.events.ui.FlipCardEvent;
import com.snatik.matches.events.ui.NextGameEvent;
import com.snatik.matches.events.ui.ResetBackgroundEvent;
import com.snatik.matches.events.ui.StartEvent;
import com.snatik.matches.events.ui.ThemeSelectedEvent;


public interface EventObserver {

    void onEvent(FlipCardEvent event);

    void onEvent(DifficultySelectedEvent event);

    void onEvent(HidePairCardsEvent event);

    void onEvent(FlipDownCardsEvent event);

    void onEvent(StartEvent event);

    void onEvent(ThemeSelectedEvent event);

    void onEvent(GameWonEvent event);

    void onEvent(BackGameEvent event);

    void onEvent(NextGameEvent event);

    void onEvent(ResetBackgroundEvent event);

}

package com.snatik.matches;

import android.app.Service;
import android.content.Intent;
import android.os.Build.VERSION_CODES;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.widget.Toast;
import com.snatik.matches.utils.CommonUtil;
import com.tencent.cloud.DatagramSocketThread;
import com.tencent.cloud.DatagramSocketThread.Listener;
import java.io.IOException;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

public class SocketService extends Service {

    private static final String TAG = "SocketService";
    private static final int MSG_SHOW_TOAST = 0;
    private static final int MSG_STOP_SERVICE = 1;
    private DatagramSocketThread mSocketThread;
    private Handler mHandler;

    DatagramSocketThread.Listener listener = new Listener() {
        @RequiresApi(api = VERSION_CODES.KITKAT)
        public void onReceive(byte[] buffer, int len) {
            // 从监听的端口接收到数据
            String dataFromRemote = new String(buffer, 0, len);
            Log.d(TAG, "receive local data=" + dataFromRemote);

            sendData(dataFromRemote);

            Message message = Message.obtain();
            message.what = MSG_SHOW_TOAST;
            message.obj = dataFromRemote;
            mHandler.sendMessage(message);
        }

        public void onException(Exception e) {
            Log.e(TAG, "onException: " + e.getMessage());
            // 数据接收或发送过程中出现异常
            // TODO 处理异常
        }
    };

    /**
     * 我们用是否设置了端口作为是否启动服务的依据
     *
     * @return true 如果能够解析出来端口号
     */
    public static boolean enable() {
        return getUdpPortFromProperty() > 0;
    }

    /**
     * 返回设置的udp端口
     *
     * @return udp端口,　测试写死为6666
     */
    public static int getUdpPortFromProperty() {
        return 6666;
    }

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate: ");
        super.onCreate();
        mHandler = new ServiceHandler();
        if (!enable()) {
            Log.i(TAG, "disable SocketService.");
            return;
        }

        mSocketThread = new DatagramSocketThread(listener, getUdpPortFromProperty());
        mSocketThread.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mSocketThread.closeSocket();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * 通过此方法向发送方回复数据
     * 必须在数据通道连接成功后使用
     *
     * @param data 要发送的数据
     */
    @RequiresApi(api = VERSION_CODES.KITKAT)
    public void sendData(String data) {
        if (mSocketThread != null) {
            Log.d(TAG, "sendData to local:" + data);
            mSocketThread.sendData(data.getBytes(StandardCharsets.UTF_8));
        }
    }

    private final class ServiceHandler extends Handler {

        @RequiresApi(api = VERSION_CODES.KITKAT)
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SHOW_TOAST:
                    Toast.makeText(getApplicationContext(), (String) msg.obj, Toast.LENGTH_SHORT).show();
                    break;
                case MSG_STOP_SERVICE:
                    stopSelf();
                    break;
                default:
                    break;
            }

        }
    }
}

package com.tencent.datachanneltest;

import android.util.Log;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private DatagramSocket socket;
    private boolean isConnectSuccess;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button testButton = findViewById(R.id.test);

        try {
            socket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }

        byte[] buf = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(buf, 1024);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        socket.receive(receivePacket);
                        String dataFromRemote = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        Log.d(TAG, "local receive data form cloud=" + dataFromRemote);
                        onReceiveCloudGameMessage(dataFromRemote);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

        testButton.setOnClickListener(v -> {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    onDataChannelConnectSuccess();
                }
            }).start();
        });
    }

    private void onDataChannelConnectSuccess() {
        Log.i(TAG, "onDataChannelConnectSuccess: ");
        isConnectSuccess = true;
        setDebugMode(true);
        sendConnectMsg();
    }

    private void onReceiveCloudGameMessage(String data) {
        Log.i(TAG, "onReceiveCloudGameMessage: " + data);
        if ("login".equals(data)) {
            // 开始登录
            // ......

            // 登录成功后
            sendLoginCall("123456");
        }
    }

    //向云端发送链接成功
    private void sendConnectMsg() {
        Log.d(TAG, "sendConnectMsg");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("connected", true);
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            Log.e(TAG, "sendConnectMsg exception, " + e.getMessage());
        }
    }

    private void setDebugMode(boolean isDebug) {
        Log.d(TAG, "setDebugMode:" + isDebug);
        try {
            JSONObject jsonObject = new JSONObject();
            // 测试的云端apk中收到该字段为true，则会在云端将收到的信息通过Toast显示出来，方便调试
            // 客户也可以在自己的云端包中新增一个类似的开关，把收到的微端包信息show出来
            jsonObject.put("debug", isDebug);
            sendDataToCloudGame(jsonObject.toString());
        } catch (Exception e) {
            Log.e(TAG, "sendConnectMsg exception, " + e.getMessage());
        }
    }

    // 向云端发送登录回调,在登录成功后调用
    private void sendLoginCall(String authCode) {
        if (!isConnectSuccess) {
            Log.d(TAG, "未连接成功，不能向云端发送登录回调");
            return;
        }
        Log.d(TAG, "向云端发送登录回调");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("auth_code", authCode);
            sendDataToCloudGame(jsonObject.toString());
        } catch (JSONException e) {
            Log.e(TAG, "sendLoginCall exception, " + e.getMessage());
        }
    }

    private void sendDataToCloudGame(String testData) {
        Log.d(TAG, "sendDataToCloud: " + testData);
        try {
            InetAddress address = InetAddress.getByName("localhost");
            byte[] buf = testData.getBytes(StandardCharsets.UTF_8);
            DatagramPacket sendPacket = new DatagramPacket(buf, buf.length, address, 6666);
            socket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
package com.tencent.datachanneltest;

import android.util.Log;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private DatagramSocket socket;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button testButton = findViewById(R.id.test);

        try {
            socket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }

        byte[] buf = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(buf, 1024);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        socket.receive(receivePacket);
                        String dataFromRemote = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        Log.d(TAG, "local receive data form cloud=" + dataFromRemote);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

        testButton.setOnClickListener(v -> {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String testData = "testData";
                        InetAddress address = InetAddress.getByName("localhost");
                        DatagramPacket sendPacket = new DatagramPacket(testData.getBytes(Charset.forName("UTF-8")),
                                testData.length(), address, 6666);
                        socket.send(sendPacket);
                        Log.d(TAG, "local send data:" + testData);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        });

    }
}
package com.DefaultCompany.Unity2018Empty;

import android.app.Application;

public class MyApplication extends Application {

}

package com.DefaultCompany.Unity2018Empty;

import android.app.Application;
import android.util.Log;
import java.io.IOException;

public class MyApplication extends Application {

    private static final String TAG = "MyApplication";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(TAG, "onCreate: ClassLoader name is " + getClassLoader().getClass().getName());
        // 1、use getClassLoader().getResourceAsStream
        Log.e(TAG, "onCreate: use getClassLoader().getResourceAsStream, " + getClassLoader()
                .getResource("assets/Test.xml"));
        // 2、use getClass().getResourceAsStream
        Log.e(TAG,
                "onCreate: use getClass().getResourceAsStream, " + getClass().getResource("/assets/Test.xml"));
        // 3、use getAssets().open
        try {
            Log.e(TAG, "onCreate: use getAssets().open, " + getAssets().open("Test.xml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
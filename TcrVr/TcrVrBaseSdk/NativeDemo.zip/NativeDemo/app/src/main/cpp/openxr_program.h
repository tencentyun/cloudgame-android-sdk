// Copyright (c) 2017-2022, The Khronos Group Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <jni_wrap/com.tencent.tcr.xr.api.tcr_activity.h>
#include <jni_wrap/com.tencent.tcr.xr.api.tcr_videoFrame.h>
#include "common.h"
#include "interaction_manager.h"
#include "pch.h"
#include "platformdata.h"

struct IOpenXrProgram {
  enum class AndroidThreadType : std::int32_t { AppMain = 1, AppWorker = 2, RendererMain = 3, RendererWorker = 4 };

  virtual ~IOpenXrProgram() = default;

  // 创建实例并且完成实例相关的初始化。
  virtual void CreateInstance() = 0;

  // 初始化OpenXR System(并使用获取到的systemId初始化IGraphicsPlugin)。
  // 备注：一个OpenXR System包括VR/AR显示器设备和各种形式的输入，初始化这里会对这些设备和输入做一些配置。
  virtual void InitSystem() = 0;

  // 创建会话并且完成会话相关的初始化。
  virtual void InitSession() = 0;

  // 处理OpenXR消息队列里的事件。
  virtual void PollEvents(bool *exitRenderLoop, bool *requestRestart) = 0;

  // 返回当前会话是否正在运行(状态是XR_SESSION_STATE_READY)
  // 只有在XR_SESSION_STATE_READY状态下才能够绘制视频帧。
  virtual bool IsSessionRunning() const = 0;

  // 返回当前会话是否是被聚焦的。
  // 只有被聚焦的会话才能够获取到输入事件，这个时候去获取输入事件才有意义。
  virtual bool IsSessionFocused() const = 0;

  virtual bool IsInitializationStart() const = 0;

  // 获取手柄事件。
  virtual Json::Value GetControllerEvents() = 0;

  // 创建并提交一帧画面进行渲染。
  virtual void RenderFrame() = 0;

  virtual void UpdateVrInfo() = 0;

  virtual void SetVideoFrame(wrap::tcr::xr::VideoFrame &&) = 0;

  // 更新位姿信息
  virtual Json::Value GetHmdTrackingInfo() = 0;

  // 初始化扩展API
  virtual void InitExtensions() = 0;

  virtual void InitJsonWriter() = 0;

  // 创建并提交一帧画面进行渲染。
  virtual void Destroy() = 0;

  virtual void UpdateLobbyText(const unsigned char *data) = 0;
  virtual void StreamInit(int32_t width, int32_t height) = 0;
  virtual void HandleMessage(std::string type, std::string data) = 0;
};

std::shared_ptr<IOpenXrProgram> CreateOpenXrProgram(const std::shared_ptr<PlatformData> &platformData,
                                                    const std::shared_ptr<wrap::tcr::xr::TcrActivity> &tcrActivity);
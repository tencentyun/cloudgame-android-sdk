//
// Created by cyy on 2022/9/8.
//

#pragma once
namespace wrap {
namespace tcr {
namespace xr {

inline java::lang::ClassLoader TcrActivity::getClassLoader() {
  assert(!isNull());
  return java::lang::ClassLoader(object().call<jni::Object>(Meta::data().getClassLoader));
}

inline void TcrActivity::onEvent(const std::string &type, const std::string &msg) {
  assert(!isNull());
  object().call<void>(Meta::data().onEvent, type, msg);
}

inline std::uint64_t TcrActivity::getGLSharedContext() {
  assert(!isNull());
  long long value = object().call<long long>(Meta::data().getGLSharedContext);
  return value;
}

inline VideoFrame TcrActivity::getVideoFrame() {
  assert(!isNull());
  return VideoFrame(object().call<jni::Object>(Meta::data().getVideoFrame));
}

}  // namespace xr
}  // namespace tcr
}  // namespace wrap
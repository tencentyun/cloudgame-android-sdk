//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "ObjectWrapperBase.h"
#include "com.tencent.tcr.xr.api.bean.math_quaternion4f.h"
#include "com.tencent.tcr.xr.api.bean.math_vector3f.h"

namespace wrap::tcr::xr {
class Pose : public ObjectWrapperBase {
 public:
  using ObjectWrapperBase::ObjectWrapperBase;
  static constexpr const char *getTypeName() noexcept { return "com/tencent/tcr/xr/api/bean/math/Pose"; }

  /*!
   * Wrapper for the getPosition method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Pose.getPosition()函数，
   *
   * Java prototype:
   * `public com.tencent.tcr.xr.api.bean.math.Vector3f getPosition();`
   *
   * JNI signature: descriptor: ()Lcom/tencent/tcr/xr/api/bean/math/Vector3f;
   *
   */
  inline Vector3f getPosition() { return Vector3f(object().call<jni::Object>(Meta::data(object().getClass()).getPosition));}

  /*!
   * Wrapper for the getOrientation method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Pose.getOrientation()函数，
   *
   * Java prototype:
   * `public com.tencent.tcr.xr.api.bean.math.Quaternion4f getOrientation();`
   *
   * JNI signature: descriptor: ()Lcom/tencent/tcr/xr/api/bean/math/Quaternion4f;
   *
   */
  inline Quaternion4f getOrientation() { return Quaternion4f(object().call<jni::Object>(Meta::data(object().getClass()).getOrientation));}

  /*!
   * Class metadata
   */
  struct Meta : public MetaBaseDroppable {
    jni::method_t getPosition;
    jni::method_t getOrientation;

      static Meta &data(jni::jclass clazz) {
        static Meta instance{clazz};
        return instance;
      }

   private:
      explicit Meta(jni::jclass clazz);
  };
};

}  // namespace wrap::tcr::xr
//
// Created by cyy on 2022/9/8.
//

#include "com.tencent.tcr.xr.api.tcr_activity.h"
namespace wrap::tcr::xr {
TcrActivity::Meta::Meta(jni::jclass clazz)
    : MetaBaseDroppable(getTypeName(), clazz),
      getClassLoader(classRef().getMethod("getClassLoader", "()Ljava/lang/ClassLoader;")),
      onEvent(classRef().getMethod("onEvent", "(Ljava/lang/String;Ljava/lang/String;)V")),
      getGLSharedContext(classRef().getMethod("getGLSharedContext", "()J")){
  MetaBaseDroppable::dropClassRef();
}

}  // namespace wrap::tcr::xr
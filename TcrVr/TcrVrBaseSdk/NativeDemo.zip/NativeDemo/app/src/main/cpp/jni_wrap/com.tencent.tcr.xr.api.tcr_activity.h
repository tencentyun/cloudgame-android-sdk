//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "ObjectWrapperBase.h"
#include "com.tencent.tcr.xr.api.tcr_videoFrame.h"
#include "java.lang.h"

namespace wrap::tcr::xr {
class TcrActivity : public ObjectWrapperBase {
 public:
  using ObjectWrapperBase::ObjectWrapperBase;
  static constexpr const char *getTypeName() noexcept { return "com/tencent/tcr/xr/TcrActivity"; }

  /*!
   * Wrapper for the getClassLoader method
   *
   * Java prototype:
   * `public void getClassLoader();`
   *
   * JNI signature: ()Ljava/lang/ClassLoader;
   *
   */
  java::lang::ClassLoader getClassLoader();

  /*!
   * Wrapper for the onEvent method
   *
   * Java prototype:
   * `public void onEvent(java.lang.String, java.lang.String);`
   *
   * JNI signature: (Ljava/lang/String;Ljava/lang/String;)V
   *
   */
  void onEvent(std::string const &type, std::string const &msg);

  /*!
   * Wrapper for the getGLSharedContext method
   *
   * Java prototype:
   * `public long getGLSharedContext();`
   *
   * JNI signature: ()J
   *
   */
  std::uint64_t getGLSharedContext();

  /*!
   * Wrapper for the getVideoFrame method
   *
   * Java prototype:
   * `public com.tencent.tcr.xr.VideoFrame getVideoFrame();`
   *
   * JNI signature: ()Lcom/tencent/tcr/xr/VideoFrame;
   *
   */
  VideoFrame getVideoFrame();

  /*!
   * Initialize the static metadata of this wrapper with a known
   * (non-null) Java class.
   */
  static void staticInitClass(jni::jclass clazz) { Meta::data(clazz); }

  /*!
   * Class metadata
   */
  struct Meta : public MetaBaseDroppable {
    jni::method_t getClassLoader;
    jni::method_t onEvent;
    jni::method_t getGLSharedContext;
    jni::method_t getVideoFrame;

    /*!
     * Singleton accessor
     */
    static Meta &data(jni::jclass clazz = nullptr) {
      static Meta instance{clazz};
      return instance;
    }

   private:
    explicit Meta(jni::jclass clazz);
  };
};

}  // namespace wrap::tcr::xr
#include "com.tencent.tcr.xr.tcr_activity.impl.h"
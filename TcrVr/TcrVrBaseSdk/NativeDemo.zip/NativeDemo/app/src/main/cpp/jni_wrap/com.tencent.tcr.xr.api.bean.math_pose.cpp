//
// Created by cyy on 2022/9/8.
//

#include "com.tencent.tcr.xr.api.bean.math_pose.h"
namespace wrap::tcr::xr {

Pose::Meta::Meta(jni::jclass clazz)
    : MetaBaseDroppable(getTypeName(), clazz),
      getPosition(classRef().getMethod("getPosition", "()Lcom/tencent/tcr/xr/api/bean/math/Vector3f")),
      getOrientation(classRef().getMethod("getOrientation", "()Lcom/tencent/tcr/xr/api/bean/math/Quaternion4f")){
    MetaBaseDroppable::dropClassRef();
}

}  // namespace wrap::tcr::xr
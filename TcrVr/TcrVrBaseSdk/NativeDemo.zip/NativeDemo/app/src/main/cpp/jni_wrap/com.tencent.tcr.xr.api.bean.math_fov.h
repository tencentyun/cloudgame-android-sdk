//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "ObjectWrapperBase.h"

namespace wrap::tcr::xr {
class Fov : public ObjectWrapperBase {
 public:
  using ObjectWrapperBase::ObjectWrapperBase;
  static constexpr const char *getTypeName() noexcept { return "com/tencent/tcr/xr/api/bean/math/Fov"; }

  /*!
   * Wrapper for the getBottom method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Fov.getBottom()函数，
   *
   * Java prototype:
   * `public float getBottom();`
   *
   * JNI signature: descriptor: ()F
   *
   */
  inline float getBottom() {
      return object().call<float>(Meta::data(object().getClass()).getBottom);
  }

  /*!
   * Wrapper for the getLeft method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Fov.getLeft()函数，
   *
   * Java prototype:
   * `public float getLeft();`
   *
   * JNI signature: descriptor: ()F
   *
   */
  inline float getLeft() { return object().call<float>(Meta::data(object().getClass()).getLeft); }

  /*!
   * Wrapper for the getRight method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Fov.getRight()函数，
   *
   * Java prototype:
   * `public float getRight();`
   *
   * JNI signature: descriptor: ()F
   *
   */
  inline float getRight() { return object().call<float>(Meta::data(object().getClass()).getRight); }

  /*!
   * Wrapper for the getTop method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Fov.getTop()函数，
   *
   * Java prototype:
   * `public float getTop();`
   *
   * JNI signature: descriptor: ()F
   *
   */
  inline float getTop() { return object().call<float>(Meta::data(object().getClass()).getTop); }

  /*!
   * Class metadata
   */
  struct Meta : public MetaBaseDroppable {
    jni::method_t getBottom;
    jni::method_t getLeft;
    jni::method_t getRight;
    jni::method_t getTop;

    static Meta &data(jni::jclass clazz) {
      static Meta instance{clazz};
      return instance;
    }

   private:
    explicit Meta(jni::jclass clazz);
  };
};

}  // namespace wrap::tcr::xr
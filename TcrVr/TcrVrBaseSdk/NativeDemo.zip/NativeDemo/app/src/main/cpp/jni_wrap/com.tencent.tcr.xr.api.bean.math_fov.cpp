//
// Created by cyy on 2022/9/8.
//

#include "com.tencent.tcr.xr.api.bean.math_fov.h"
namespace wrap::tcr::xr {

Fov::Meta::Meta(jni::jclass clazz)
    : MetaBaseDroppable(getTypeName(), clazz),
      getBottom(classRef().getMethod("getBottom", "()F")),
      getLeft(classRef().getMethod("getLeft", "()F")),
      getTop(classRef().getMethod("getTop", "()F")),
      getRight(classRef().getMethod("getRight", "()F")) {
    MetaBaseDroppable::dropClassRef();
}

}  // namespace wrap::tcr::xr
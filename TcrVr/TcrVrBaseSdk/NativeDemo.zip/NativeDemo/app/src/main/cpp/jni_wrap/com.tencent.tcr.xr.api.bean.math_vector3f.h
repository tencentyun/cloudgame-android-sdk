//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "ObjectWrapperBase.h"

namespace wrap::tcr::xr {
class Vector3f : public ObjectWrapperBase {
 public:
  using ObjectWrapperBase::ObjectWrapperBase;
  static constexpr const char *getTypeName() noexcept { return "com/tencent/tcr/xr/api/bean/math/Vector3f"; }

  /*!
   * Wrapper for the getX method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Vector3f.getX()函数，
   *
   * Java prototype:
   * `public double getX();`
   *
   * JNI signature: descriptor: ()D
   *
   */
  inline double getX() { return object().call<float>(Meta::data(object().getClass()).getX); }

  /*!
   * Wrapper for the getY method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Vector3f.getY()函数，
   *
   * Java prototype:
   * `public double getY();`
   *
   * JNI signature: descriptor: ()D
   *
   */
  inline double getY() { return object().call<float>(Meta::data(object().getClass()).getY); }

  /*!
   * Wrapper for the getZ method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.api.bean.math.Vector3f.getZ()函数，
   *
   * Java prototype:
   * `public double getZ();`
   *
   * JNI signature: descriptor: ()D
   *
   */
  inline double getZ() { return object().call<float>(Meta::data(object().getClass()).getZ); }

  /*!
   * Class metadata
   */
  struct Meta : public MetaBaseDroppable {
    jni::method_t getX;
    jni::method_t getY;
    jni::method_t getZ;

    static Meta &data(jni::jclass clazz) {
      static Meta instance{clazz};
      return instance;
    }

   private:
    explicit Meta(jni::jclass clazz);
  };
};

}  // namespace wrap::tcr::xr
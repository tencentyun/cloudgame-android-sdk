// Copyright (c) 2017-2022, The Khronos Group Inc.
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#define LogD(...) Log::Write(Log::Level::Debug, __VA_ARGS__)
#define LogV(...) Log::Write(Log::Level::Verbose, __VA_ARGS__)
#define LogI(...) Log::Write(Log::Level::Info, __VA_ARGS__)
#define LogW(...) Log::Write(Log::Level::Warning, __VA_ARGS__)
#define LogE(...) Log::Write(Log::Level::Error, __VA_ARGS__)

namespace Log {
// 定义日志级别枚举
// 需要确保对应的整数值和android.util.Log中定义的日志级别取值相同, 例如Verbose的值就是Log.VERBOSE
enum class Level { Verbose = 2, Debug, Info, Warning, Error };

void SetLevel(Level minSeverity);
void Write(Level severity, const char* fmt, ...);

}  // namespace Log

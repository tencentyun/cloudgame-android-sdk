#pragma once

#include <string>
#include <array>
#include <vector>

typedef struct FfiOrientation {
    float    x;
    float    y;
    float    z;
    float    w;
} FfiOrientation;

typedef struct FfiPosition {
    float    x;
    float    y;
    float    z;
} FfiPosition;

struct FfiViewInput {
    unsigned int swapchainIndex;
    FfiOrientation orientation;
    FfiPosition position;
    float fovLeft;
    float fovRight;
    float fovUp;
    float fovDown;
};

struct FfiStreamConfig {
    unsigned int viewWidth;
    unsigned int viewHeight;
    std::array<std::vector<uint32_t>, 2> swapchainTextures;
};

void initGraphics(const std::string &xrAssetPath);
void destroyGraphics();
void prepareLobbyRoom(uint32_t viewWidth, uint32_t viewHeight, std::array<std::vector<uint32_t>, 2> swapchainTextures);
void destroyRenderers();
void streamStart(FfiStreamConfig config);
void updateLobbyHudTexture(const unsigned char *data);
void renderLobby(std::array<const FfiViewInput, 2> eyeInputs);
void renderStream(std::uint64_t textureId, std::array<uint32_t, 2> swapchainIndices);
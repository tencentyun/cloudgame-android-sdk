# Tencent CloudXR Client Unity Plugin Third-Party Notices

Tencent CloudXR Client Unity Plugin includes or makes use of the following
software, subject to their respective licenses:

-   TcrVrBaseSdk
    -   License and 3rd party notices are included in the NativeDemo.zip package provided.

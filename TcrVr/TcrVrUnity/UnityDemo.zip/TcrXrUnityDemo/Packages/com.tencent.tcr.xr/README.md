# Tencent CloudXR Client Unity Plugin

Enables a Unity VR application to receive a CloudXR stream from a Tencent Real-Time Cloud Rendering backend. (for now, Quest-only)

## Description

This Unity plugin allows you to integrate Tencent CloudXR into your VR application. It enables your application to receive a CloudXR stream from a Tencent Real-Time Cloud Rendering backend. Currently, this plugin is only compatible with the Oculus Quest.

## Usage

To use this plugin, follow the steps below:

Please refer to this document:
https://github.com/tencentyun/cloudgame-android-sdk/blob/tcrvr-base/TcrVr/TcrVrUnity/%E8%85%BE%E8%AE%AF%E4%BA%91%E6%B8%B2%E6%9F%93VR%20Unity%E6%8E%A5%E5%85%A5%E6%8C%87%E5%8D%97.md
# Changelog

All notable changes to the project will be documented in this file.

## [0.0.1] - 2024-04-29

Supports sending controller events to the cloud server and rendering streaming frame.

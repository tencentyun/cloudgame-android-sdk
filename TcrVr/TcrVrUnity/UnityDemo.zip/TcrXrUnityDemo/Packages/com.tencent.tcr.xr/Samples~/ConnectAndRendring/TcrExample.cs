using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

using TCR;
using UnityEngine.UI;


public class TcrExample : MonoBehaviour
{
    private static readonly string TAG = "TcrExample";
    private TcrXrManager m_tcrXrManager = null;

    public string m_ExperienceCode;
    public Canvas m_Canvas;
    private TMPro.TextMeshProUGUI m_Text;

    void Start()
    {
        m_tcrXrManager = Camera.main.GetComponent<TcrXrManager>();
        if (m_tcrXrManager == null) {
            Log.E(TAG, "TcrXrManager is not attached to the main camera");
            return;
        }
        m_tcrXrManager.onInitedSdk += OnInitedSdk;

        
        if (m_Canvas == null)  {
            Log.W(TAG, "TcrExample: No Canvas found!, auto connect.");
            OnClickInitSdk();
            return;
        }

        Button btn = m_Canvas.GetComponentInChildren<Button>();
        if (btn == null || btn.name != "StartBtn") {
            Log.W(TAG, "TcrExample: No Button(with name: StartBtn) found in Canvas, auto connect.");
            OnClickInitSdk();
        } else {
            btn.onClick.AddListener(OnClickInitSdk);
        }

        // 获取Canvas及其子对象上的所有组件
        Component[] components = m_Canvas.GetComponentsInChildren<Component>(true);

        // 遍历并找到名为msgText的TextMeshProUGUI组件
        foreach (Component component in components)
        {
            if (component.name == "msgText") {
                m_Text = component as TMPro.TextMeshProUGUI;
            }
        }
    }

    public void OnClickInitSdk() {
        Log.I(TAG, "OnClickInitSdk()");
        if (m_tcrXrManager != null) {
            m_tcrXrManager.StartInitTcrXrSdk();
        }
    }

    private IEnumerator SendHttpPostRequest(string url, string json)
    {
        using UnityWebRequest request = new(url, "POST");
        Log.I(TAG, $"SendHttpPostRequest Post: {json} to {url}");

        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.ConnectionError || request.result == UnityWebRequest.Result.ProtocolError)
        {
            Log.E(TAG, $"SendHttpPostRequest Error: {request.error}");
            ShowMsg($"Request {url} Error: {request.error}");
        }
        else
        {
            string responseText = request.downloadHandler.text;
            Log.I(TAG, $"SendHttpPostRequest response: {responseText}");
            GameStartResp response = JsonUtility.FromJson<GameStartResp>(responseText);

            if (response.Code == 0)
            {
                ShowMsg("Got ServerSession, Connecting...");
                m_tcrXrManager.StartSession(response.ServerSession);
            } else {
                ShowMsg($"Reqeust ServerSession failed Code: {response.Code} Msg: {response.Message}");
            }
        }
    }

    private void ShowMsg(string msg) {
        if (m_Text != null) {
            m_Text.text = msg;
        }
    }

    public void OnInitedSdk(string clientSession) {
        Log.I(TAG, $"OnInitedSdk clientSession: {clientSession}");
        ShowMsg("init success\nrequesting Server Session...");

        string experienceCode = String.IsNullOrEmpty(m_ExperienceCode) ? "662GPS54" : m_ExperienceCode;

        // 创建GameStartParam对象并设置属性
        GameStartParam requestData = new GameStartParam
        {
            ExperienceCode = experienceCode,
            UserId = "unit_test",
            ClientSession = clientSession
        };
        // 发起HTTP POST请求: 创建会话
        try
        {
            CoroutineRunner.Instance.StartCoroutine(SendHttpPostRequest("https://code.cloud-gaming.myqcloud.com/CreateExperienceSession", JsonUtility.ToJson(requestData)));
        } catch(Exception e) {
            Log.E(TAG, $"StartCoroutine faild, e: {e.Message}");
        }
    }

    void Update() {}
}

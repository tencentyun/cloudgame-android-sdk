using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

using TCR;

internal class TcrBlitPass : ScriptableRenderPass
{
    private static readonly string TAG = "TcrBlitPass";
    readonly Material m_Material;

    private RTHandle m_CameraColorTarget;

    public TcrBlitPass(Material material)
    { 
        m_Material = material;
        renderPassEvent = RenderPassEvent.AfterRendering;
    }

    public void SetTarget(RTHandle colorHandle)
    {
        m_CameraColorTarget = colorHandle;
    }

    // ========================================================================
    // This is needed to ensure our pass uses the right render target.
    public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
    {
        ConfigureTarget(m_CameraColorTarget);
    }

    private Texture2D lastTexture;

    private Quaternion mLastOrientation;

    private TcrXrManager xrManager;
    private readonly MaterialPropertyBlock m_PropertyBlock = new();

        
    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        var camera = renderingData.cameraData.camera;
        if (camera.cameraType != CameraType.Game)
            return;
            
        if (!camera.TryGetComponent<TcrXrManager>(out xrManager)) {
            Log.D(TAG, "TcrBlitPass: No TcrXrManager found on camera!");
            return;
        }

        if (!xrManager.IsSdkInitilazed()) {
            return;
        }

        Texture2D texture;
        VideoFrame theFrame = xrManager.getLastFrame();
        Quaternion orientationInUnity;
        if (theFrame == null) {
            texture = lastTexture;
            orientationInUnity = mLastOrientation;
        } else {
            texture = 
                Texture2D.CreateExternalTexture((int)theFrame.getWidth(), (int)theFrame.getHeight(), TextureFormat.RGBA32, false, false, new System.IntPtr(theFrame.updateTexture()));
            lastTexture = texture;

            Quaternion4f orientation = theFrame.getPose().getOrientation();
            /*
            Unity is Left-Handed, Y-Up, "unity units" (typically 1 uu = 1 m)
                https://www.techarthub.com/a-guide-to-unitys-coordinate-system-with-practical-examples/
                +y is up
                +x is right
                +z is forward
            OpenXR uses a right-handed system, where:
                    +y is up
                    +x is to the right
                    -z is forward
                Distance units are in meters.
                
            Transformation Relationship: 
                https://zhuanlan.zhihu.com/p/563410654
            */
            orientationInUnity = new Quaternion(-orientation.getX(), -orientation.getY(), orientation.getZ(), orientation.getW());
            mLastOrientation = orientationInUnity;
        }
        if (texture == null) { 
            Log.D(TAG, "TcrBlitPass Execute() texture=null"); 
            return;
        }

        m_Material.SetMatrix("_StreamingRotation", Matrix4x4.TRS(Vector3.zero, orientationInUnity, Vector3.one));
        m_Material.SetTexture("_EyeTex", texture);
        CommandBuffer cmd = CommandBufferPool.Get();
        cmd.DrawMesh(RenderingUtils.fullscreenMesh, Matrix4x4.identity, m_Material, 0, -1, m_PropertyBlock);
        context.ExecuteCommandBuffer(cmd); 
        cmd.Clear();
        CommandBufferPool.Release(cmd);

        if (theFrame != null) {
            theFrame.release();
        }
        
    }
}
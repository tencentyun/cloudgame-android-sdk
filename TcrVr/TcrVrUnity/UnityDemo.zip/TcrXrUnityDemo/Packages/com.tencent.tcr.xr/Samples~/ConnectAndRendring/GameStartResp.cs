
[System.Serializable]
public class GameStartResp
{
    public int Code;
    public string Message;
    public string ServerSession;
    public long AppId;
}
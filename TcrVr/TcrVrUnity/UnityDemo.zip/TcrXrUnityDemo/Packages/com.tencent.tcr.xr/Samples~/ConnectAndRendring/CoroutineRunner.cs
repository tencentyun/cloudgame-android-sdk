using UnityEngine;

// 为什么需要这个类?
// 当你直接在一个MonoBehaviour的类中调用StartCoroutine时，协程将在该MonoBehaviour所附加的游戏对象上执行。然而，如果该MonoBehaviour所附加的游戏对象在某个时间点被销毁或禁用，协程将停止执行。
// 为了避免这个问题，我们过实现一个CoroutineRunner类，并将其附加到一个不会被销毁或禁用的游戏对象上，你可以确保协程的执行不会受到其他对象的影响。
public class CoroutineRunner : MonoBehaviour
{
    private static CoroutineRunner _instance;

    public static CoroutineRunner Instance
    {
        get
        {
            if (_instance == null)
            {
                GameObject coroutineRunnerObject = new GameObject("CoroutineRunner");
                _instance = coroutineRunnerObject.AddComponent<CoroutineRunner>();
                DontDestroyOnLoad(coroutineRunnerObject);
            }
            return _instance;
        }
    }
}


[System.Serializable]
public class GameStartParam
{
    public string ExperienceCode;
    public string UserId;
    public string RequestId;
    public string ClientSession;
}
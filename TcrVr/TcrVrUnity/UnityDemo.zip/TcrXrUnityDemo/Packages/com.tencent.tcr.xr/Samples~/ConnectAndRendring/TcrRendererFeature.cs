using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

internal class TcrRendererFeature : ScriptableRendererFeature
{
    public Shader m_Shader;

    Material m_Material;

    TcrBlitPass m_RenderPass;

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    { 
        if (renderingData.cameraData.cameraType == CameraType.Game)
        {
            renderer.EnqueuePass(m_RenderPass);
        }
    }

#if UNITY_2022_1_OR_NEWER
    public override void SetupRenderPasses(ScriptableRenderer renderer, in RenderingData renderingData)
    {
        if (renderingData.cameraData.cameraType == CameraType.Game)
        {
            m_RenderPass.SetTarget(renderer.cameraColorTargetHandle);
        }
    }
#endif

    public override void Create()
    {
        m_Material = new Material(m_Shader);
        m_RenderPass = new TcrBlitPass(m_Material);
    }

    protected override void Dispose(bool disposing)
    {
        CoreUtils.Destroy(m_Material);
    }
}
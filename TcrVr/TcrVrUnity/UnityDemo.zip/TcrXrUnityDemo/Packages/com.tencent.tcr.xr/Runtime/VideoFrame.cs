using UnityEngine;
[System.Serializable]
public class VideoFrame
{
    public AndroidJavaObject javaVideoFrame;
    public Pose pose;
    public VideoFrame(AndroidJavaObject javaVideoFrame) 
    {
        this.javaVideoFrame = javaVideoFrame;

        using(AndroidJavaObject javaObjPose = javaVideoFrame.Call<AndroidJavaObject>("getPose"),
            javaObjPosition = javaObjPose.Call<AndroidJavaObject>("getPosition"),
            javaObjOrientation = javaObjPose.Call<AndroidJavaObject>("getOrientation")) {
                Vector3f position = new((float)javaObjPosition.Call<double>("getX"), (float)javaObjPosition.Call<double>("getY"), (float)javaObjPosition.Call<double>("getZ"));
                Quaternion4f orientation = new((float)javaObjOrientation.Call<double>("getX"), (float)javaObjOrientation.Call<double>("getY"), (float)javaObjOrientation.Call<double>("getZ"), (float)javaObjOrientation.Call<double>("getW"));
                pose = new Pose(position, orientation);
            }

    }

    public long updateTexture() {
        return javaVideoFrame.Call<long>("updateTexture");
    }

    public long getWidth() {
        return javaVideoFrame.Call<long>("getWidth");
    }

    public long getHeight() {
        return javaVideoFrame.Call<long>("getHeight");
    }

    public void retain() {
        javaVideoFrame.Call("retain");
    }

    public void release() {
        javaVideoFrame.Call("release");
        javaVideoFrame.Dispose();
        javaVideoFrame = null;
    }

    public Pose getPose() {
        return this.pose;
    }
}
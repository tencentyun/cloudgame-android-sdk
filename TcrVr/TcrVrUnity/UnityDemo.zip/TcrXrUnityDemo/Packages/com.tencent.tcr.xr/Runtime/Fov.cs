namespace TCR
{
    /**
    * 视场角。
    */
    public class Fov
    {
        /**
        * 单眼屏幕正中间往下偏移的角度，单位是弧度。
        */
        public float bottom;
        /**
        * 单眼屏幕正中间往左偏移的角度，单位是弧度。
        */
        public float left;
        /**
        * 单眼屏幕正中间往右偏移的角度，单位是弧度。
        */
        public float right;
        /**
        * 单眼屏幕正中间往上偏移的角度，单位是弧度。
        */
        public float top;

        public Fov(float left, float right, float top, float bottom)
        {
            this.left = left;
            this.right = right;
            this.top = top;
            this.bottom = bottom;
        }

        public float GetBottom()
        {
            return bottom;
        }

        public float GetLeft()
        {
            return left;
        }

        public float GetRight()
        {
            return right;
        }

        public float GetTop()
        {
            return top;
        }
    }
}
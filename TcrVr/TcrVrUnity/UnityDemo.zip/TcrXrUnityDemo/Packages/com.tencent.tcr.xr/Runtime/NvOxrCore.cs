using System.Runtime.InteropServices;

using TCR;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;

namespace OXR {
    /* =================================================================================
       Code-generated section: "using" statements

       N.B. These only work within this file. To use this convenience name referrals, 
       this must be copy-pasted to each file using it.
       ================================================================================= */
        using XrAction = System.UInt64;
        using XrActionSet = System.UInt64;
        using XrBool32 = System.UInt32;
        using XrFlags64 = System.UInt64;
        using XrInstance = System.UInt64;
        using XrPath = System.UInt64;
        using XrSession = System.UInt64;
        using XrSpace = System.UInt64;
        using XrSpaceLocationFlags = System.UInt64;
        using XrSpaceVelocityFlags = System.UInt64;
        using XrSystemId = System.UInt64;
        using XrTime = System.Int64;
        using XrVersion = System.UInt64;
        using XrViewStateFlags = System.UInt64;


     /* =================================================================================
       Hand-crafted section: Fixed-length string marshalling
       ================================================================================= */

   // In order to marshall fixed-size, inline, by-value character arrays of UTF-8 null-terminated strings,
    // we need some structure.
    public interface IFixedLengthString
    {
        public int Size {get;}
        public string Value {get; set;}
    }
    public static class Helpers
    {
        public static string CheckDecodeFixedString(byte[] value) {
            if (value==null) {
                return "";
            } else {
                return System.Text.Encoding.UTF8.GetString(value).TrimEnd('\0');
            }
        }
        public static byte[] CheckEncodeFixedString(string source, int maxSize, byte[] target) {
            {
                byte[] result = target;
                var bytes = System.Text.Encoding.UTF8.GetBytes(source);
                int byteCount = bytes.Length;
                if (byteCount > (maxSize-1))
                {
                    throw new System.ArgumentException("String is too long in UTF-8!");
                }
                else
                {
                    if (result==null) {
                        result = new byte[maxSize];
                    }
                    System.Array.Copy(bytes, result, maxSize);
                    System.Array.Clear(result, bytes.Length, maxSize-bytes.Length);
                }
                return result;
            }             
        }
    }
    
    public struct OxrString256 : IFixedLengthString
    {
        // As the only public and/or explicitly MarshalAs'd **field**, this entire struct will
        // flatten to marshalling as this "value" member
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = _size)]
        private byte[] value;
        private const int _size = 256;

        public int Size { get => _size; }
        public string Value{
            get => Helpers.CheckDecodeFixedString(this.value);
            set => this.value = Helpers.CheckEncodeFixedString(value,_size,this.value);
        }
    }
    public struct OxrString128 : IFixedLengthString
    {
        // As the only public and/or explicitly MarshalAs'd **field**, this entire struct will
        // flatten to marshalling as this "value" member
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = _size)]
        private byte[] value;
        private const int _size = 128;

        public int Size { get => _size; }
        public string Value{
            get => Helpers.CheckDecodeFixedString(this.value);
            set => this.value = Helpers.CheckEncodeFixedString(value,_size,this.value);
        }
    }
    public struct OxrString64 : IFixedLengthString
    {
        // As the only public and/or explicitly MarshalAs'd **field**, this entire struct will
        // flatten to marshalling as this "value" member
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = _size)]
        private byte[] value;
        private const int _size = 64;

        public int Size { get => _size; }
        public string Value{
            get => Helpers.CheckDecodeFixedString(this.value);
            set => this.value = Helpers.CheckEncodeFixedString(value,_size,this.value);
        }
    }


    /* =================================================================================
       Code-generated section: OpenXR types
       ================================================================================= */

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionCreateInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public OxrString64 actionName;
        public XrActionType actionType;
        public System.UInt32 countSubactionPaths;
        public System.IntPtr subactionPaths;
        public XrPath[] subactionPaths_managed {
            get {
                if (countSubactionPaths == 0 || subactionPaths == System.IntPtr.Zero)
                    return null;

                XrPath[] outarr = new XrPath[countSubactionPaths];
                System.IntPtr offset;
                for (int i=0; i<countSubactionPaths; i++) {
                    offset = System.IntPtr.Add(subactionPaths,i*sizeof(ulong));
                    outarr[i] = (System.UInt64)Marshal.ReadInt64(offset);
                }
                return outarr;
            }
        }
        public OxrString128 localizedActionName;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionSetCreateInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public OxrString64 actionSetName;
        public OxrString128 localizedActionSetName;
        public System.UInt32 priority;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionSpaceCreateInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public XrAction action;
        public XrPath subactionPath;
        public XrPosef poseInActionSpace;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionStateBoolean {
        public XrStructureType type;
        public System.IntPtr next;
        public XrBool32 currentState;
        public XrBool32 changedSinceLastSync;
        public XrTime lastChangeTime;
        public XrBool32 isActive;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionStateFloat {
        public XrStructureType type;
        public System.IntPtr next;
        public float currentState;
        public XrBool32 changedSinceLastSync;
        public XrTime lastChangeTime;
        public XrBool32 isActive;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionStateGetInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public XrAction action;
        public XrPath subactionPath;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionStatePose {
        public XrStructureType type;
        public System.IntPtr next;
        public XrBool32 isActive;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionStateVector2f {
        public XrStructureType type;
        public System.IntPtr next;
        public XrVector2f currentState;
        public XrBool32 changedSinceLastSync;
        public XrTime lastChangeTime;
        public XrBool32 isActive;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionSuggestedBinding {
        public XrAction action;
        public XrPath binding;
    }

    public enum XrActionType {
          XR_ACTION_TYPE_BOOLEAN_INPUT = 1,
          XR_ACTION_TYPE_FLOAT_INPUT = 2,
          XR_ACTION_TYPE_VECTOR2F_INPUT = 3,
          XR_ACTION_TYPE_POSE_INPUT = 4,
          XR_ACTION_TYPE_VIBRATION_OUTPUT = 100,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActionsSyncInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public System.UInt32 countActiveActionSets;
        public System.IntPtr activeActionSets;
        public XrActiveActionSet[] activeActionSets_managed {
            get {
                if (countActiveActionSets == 0 || activeActionSets == System.IntPtr.Zero)
                    return null;

                XrActiveActionSet[] outarr = new XrActiveActionSet[countActiveActionSets];
                System.IntPtr offset;
                for (int i=0; i<countActiveActionSets; i++) {
                    offset = System.IntPtr.Add(activeActionSets,i*Marshal.SizeOf(typeof(XrActiveActionSet)));
                    outarr[i] = Marshal.PtrToStructure<XrActiveActionSet>(offset);
                }
                return outarr;
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrActiveActionSet {
        public XrActionSet actionSet;
        public XrPath subactionPath;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrApiLayerProperties {
        public XrStructureType type;
        public System.IntPtr next;
        public OxrString256 layerName;
        public XrVersion specVersion;
        public System.UInt32 layerVersion;
        public OxrString256 description;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrEventDataBuffer {
        public XrStructureType type;
        public System.IntPtr next;
        public byte varying;
    }

    public enum XrFormFactor {
          XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY = 1,
          XR_FORM_FACTOR_HANDHELD_DISPLAY = 2,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrFovf {
        public float angleLeft;
        public float angleRight;
        public float angleUp;
        public float angleDown;
        public override string ToString()
        {
            return $"{angleLeft},{angleRight},{angleUp},{angleDown}";
        }        
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrInteractionProfileState {
        public XrStructureType type;
        public System.IntPtr next;
        public XrPath interactionProfile;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrInteractionProfileSuggestedBinding {
        public XrStructureType type;
        public System.IntPtr next;
        public XrPath interactionProfile;
        public System.UInt32 countSuggestedBindings;
        public System.IntPtr suggestedBindings;
        public XrActionSuggestedBinding[] suggestedBindings_managed {
            get {
                if (countSuggestedBindings == 0 || suggestedBindings == System.IntPtr.Zero)
                    return null;

                XrActionSuggestedBinding[] outarr = new XrActionSuggestedBinding[countSuggestedBindings];
                System.IntPtr offset;
                for (int i=0; i<countSuggestedBindings; i++) {
                    offset = System.IntPtr.Add(suggestedBindings,i*Marshal.SizeOf(typeof(XrActionSuggestedBinding)));
                    outarr[i] = Marshal.PtrToStructure<XrActionSuggestedBinding>(offset);
                }
                return outarr;
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrPosef {
        public XrQuaternionf orientation;
        public XrVector3f position;
        public override string ToString()
        {
            return $"orientation:{orientation},position:{position}";
        } 
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrQuaternionf {
        public float x;
        public float y;
        public float z;
        public float w;

        public override string ToString()
        {
            return $"{x},{y},{z},{w}";
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrReferenceSpaceCreateInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public XrReferenceSpaceType referenceSpaceType;
        public XrPosef poseInReferenceSpace;
    }

    public enum XrReferenceSpaceType {
          XR_REFERENCE_SPACE_TYPE_VIEW = 1,
          XR_REFERENCE_SPACE_TYPE_LOCAL = 2,
          XR_REFERENCE_SPACE_TYPE_STAGE = 3,
    }

    public enum XrResult {
          XR_SUCCESS = 0,
          XR_TIMEOUT_EXPIRED = 1,
          XR_SESSION_LOSS_PENDING = 3,
          XR_EVENT_UNAVAILABLE = 4,
          XR_SPACE_BOUNDS_UNAVAILABLE = 7,
          XR_SESSION_NOT_FOCUSED = 8,
          XR_FRAME_DISCARDED = 9,
          XR_ERROR_VALIDATION_FAILURE = -1,
          XR_ERROR_RUNTIME_FAILURE = -2,
          XR_ERROR_OUT_OF_MEMORY = -3,
          XR_ERROR_API_VERSION_UNSUPPORTED = -4,
          XR_ERROR_INITIALIZATION_FAILED = -6,
          XR_ERROR_FUNCTION_UNSUPPORTED = -7,
          XR_ERROR_FEATURE_UNSUPPORTED = -8,
          XR_ERROR_EXTENSION_NOT_PRESENT = -9,
          XR_ERROR_LIMIT_REACHED = -10,
          XR_ERROR_SIZE_INSUFFICIENT = -11,
          XR_ERROR_HANDLE_INVALID = -12,
          XR_ERROR_INSTANCE_LOST = -13,
          XR_ERROR_SESSION_RUNNING = -14,
          XR_ERROR_SESSION_NOT_RUNNING = -16,
          XR_ERROR_SESSION_LOST = -17,
          XR_ERROR_SYSTEM_INVALID = -18,
          XR_ERROR_PATH_INVALID = -19,
          XR_ERROR_PATH_COUNT_EXCEEDED = -20,
          XR_ERROR_PATH_FORMAT_INVALID = -21,
          XR_ERROR_PATH_UNSUPPORTED = -22,
          XR_ERROR_LAYER_INVALID = -23,
          XR_ERROR_LAYER_LIMIT_EXCEEDED = -24,
          XR_ERROR_SWAPCHAIN_RECT_INVALID = -25,
          XR_ERROR_SWAPCHAIN_FORMAT_UNSUPPORTED = -26,
          XR_ERROR_ACTION_TYPE_MISMATCH = -27,
          XR_ERROR_SESSION_NOT_READY = -28,
          XR_ERROR_SESSION_NOT_STOPPING = -29,
          XR_ERROR_TIME_INVALID = -30,
          XR_ERROR_REFERENCE_SPACE_UNSUPPORTED = -31,
          XR_ERROR_FILE_ACCESS_ERROR = -32,
          XR_ERROR_FILE_CONTENTS_INVALID = -33,
          XR_ERROR_FORM_FACTOR_UNSUPPORTED = -34,
          XR_ERROR_FORM_FACTOR_UNAVAILABLE = -35,
          XR_ERROR_API_LAYER_NOT_PRESENT = -36,
          XR_ERROR_CALL_ORDER_INVALID = -37,
          XR_ERROR_GRAPHICS_DEVICE_INVALID = -38,
          XR_ERROR_POSE_INVALID = -39,
          XR_ERROR_INDEX_OUT_OF_RANGE = -40,
          XR_ERROR_VIEW_CONFIGURATION_TYPE_UNSUPPORTED = -41,
          XR_ERROR_ENVIRONMENT_BLEND_MODE_UNSUPPORTED = -42,
          XR_ERROR_NAME_DUPLICATED = -44,
          XR_ERROR_NAME_INVALID = -45,
          XR_ERROR_ACTIONSET_NOT_ATTACHED = -46,
          XR_ERROR_ACTIONSETS_ALREADY_ATTACHED = -47,
          XR_ERROR_LOCALIZED_NAME_DUPLICATED = -48,
          XR_ERROR_LOCALIZED_NAME_INVALID = -49,
          XR_ERROR_GRAPHICS_REQUIREMENTS_CALL_MISSING = -50,
          XR_ERROR_RUNTIME_UNAVAILABLE = -51,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSessionActionSetsAttachInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public System.UInt32 countActionSets;
        public System.IntPtr actionSets;
        public XrActionSet[] actionSets_managed {
            get {
                if (countActionSets == 0 || actionSets == System.IntPtr.Zero)
                    return null;

                XrActionSet[] outarr = new XrActionSet[countActionSets];
                System.IntPtr offset;
                for (int i=0; i<countActionSets; i++) {
                    offset = System.IntPtr.Add(actionSets,i*sizeof(ulong));
                    outarr[i] = (System.UInt64)Marshal.ReadInt64(offset);
                }
                return outarr;
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSpaceLocation {
        public XrStructureType type;
        public System.IntPtr next;
        public XrSpaceLocationFlags locationFlags;
        public XrPosef pose;
    }

    [System.Flags] public enum XrSpaceLocationFlagBits : System.UInt64 {
          XR_SPACE_LOCATION_ORIENTATION_VALID_BIT = 0x00000001,
          XR_SPACE_LOCATION_POSITION_VALID_BIT = 0x00000002,
          XR_SPACE_LOCATION_ORIENTATION_TRACKED_BIT = 0x00000004,
          XR_SPACE_LOCATION_POSITION_TRACKED_BIT = 0x00000008,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSpaceVelocity {
        public XrStructureType type;
        public System.IntPtr next;
        public XrSpaceVelocityFlags velocityFlags;
        public XrVector3f linearVelocity;
        public XrVector3f angularVelocity;
    }

    [System.Flags] public enum XrSpaceVelocityFlagBits : System.UInt64 {
          XR_SPACE_VELOCITY_LINEAR_VALID_BIT = 0x00000001,
          XR_SPACE_VELOCITY_ANGULAR_VALID_BIT = 0x00000002,
    }

    public enum XrStructureType {
          XR_TYPE_UNKNOWN = 0,
          XR_TYPE_API_LAYER_PROPERTIES = 1,
          XR_TYPE_EXTENSION_PROPERTIES = 2,
          XR_TYPE_INSTANCE_CREATE_INFO = 3,
          XR_TYPE_SYSTEM_GET_INFO = 4,
          XR_TYPE_SYSTEM_PROPERTIES = 5,
          XR_TYPE_VIEW_LOCATE_INFO = 6,
          XR_TYPE_VIEW = 7,
          XR_TYPE_SESSION_CREATE_INFO = 8,
          XR_TYPE_SWAPCHAIN_CREATE_INFO = 9,
          XR_TYPE_SESSION_BEGIN_INFO = 10,
          XR_TYPE_VIEW_STATE = 11,
          XR_TYPE_FRAME_END_INFO = 12,
          XR_TYPE_HAPTIC_VIBRATION = 13,
          XR_TYPE_EVENT_DATA_BUFFER = 16,
          XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING = 17,
          XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED = 18,
          XR_TYPE_ACTION_STATE_BOOLEAN = 23,
          XR_TYPE_ACTION_STATE_FLOAT = 24,
          XR_TYPE_ACTION_STATE_VECTOR2F = 25,
          XR_TYPE_ACTION_STATE_POSE = 27,
          XR_TYPE_ACTION_SET_CREATE_INFO = 28,
          XR_TYPE_ACTION_CREATE_INFO = 29,
          XR_TYPE_INSTANCE_PROPERTIES = 32,
          XR_TYPE_FRAME_WAIT_INFO = 33,
          XR_TYPE_COMPOSITION_LAYER_PROJECTION = 35,
          XR_TYPE_COMPOSITION_LAYER_QUAD = 36,
          XR_TYPE_REFERENCE_SPACE_CREATE_INFO = 37,
          XR_TYPE_ACTION_SPACE_CREATE_INFO = 38,
          XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING = 40,
          XR_TYPE_VIEW_CONFIGURATION_VIEW = 41,
          XR_TYPE_SPACE_LOCATION = 42,
          XR_TYPE_SPACE_VELOCITY = 43,
          XR_TYPE_FRAME_STATE = 44,
          XR_TYPE_VIEW_CONFIGURATION_PROPERTIES = 45,
          XR_TYPE_FRAME_BEGIN_INFO = 46,
          XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW = 48,
          XR_TYPE_EVENT_DATA_EVENTS_LOST = 49,
          XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING = 51,
          XR_TYPE_EVENT_DATA_INTERACTION_PROFILE_CHANGED = 52,
          XR_TYPE_INTERACTION_PROFILE_STATE = 53,
          XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO = 55,
          XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO = 56,
          XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO = 57,
          XR_TYPE_ACTION_STATE_GET_INFO = 58,
          XR_TYPE_HAPTIC_ACTION_INFO = 59,
          XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO = 60,
          XR_TYPE_ACTIONS_SYNC_INFO = 61,
          XR_TYPE_BOUND_SOURCES_FOR_ACTION_ENUMERATE_INFO = 62,
          XR_TYPE_INPUT_SOURCE_LOCALIZED_NAME_GET_INFO = 63,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSystemGetInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public XrFormFactor formFactor;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSystemGraphicsProperties {
        public System.UInt32 maxSwapchainImageHeight;
        public System.UInt32 maxSwapchainImageWidth;
        public System.UInt32 maxLayerCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSystemProperties {
        public XrStructureType type;
        public System.IntPtr next;
        public XrSystemId systemId;
        public System.UInt32 vendorId;
        public OxrString256 systemName;
        public XrSystemGraphicsProperties graphicsProperties;
        public XrSystemTrackingProperties trackingProperties;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrSystemTrackingProperties {
        public XrBool32 orientationTracking;
        public XrBool32 positionTracking;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrVector2f {
        public float x;
        public float y;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrVector3f {
        public float x;
        public float y;
        public float z;
        public override string ToString()
        {
            return $"{x},{y},{z}";
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrView {
        public XrStructureType type;
        public System.IntPtr next;
        public XrPosef pose;
        public XrFovf fov;
        public override string ToString()
        {
            return $"pose:{pose},fov:{fov}";
        } 
    }

    public enum XrViewConfigurationType {
          XR_VIEW_CONFIGURATION_TYPE_PRIMARY_MONO = 1,
          XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO = 2,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrViewConfigurationView {
        public XrStructureType type;
        public System.IntPtr next;
        public System.UInt32 recommendedImageRectWidth;
        public System.UInt32 maxImageRectWidth;
        public System.UInt32 recommendedImageRectHeight;
        public System.UInt32 maxImageRectHeight;
        public System.UInt32 recommendedSwapchainSampleCount;
        public System.UInt32 maxSwapchainSampleCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrViewLocateInfo {
        public XrStructureType type;
        public System.IntPtr next;
        public XrViewConfigurationType viewConfigurationType;
        public XrTime displayTime;
        public XrSpace space;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct XrViewState {
        public XrStructureType type;
        public System.IntPtr next;
        public XrViewStateFlags viewStateFlags;
    }

    [System.Flags] public enum XrViewStateFlagBits : System.UInt64 {
          XR_VIEW_STATE_ORIENTATION_VALID_BIT = 0x00000001,
          XR_VIEW_STATE_POSITION_VALID_BIT = 0x00000002,
          XR_VIEW_STATE_ORIENTATION_TRACKED_BIT = 0x00000004,
          XR_VIEW_STATE_POSITION_TRACKED_BIT = 0x00000008,
    }




    /* =================================================================================
       Hand-crafted section: OpenXRFeature class declaration and details
       ================================================================================= */
    public class OpenXRFeatureBase : OpenXRFeature
    {
        private static readonly string TAG = "NvOpenXRFeatureBase";
        protected static OpenXRFeatureBase theInstance = null;
        public OpenXRFeatureBase() {
            /*
            // It's a singleton created by Unity what can I say.
            if (NvOpenXRFeatureBase.theInstance==null)
                Log.W("NvOpenXRFeatureBase instantiated more than once; replacing with latest.");
            NvOpenXRFeatureBase.theInstance = this;
            */
            // The old way
            if (OpenXRFeatureBase.theInstance==null)
                 OpenXRFeatureBase.theInstance = this;
        }

        protected static System.UInt64 m_xrInstanceHandle = 0, m_xrSessionHandle = 0;

        // Method attribute that hints to Unity (via its name?!) that a method needs to
        // be callable from native code on Android/iOS
        public class MonoPInvokeCallback : System.Attribute { };

        private bool checkResult(XrResult code, string reference) {
            if (code == XrResult.XR_SUCCESS) {
                return true;
            }
            else {
                /*
                string msg;
                if ((f_xrResultToString==null)) {
                    msg = $"OpenXR err: code {code} at reference {reference} (could not get error name)";
                }
                else if (m_xrInstanceHandle==0) {
                    msg = $"OpenXR err: code {code} at reference {reference} (could not get error name)";
                }
                else {
                    string errName;
                    XrResult innerCode = f_xrResultToString(m_xrInstanceHandle,code,out errName);
                    msg = $"OpenXR err: code {errName} ({code}) at reference {reference}";
                }
                Log.W(msg);
                */
                return false;
            }
        }
    /* =================================================================================
       Code-generated class section: constants
       ================================================================================= */

            public const int XR_TRUE = 1;
            public const int XR_FALSE = 0;
            public const int XR_MAX_EXTENSION_NAME_SIZE = 128;
            public const int XR_MAX_API_LAYER_NAME_SIZE = 256;
            public const int XR_MAX_API_LAYER_DESCRIPTION_SIZE = 256;
            public const int XR_MAX_SYSTEM_NAME_SIZE = 256;
            public const int XR_MAX_APPLICATION_NAME_SIZE = 128;
            public const int XR_MAX_ENGINE_NAME_SIZE = 128;
            public const int XR_MAX_RUNTIME_NAME_SIZE = 128;
            public const int XR_MAX_PATH_LENGTH = 256;
            public const int XR_MAX_STRUCTURE_NAME_SIZE = 64;
            public const int XR_MAX_RESULT_STRING_SIZE = 64;
            public const int XR_MAX_GRAPHICS_APIS_SUPPORTED = 32;
            public const int XR_MAX_ACTION_SET_NAME_SIZE = 64;
            public const int XR_MAX_ACTION_NAME_SIZE = 64;
            public const int XR_MAX_LOCALIZED_ACTION_SET_NAME_SIZE = 128;
            public const int XR_MAX_LOCALIZED_ACTION_NAME_SIZE = 128;
    /* =================================================================================
       Code-generated class section: function prototypes for OpenXR functions
       ================================================================================= */

        protected delegate XrResult delg_native_xrEnumerateApiLayerProperties(System.UInt32 propertyCapacityInput, out System.UInt32 propertyCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=0)] XrApiLayerProperties[] properties);
        protected delegate XrResult delg_xrEnumerateApiLayerProperties(out XrApiLayerProperties[] cs_properties);
        protected delg_native_xrEnumerateApiLayerProperties f_native_xrEnumerateApiLayerProperties;
        protected delg_native_xrEnumerateApiLayerProperties f_oxr_native_xrEnumerateApiLayerProperties;
        protected XrResult f_xrEnumerateApiLayerProperties (out XrApiLayerProperties[] cs_properties)
        {
            // Log.I(TAG, "Called C# outer function for: xrEnumerateApiLayerProperties");
            System.UInt32 propertyCountOutput;
            XrApiLayerProperties[] properties = null;
            XrResult result = f_native_xrEnumerateApiLayerProperties(0, out propertyCountOutput, properties);
            if (result != XrResult.XR_SUCCESS) {
                cs_properties = null;                
                return result;
            }
            properties = new XrApiLayerProperties[propertyCountOutput];
            
            for (int i=0;i<properties.Length;i++) {
                properties[i].type = XrStructureType.XR_TYPE_API_LAYER_PROPERTIES;
            }

            System.UInt32 propertyCapacityInput = propertyCountOutput;
            result = f_native_xrEnumerateApiLayerProperties(propertyCapacityInput, out propertyCountOutput, properties);
            if (result != XrResult.XR_SUCCESS) {
                cs_properties = null;                
                return result;
            }
            cs_properties = properties;
            return result;
        }

        protected virtual XrResult hooked_method_xrEnumerateApiLayerProperties(System.UInt32 propertyCapacityInput, out System.UInt32 propertyCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=0)] XrApiLayerProperties[] properties) {
            return f_oxr_native_xrEnumerateApiLayerProperties(propertyCapacityInput, out propertyCountOutput, properties);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrEnumerateApiLayerProperties(System.UInt32 propertyCapacityInput, out System.UInt32 propertyCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=0)] XrApiLayerProperties[] properties) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrEnumerateApiLayerProperties(propertyCapacityInput, out propertyCountOutput, properties);
        }
        protected delegate XrResult delg_native_xrResultToString(XrInstance instance, XrResult value, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeConst=XR_MAX_RESULT_STRING_SIZE)] byte[] buffer);
        protected delegate XrResult delg_xrResultToString(XrInstance instance, XrResult value, out string cs_buffer);
        protected delg_native_xrResultToString f_native_xrResultToString;
        protected delg_native_xrResultToString f_oxr_native_xrResultToString;
        protected XrResult f_xrResultToString (XrInstance instance, XrResult value, out string cs_buffer)
        {
            // Log.I(TAG, "Called C# outer function for: xrResultToString");
            byte[] buffer = new byte[XR_MAX_RESULT_STRING_SIZE];
            XrResult result = f_native_xrResultToString(instance, value, buffer);
            if (result != XrResult.XR_SUCCESS) {
                cs_buffer = null;                
                return result;
            }
            cs_buffer = System.Text.Encoding.UTF8.GetString(buffer, 0, (int)XR_MAX_RESULT_STRING_SIZE-1);
            return result;
        }

        protected virtual XrResult hooked_method_xrResultToString(XrInstance instance, XrResult value, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeConst=XR_MAX_RESULT_STRING_SIZE)] byte[] buffer) {
            return f_oxr_native_xrResultToString(instance, value, buffer);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrResultToString(XrInstance instance, XrResult value, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeConst=XR_MAX_RESULT_STRING_SIZE)] byte[] buffer) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrResultToString(instance, value, buffer);
        }
        protected delegate XrResult delg_native_xrGetSystem(XrInstance instance, ref XrSystemGetInfo getInfo, ref XrSystemId systemId);
        protected delg_native_xrGetSystem f_native_xrGetSystem;
        protected delg_native_xrGetSystem f_oxr_native_xrGetSystem;
        protected delg_native_xrGetSystem f_xrGetSystem {get => f_native_xrGetSystem; }

        protected virtual XrResult hooked_method_xrGetSystem(XrInstance instance, ref XrSystemGetInfo getInfo, ref XrSystemId systemId) {
            return f_oxr_native_xrGetSystem(instance, ref getInfo, ref systemId);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetSystem(XrInstance instance, ref XrSystemGetInfo getInfo, ref XrSystemId systemId) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetSystem(instance, ref getInfo, ref systemId);
        }
        protected delegate XrResult delg_native_xrGetSystemProperties(XrInstance instance, XrSystemId systemId, ref XrSystemProperties properties);
        protected delg_native_xrGetSystemProperties f_native_xrGetSystemProperties;
        protected delg_native_xrGetSystemProperties f_oxr_native_xrGetSystemProperties;
        protected delg_native_xrGetSystemProperties f_xrGetSystemProperties {get => f_native_xrGetSystemProperties; }

        protected virtual XrResult hooked_method_xrGetSystemProperties(XrInstance instance, XrSystemId systemId, ref XrSystemProperties properties) {
            return f_oxr_native_xrGetSystemProperties(instance, systemId, ref properties);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetSystemProperties(XrInstance instance, XrSystemId systemId, ref XrSystemProperties properties) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetSystemProperties(instance, systemId, ref properties);
        }
        protected delegate XrResult delg_native_xrDestroySpace(XrSpace space);
        protected delg_native_xrDestroySpace f_native_xrDestroySpace;
        protected delg_native_xrDestroySpace f_oxr_native_xrDestroySpace;
        protected delg_native_xrDestroySpace f_xrDestroySpace {get => f_native_xrDestroySpace; }

        protected virtual XrResult hooked_method_xrDestroySpace(XrSpace space) {
            return f_oxr_native_xrDestroySpace(space);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrDestroySpace(XrSpace space) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrDestroySpace(space);
        }
        protected delegate XrResult delg_native_xrCreateReferenceSpace(XrSession session, ref XrReferenceSpaceCreateInfo createInfo, ref XrSpace space);
        protected delg_native_xrCreateReferenceSpace f_native_xrCreateReferenceSpace;
        protected delg_native_xrCreateReferenceSpace f_oxr_native_xrCreateReferenceSpace;
        protected delg_native_xrCreateReferenceSpace f_xrCreateReferenceSpace {get => f_native_xrCreateReferenceSpace; }

        protected virtual XrResult hooked_method_xrCreateReferenceSpace(XrSession session, ref XrReferenceSpaceCreateInfo createInfo, ref XrSpace space) {
            return f_oxr_native_xrCreateReferenceSpace(session, ref createInfo, ref space);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrCreateReferenceSpace(XrSession session, ref XrReferenceSpaceCreateInfo createInfo, ref XrSpace space) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrCreateReferenceSpace(session, ref createInfo, ref space);
        }
        protected delegate XrResult delg_native_xrCreateActionSpace(XrSession session, ref XrActionSpaceCreateInfo createInfo, ref XrSpace space);
        protected delg_native_xrCreateActionSpace f_native_xrCreateActionSpace;
        protected delg_native_xrCreateActionSpace f_oxr_native_xrCreateActionSpace;
        protected delg_native_xrCreateActionSpace f_xrCreateActionSpace {get => f_native_xrCreateActionSpace; }

        protected virtual XrResult hooked_method_xrCreateActionSpace(XrSession session, ref XrActionSpaceCreateInfo createInfo, ref XrSpace space) {
            return f_oxr_native_xrCreateActionSpace(session, ref createInfo, ref space);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrCreateActionSpace(XrSession session, ref XrActionSpaceCreateInfo createInfo, ref XrSpace space) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrCreateActionSpace(session, ref createInfo, ref space);
        }
        protected delegate XrResult delg_native_xrLocateSpace(XrSpace space, XrSpace baseSpace, XrTime time, ref XrSpaceLocation location);
        protected delg_native_xrLocateSpace f_native_xrLocateSpace;
        protected delg_native_xrLocateSpace f_oxr_native_xrLocateSpace;
        protected delg_native_xrLocateSpace f_xrLocateSpace {get => f_native_xrLocateSpace; }

        protected virtual XrResult hooked_method_xrLocateSpace(XrSpace space, XrSpace baseSpace, XrTime time, ref XrSpaceLocation location) {
            return f_oxr_native_xrLocateSpace(space, baseSpace, time, ref location);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrLocateSpace(XrSpace space, XrSpace baseSpace, XrTime time, ref XrSpaceLocation location) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrLocateSpace(space, baseSpace, time, ref location);
        }
        protected delegate XrResult delg_native_xrEnumerateViewConfigurationViews(XrInstance instance, XrSystemId systemId, XrViewConfigurationType viewConfigurationType, System.UInt32 viewCapacityInput, out System.UInt32 viewCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=3)] XrViewConfigurationView[] views);
        protected delegate XrResult delg_xrEnumerateViewConfigurationViews(XrInstance instance, XrSystemId systemId, XrViewConfigurationType viewConfigurationType, out XrViewConfigurationView[] cs_views);
        protected delg_native_xrEnumerateViewConfigurationViews f_native_xrEnumerateViewConfigurationViews;
        protected delg_native_xrEnumerateViewConfigurationViews f_oxr_native_xrEnumerateViewConfigurationViews;
        protected XrResult f_xrEnumerateViewConfigurationViews (XrInstance instance, XrSystemId systemId, XrViewConfigurationType viewConfigurationType, out XrViewConfigurationView[] cs_views)
        {
            // Log.I(TAG, "Called C# outer function for: xrEnumerateViewConfigurationViews");
            System.UInt32 viewCountOutput;
            XrViewConfigurationView[] views = null;
            XrResult result = f_native_xrEnumerateViewConfigurationViews(instance, systemId, viewConfigurationType, 0, out viewCountOutput, views);
            if (result != XrResult.XR_SUCCESS) {
                cs_views = null;                
                return result;
            }
            views = new XrViewConfigurationView[viewCountOutput];
            
            for (int i=0;i<views.Length;i++) {
                views[i].type = XrStructureType.XR_TYPE_VIEW_CONFIGURATION_VIEW;
            }

            System.UInt32 viewCapacityInput = viewCountOutput;
            result = f_native_xrEnumerateViewConfigurationViews(instance, systemId, viewConfigurationType, viewCapacityInput, out viewCountOutput, views);
            if (result != XrResult.XR_SUCCESS) {
                cs_views = null;                
                return result;
            }
            cs_views = views;
            return result;
        }

        protected virtual XrResult hooked_method_xrEnumerateViewConfigurationViews(XrInstance instance, XrSystemId systemId, XrViewConfigurationType viewConfigurationType, System.UInt32 viewCapacityInput, out System.UInt32 viewCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=3)] XrViewConfigurationView[] views) {
            return f_oxr_native_xrEnumerateViewConfigurationViews(instance, systemId, viewConfigurationType, viewCapacityInput, out viewCountOutput, views);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrEnumerateViewConfigurationViews(XrInstance instance, XrSystemId systemId, XrViewConfigurationType viewConfigurationType, System.UInt32 viewCapacityInput, out System.UInt32 viewCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=3)] XrViewConfigurationView[] views) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrEnumerateViewConfigurationViews(instance, systemId, viewConfigurationType, viewCapacityInput, out viewCountOutput, views);
        }
        protected delegate XrResult delg_native_xrLocateViews(XrSession session, ref XrViewLocateInfo viewLocateInfo, ref XrViewState viewState, System.UInt32 viewCapacityInput, out System.UInt32 viewCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=3)] XrView[] views);
        protected delegate XrResult delg_xrLocateViews(XrSession session, ref XrViewLocateInfo viewLocateInfo, ref XrViewState viewState, out XrView[] cs_views);
        protected delg_native_xrLocateViews f_native_xrLocateViews;
        protected delg_native_xrLocateViews f_oxr_native_xrLocateViews;
        protected XrResult f_xrLocateViews (XrSession session, ref XrViewLocateInfo viewLocateInfo, ref XrViewState viewState, out XrView[] cs_views)
        {
            // Log.I(TAG, "Called C# outer function for: xrLocateViews");
            System.UInt32 viewCountOutput;
            XrView[] views = null;
            XrResult result = f_native_xrLocateViews(session, ref viewLocateInfo, ref viewState, 0, out viewCountOutput, views);
            if (result != XrResult.XR_SUCCESS) {
                cs_views = null;                
                return result;
            }
            views = new XrView[viewCountOutput];
            
            for (int i=0;i<views.Length;i++) {
                views[i].type = XrStructureType.XR_TYPE_VIEW;
            }

            System.UInt32 viewCapacityInput = viewCountOutput;
            result = f_native_xrLocateViews(session, ref viewLocateInfo, ref viewState, viewCapacityInput, out viewCountOutput, views);
            if (result != XrResult.XR_SUCCESS) {
                cs_views = null;                
                return result;
            }
            cs_views = views;
            return result;
        }

        protected virtual XrResult hooked_method_xrLocateViews(XrSession session, ref XrViewLocateInfo viewLocateInfo, ref XrViewState viewState, System.UInt32 viewCapacityInput, out System.UInt32 viewCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=3)] XrView[] views) {
            return f_oxr_native_xrLocateViews(session, ref viewLocateInfo, ref viewState, viewCapacityInput, out viewCountOutput, views);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrLocateViews(XrSession session, ref XrViewLocateInfo viewLocateInfo, ref XrViewState viewState, System.UInt32 viewCapacityInput, out System.UInt32 viewCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=3)] XrView[] views) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrLocateViews(session, ref viewLocateInfo, ref viewState, viewCapacityInput, out viewCountOutput, views);
        }
        protected delegate XrResult delg_native_xrPollEvent(XrInstance instance, ref XrEventDataBuffer eventData);
        protected delg_native_xrPollEvent f_native_xrPollEvent;
        protected delg_native_xrPollEvent f_oxr_native_xrPollEvent;
        protected delg_native_xrPollEvent f_xrPollEvent {get => f_native_xrPollEvent; }

        protected virtual XrResult hooked_method_xrPollEvent(XrInstance instance, ref XrEventDataBuffer eventData) {
            return f_oxr_native_xrPollEvent(instance, ref eventData);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrPollEvent(XrInstance instance, ref XrEventDataBuffer eventData) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrPollEvent(instance, ref eventData);
        }
        protected delegate XrResult delg_native_xrStringToPath(XrInstance instance, [MarshalAs(UnmanagedType.LPUTF8Str)] string pathString, ref XrPath path);
        protected delg_native_xrStringToPath f_native_xrStringToPath;
        protected delg_native_xrStringToPath f_oxr_native_xrStringToPath;
        protected delg_native_xrStringToPath f_xrStringToPath {get => f_native_xrStringToPath; }

        protected virtual XrResult hooked_method_xrStringToPath(XrInstance instance, [MarshalAs(UnmanagedType.LPUTF8Str)] string pathString, ref XrPath path) {
            return f_oxr_native_xrStringToPath(instance, pathString, ref path);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrStringToPath(XrInstance instance, [MarshalAs(UnmanagedType.LPUTF8Str)] string pathString, ref XrPath path) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrStringToPath(instance, pathString, ref path);
        }
        protected delegate XrResult delg_native_xrPathToString(XrInstance instance, XrPath path, System.UInt32 bufferCapacityInput, out System.UInt32 bufferCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=2)] byte[] buffer);
        protected delegate XrResult delg_xrPathToString(XrInstance instance, XrPath path, out string cs_buffer);
        protected delg_native_xrPathToString f_native_xrPathToString;
        protected delg_native_xrPathToString f_oxr_native_xrPathToString;
        protected XrResult f_xrPathToString (XrInstance instance, XrPath path, out string cs_buffer)
        {
            // Log.I(TAG, "Called C# outer function for: xrPathToString");
            System.UInt32 bufferCountOutput;
            byte[] buffer = null;
            XrResult result = f_native_xrPathToString(instance, path, 0, out bufferCountOutput, buffer);
            if (result != XrResult.XR_SUCCESS) {
                cs_buffer = null;                
                return result;
            }
            buffer = new byte[bufferCountOutput];
            
            System.UInt32 bufferCapacityInput = bufferCountOutput;
            result = f_native_xrPathToString(instance, path, bufferCapacityInput, out bufferCountOutput, buffer);
            if (result != XrResult.XR_SUCCESS) {
                cs_buffer = null;                
                return result;
            }
            cs_buffer = System.Text.Encoding.UTF8.GetString(buffer, 0, (int)bufferCapacityInput-1);
            return result;
        }

        protected virtual XrResult hooked_method_xrPathToString(XrInstance instance, XrPath path, System.UInt32 bufferCapacityInput, out System.UInt32 bufferCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=2)] byte[] buffer) {
            return f_oxr_native_xrPathToString(instance, path, bufferCapacityInput, out bufferCountOutput, buffer);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrPathToString(XrInstance instance, XrPath path, System.UInt32 bufferCapacityInput, out System.UInt32 bufferCountOutput, [In, Out, MarshalAs(UnmanagedType.LPArray,SizeParamIndex=2)] byte[] buffer) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrPathToString(instance, path, bufferCapacityInput, out bufferCountOutput, buffer);
        }
        protected delegate XrResult delg_native_xrGetActionStateBoolean(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateBoolean state);
        protected delg_native_xrGetActionStateBoolean f_native_xrGetActionStateBoolean;
        protected delg_native_xrGetActionStateBoolean f_oxr_native_xrGetActionStateBoolean;
        protected delg_native_xrGetActionStateBoolean f_xrGetActionStateBoolean {get => f_native_xrGetActionStateBoolean; }

        protected virtual XrResult hooked_method_xrGetActionStateBoolean(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateBoolean state) {
            return f_oxr_native_xrGetActionStateBoolean(session, ref getInfo, ref state);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetActionStateBoolean(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateBoolean state) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetActionStateBoolean(session, ref getInfo, ref state);
        }
        protected delegate XrResult delg_native_xrGetActionStateFloat(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateFloat state);
        protected delg_native_xrGetActionStateFloat f_native_xrGetActionStateFloat;
        protected delg_native_xrGetActionStateFloat f_oxr_native_xrGetActionStateFloat;
        protected delg_native_xrGetActionStateFloat f_xrGetActionStateFloat {get => f_native_xrGetActionStateFloat; }

        protected virtual XrResult hooked_method_xrGetActionStateFloat(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateFloat state) {
            return f_oxr_native_xrGetActionStateFloat(session, ref getInfo, ref state);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetActionStateFloat(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateFloat state) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetActionStateFloat(session, ref getInfo, ref state);
        }
        protected delegate XrResult delg_native_xrGetActionStateVector2f(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateVector2f state);
        protected delg_native_xrGetActionStateVector2f f_native_xrGetActionStateVector2f;
        protected delg_native_xrGetActionStateVector2f f_oxr_native_xrGetActionStateVector2f;
        protected delg_native_xrGetActionStateVector2f f_xrGetActionStateVector2f {get => f_native_xrGetActionStateVector2f; }

        protected virtual XrResult hooked_method_xrGetActionStateVector2f(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateVector2f state) {
            return f_oxr_native_xrGetActionStateVector2f(session, ref getInfo, ref state);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetActionStateVector2f(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStateVector2f state) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetActionStateVector2f(session, ref getInfo, ref state);
        }
        protected delegate XrResult delg_native_xrGetActionStatePose(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStatePose state);
        protected delg_native_xrGetActionStatePose f_native_xrGetActionStatePose;
        protected delg_native_xrGetActionStatePose f_oxr_native_xrGetActionStatePose;
        protected delg_native_xrGetActionStatePose f_xrGetActionStatePose {get => f_native_xrGetActionStatePose; }

        protected virtual XrResult hooked_method_xrGetActionStatePose(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStatePose state) {
            return f_oxr_native_xrGetActionStatePose(session, ref getInfo, ref state);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetActionStatePose(XrSession session, ref XrActionStateGetInfo getInfo, ref XrActionStatePose state) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetActionStatePose(session, ref getInfo, ref state);
        }
        protected delegate XrResult delg_native_xrCreateActionSet(XrInstance instance, ref XrActionSetCreateInfo createInfo, ref XrActionSet actionSet);
        protected delg_native_xrCreateActionSet f_native_xrCreateActionSet;
        protected delg_native_xrCreateActionSet f_oxr_native_xrCreateActionSet;
        protected delg_native_xrCreateActionSet f_xrCreateActionSet {get => f_native_xrCreateActionSet; }

        protected virtual XrResult hooked_method_xrCreateActionSet(XrInstance instance, ref XrActionSetCreateInfo createInfo, ref XrActionSet actionSet) {
            return f_oxr_native_xrCreateActionSet(instance, ref createInfo, ref actionSet);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrCreateActionSet(XrInstance instance, ref XrActionSetCreateInfo createInfo, ref XrActionSet actionSet) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrCreateActionSet(instance, ref createInfo, ref actionSet);
        }
        protected delegate XrResult delg_native_xrCreateAction(XrActionSet actionSet, ref XrActionCreateInfo createInfo, ref XrAction action);
        protected delg_native_xrCreateAction f_native_xrCreateAction;
        protected delg_native_xrCreateAction f_oxr_native_xrCreateAction;
        protected delg_native_xrCreateAction f_xrCreateAction {get => f_native_xrCreateAction; }

        protected virtual XrResult hooked_method_xrCreateAction(XrActionSet actionSet, ref XrActionCreateInfo createInfo, ref XrAction action) {
            return f_oxr_native_xrCreateAction(actionSet, ref createInfo, ref action);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrCreateAction(XrActionSet actionSet, ref XrActionCreateInfo createInfo, ref XrAction action) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrCreateAction(actionSet, ref createInfo, ref action);
        }
        protected delegate XrResult delg_native_xrSuggestInteractionProfileBindings(XrInstance instance, ref XrInteractionProfileSuggestedBinding suggestedBindings);
        protected delg_native_xrSuggestInteractionProfileBindings f_native_xrSuggestInteractionProfileBindings;
        protected delg_native_xrSuggestInteractionProfileBindings f_oxr_native_xrSuggestInteractionProfileBindings;
        protected delg_native_xrSuggestInteractionProfileBindings f_xrSuggestInteractionProfileBindings {get => f_native_xrSuggestInteractionProfileBindings; }

        protected virtual XrResult hooked_method_xrSuggestInteractionProfileBindings(XrInstance instance, ref XrInteractionProfileSuggestedBinding suggestedBindings) {
            return f_oxr_native_xrSuggestInteractionProfileBindings(instance, ref suggestedBindings);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrSuggestInteractionProfileBindings(XrInstance instance, ref XrInteractionProfileSuggestedBinding suggestedBindings) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrSuggestInteractionProfileBindings(instance, ref suggestedBindings);
        }
        protected delegate XrResult delg_native_xrAttachSessionActionSets(XrSession session, ref XrSessionActionSetsAttachInfo attachInfo);
        protected delg_native_xrAttachSessionActionSets f_native_xrAttachSessionActionSets;
        protected delg_native_xrAttachSessionActionSets f_oxr_native_xrAttachSessionActionSets;
        protected delg_native_xrAttachSessionActionSets f_xrAttachSessionActionSets {get => f_native_xrAttachSessionActionSets; }

        protected virtual XrResult hooked_method_xrAttachSessionActionSets(XrSession session, ref XrSessionActionSetsAttachInfo attachInfo) {
            return f_oxr_native_xrAttachSessionActionSets(session, ref attachInfo);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrAttachSessionActionSets(XrSession session, ref XrSessionActionSetsAttachInfo attachInfo) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrAttachSessionActionSets(session, ref attachInfo);
        }
        protected delegate XrResult delg_native_xrGetCurrentInteractionProfile(XrSession session, XrPath topLevelUserPath, ref XrInteractionProfileState interactionProfile);
        protected delg_native_xrGetCurrentInteractionProfile f_native_xrGetCurrentInteractionProfile;
        protected delg_native_xrGetCurrentInteractionProfile f_oxr_native_xrGetCurrentInteractionProfile;
        protected delg_native_xrGetCurrentInteractionProfile f_xrGetCurrentInteractionProfile {get => f_native_xrGetCurrentInteractionProfile; }

        protected virtual XrResult hooked_method_xrGetCurrentInteractionProfile(XrSession session, XrPath topLevelUserPath, ref XrInteractionProfileState interactionProfile) {
            return f_oxr_native_xrGetCurrentInteractionProfile(session, topLevelUserPath, ref interactionProfile);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrGetCurrentInteractionProfile(XrSession session, XrPath topLevelUserPath, ref XrInteractionProfileState interactionProfile) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrGetCurrentInteractionProfile(session, topLevelUserPath, ref interactionProfile);
        }
        protected delegate XrResult delg_native_xrSyncActions(XrSession session, ref XrActionsSyncInfo syncInfo);
        protected delg_native_xrSyncActions f_native_xrSyncActions;
        protected delg_native_xrSyncActions f_oxr_native_xrSyncActions;
        protected delg_native_xrSyncActions f_xrSyncActions {get => f_native_xrSyncActions; }

        protected virtual XrResult hooked_method_xrSyncActions(XrSession session, ref XrActionsSyncInfo syncInfo) {
            return f_oxr_native_xrSyncActions(session, ref syncInfo);
        }
        [MonoPInvokeCallback]
        private static XrResult hooked_xrSyncActions(XrSession session, ref XrActionsSyncInfo syncInfo) {
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            return thisish.hooked_method_xrSyncActions(session, ref syncInfo);
        }
    /* =================================================================================
       Hand-crafted class section: Time is tricky
       ================================================================================= */
        #if (UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN)
            [DllImport("Kernel32.dll")]
            public static extern bool QueryPerformanceCounter(ref System.Int64 lpPerformanceCount);

            // https://registry.khronos.org/OpenXR/specs/1.0/man/html/xrConvertWin32PerformanceCounterToTimeKHR.html
            delegate XrResult delg_xrConvertWin32PerformanceCounterToTimeKHR(XrInstance instance, ref long lpPerformanceCount, out XrTime time);
            private delg_xrConvertWin32PerformanceCounterToTimeKHR f_xrConvertWin32PerformanceCounterToTimeKHR = null;
        #elif UNITY_ANDROID
            // https://linux.die.net/man/3/clock_gettime
            [StructLayout(LayoutKind.Sequential)]
            public struct timespec_struct {
                public System.UInt64 tv_sec;
                public long tv_nsec;
            }
            // [global::System.Runtime.InteropServices.DllImport("tcr", EntryPoint = "native_GetTimespecTime")]
            // private static extern timespec_struct GetTimespecTime();
            [DllImport("tcr")]
            private static extern timespec_struct native_GetTimespecTime();

            private static timespec_struct GetTimespecTime() {
                return native_GetTimespecTime();
            }


            delegate XrResult delg_xrConvertTimespecTimeToTimeKHR(XrInstance instance, ref timespec_struct timespecTime, out XrTime time);
            private delg_xrConvertTimespecTimeToTimeKHR f_xrConvertTimespecTimeToTimeKHR = null;
        #endif


        public XrTime GetXrTimeNow() {
            // For now, just do NOW.
            #if (UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN)
                System.Int64 winTime = 0;
                QueryPerformanceCounter(ref winTime);

                XrTime time;
                XrResult xrResult = f_xrConvertWin32PerformanceCounterToTimeKHR(m_xrInstanceHandle, ref winTime, out time);
                if (checkResult(xrResult,"xrConvertWin32PerformanceCounterToTimeKHR"))
                    return time;
                else
                    return (XrTime)0;
            #elif UNITY_ANDROID
                timespec_struct ts = GetTimespecTime();

               if (f_xrConvertTimespecTimeToTimeKHR==null) {
                    System.UInt64 result = ((System.UInt64)ts.tv_nsec) + ( ((System.UInt64)ts.tv_sec)*((System.UInt64)(1000*1000*1000)) );
                    return (XrTime)result;
                }
                else {
                    XrTime time;
                    XrResult xrResult = f_xrConvertTimespecTimeToTimeKHR(m_xrInstanceHandle,ref ts, out time);
                    if (checkResult(xrResult,"xrConvertTimespecTimeToTimeKHR"))
                        return time;
                    else
                        return (XrTime)0;
                }
            #else
                return (XrTime)0;
            #endif
        }



    /* =================================================================================
       Hand-crafted class section: Setup / teardown instance / interop
       ================================================================================= */
        protected override bool OnInstanceCreate(ulong instance) {
            Log.I(TAG, "OnInstanceCreate()");
            m_xrInstanceHandle = instance;
            return SetupInterop();
        }
        protected override void OnInstanceDestroy(ulong instance) {
            if (instance != m_xrInstanceHandle) {
                Log.E(TAG, "UNEXPECTED: OnInstanceDestroy called on a different OpenXR instance than previously passed to OnInstanceCreate");
            }
            m_xrInstanceHandle = 0;
            TeardownInterop();
        }       
        private bool SetupInterop() {
            bool succeeded=true;
            XrResult xrResult;
            System.IntPtr funcPtr;

            // This one's special; Unity exposes `xrGetInstanceProcAddr` as an element or field
            // on the parent class OpenXRFeature
            f_native_xrGetInstanceProcAddr = (delg_native_xrGetInstanceProcAddr)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetInstanceProcAddr>(xrGetInstanceProcAddr);

            /*  =================================================================================
                Code-generated function section: fetch all required "underlying" functions
                ================================================================================= */
            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrEnumerateApiLayerProperties",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrEnumerateApiLayerProperties")) succeeded = false;
            f_native_xrEnumerateApiLayerProperties = Marshal.GetDelegateForFunctionPointer<delg_native_xrEnumerateApiLayerProperties>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrResultToString",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrResultToString")) succeeded = false;
            f_native_xrResultToString = Marshal.GetDelegateForFunctionPointer<delg_native_xrResultToString>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetSystem",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetSystem")) succeeded = false;
            f_native_xrGetSystem = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetSystem>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetSystemProperties",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetSystemProperties")) succeeded = false;
            f_native_xrGetSystemProperties = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetSystemProperties>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrDestroySpace",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrDestroySpace")) succeeded = false;
            f_native_xrDestroySpace = Marshal.GetDelegateForFunctionPointer<delg_native_xrDestroySpace>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrCreateReferenceSpace",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrCreateReferenceSpace")) succeeded = false;
            f_native_xrCreateReferenceSpace = Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateReferenceSpace>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrCreateActionSpace",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrCreateActionSpace")) succeeded = false;
            f_native_xrCreateActionSpace = Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateActionSpace>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrLocateSpace",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrLocateSpace")) succeeded = false;
            f_native_xrLocateSpace = Marshal.GetDelegateForFunctionPointer<delg_native_xrLocateSpace>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrEnumerateViewConfigurationViews",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrEnumerateViewConfigurationViews")) succeeded = false;
            f_native_xrEnumerateViewConfigurationViews = Marshal.GetDelegateForFunctionPointer<delg_native_xrEnumerateViewConfigurationViews>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrLocateViews",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrLocateViews")) succeeded = false;
            f_native_xrLocateViews = Marshal.GetDelegateForFunctionPointer<delg_native_xrLocateViews>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrPollEvent",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrPollEvent")) succeeded = false;
            f_native_xrPollEvent = Marshal.GetDelegateForFunctionPointer<delg_native_xrPollEvent>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrStringToPath",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrStringToPath")) succeeded = false;
            f_native_xrStringToPath = Marshal.GetDelegateForFunctionPointer<delg_native_xrStringToPath>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrPathToString",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrPathToString")) succeeded = false;
            f_native_xrPathToString = Marshal.GetDelegateForFunctionPointer<delg_native_xrPathToString>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetActionStateBoolean",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetActionStateBoolean")) succeeded = false;
            f_native_xrGetActionStateBoolean = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStateBoolean>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetActionStateFloat",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetActionStateFloat")) succeeded = false;
            f_native_xrGetActionStateFloat = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStateFloat>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetActionStateVector2f",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetActionStateVector2f")) succeeded = false;
            f_native_xrGetActionStateVector2f = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStateVector2f>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetActionStatePose",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetActionStatePose")) succeeded = false;
            f_native_xrGetActionStatePose = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStatePose>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrCreateActionSet",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrCreateActionSet")) succeeded = false;
            f_native_xrCreateActionSet = Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateActionSet>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrCreateAction",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrCreateAction")) succeeded = false;
            f_native_xrCreateAction = Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateAction>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrSuggestInteractionProfileBindings",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrSuggestInteractionProfileBindings")) succeeded = false;
            f_native_xrSuggestInteractionProfileBindings = Marshal.GetDelegateForFunctionPointer<delg_native_xrSuggestInteractionProfileBindings>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrAttachSessionActionSets",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrAttachSessionActionSets")) succeeded = false;
            f_native_xrAttachSessionActionSets = Marshal.GetDelegateForFunctionPointer<delg_native_xrAttachSessionActionSets>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrGetCurrentInteractionProfile",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrGetCurrentInteractionProfile")) succeeded = false;
            f_native_xrGetCurrentInteractionProfile = Marshal.GetDelegateForFunctionPointer<delg_native_xrGetCurrentInteractionProfile>(funcPtr);

            xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrSyncActions",out funcPtr);
            if (!checkResult(xrResult,"getAddr:xrSyncActions")) succeeded = false;
            f_native_xrSyncActions = Marshal.GetDelegateForFunctionPointer<delg_native_xrSyncActions>(funcPtr);

            /*  =================================================================================
                Hand-crafted function section: timing is tricky, and finish up the setup.
                ================================================================================= */
            #if (UNITY_WINDOWS || UNITY_EDITOR_WIN) 
                if (OpenXRRuntime.IsExtensionEnabled("XR_KHR_win32_convert_performance_counter_time")){
                    xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"xrConvertWin32PerformanceCounterToTimeKHR",out funcPtr);
                    if (!checkResult(xrResult,"getAddr:xrConvertWin32PerformanceCounterToTimeKHR")) succeeded = false;
                    f_xrConvertWin32PerformanceCounterToTimeKHR = Marshal.GetDelegateForFunctionPointer<delg_xrConvertWin32PerformanceCounterToTimeKHR>(funcPtr);
                }
            #elif UNITY_ANDROID
                if (OpenXRRuntime.IsExtensionEnabled("XR_KHR_convert_timespec_time")){
                    xrResult = f_native_xrGetInstanceProcAddr(m_xrInstanceHandle,"getAddr:xrConvertTimespecTimeToTimeKHR",out funcPtr);
                    if (!checkResult(xrResult,"getAddr:xrConvertTimespecTimeToTimeKHR")) succeeded = false;
                    else f_xrConvertTimespecTimeToTimeKHR = Marshal.GetDelegateForFunctionPointer<delg_xrConvertTimespecTimeToTimeKHR>(funcPtr);
                }
            #endif
            
            Log.I(TAG, "Obtained OpenXR function pointers");
            return succeeded;

        }
        private void TeardownInterop(){
            f_native_xrGetInstanceProcAddr = null;
            f_native_xrEnumerateApiLayerProperties = null;
            f_native_xrResultToString = null;
            f_native_xrGetSystem = null;
            f_native_xrGetSystemProperties = null;
            f_native_xrDestroySpace = null;
            f_native_xrCreateReferenceSpace = null;
            f_native_xrCreateActionSpace = null;
            f_native_xrLocateSpace = null;
            f_native_xrEnumerateViewConfigurationViews = null;
            f_native_xrLocateViews = null;
            f_native_xrPollEvent = null;
            f_native_xrStringToPath = null;
            f_native_xrPathToString = null;
            f_native_xrGetActionStateBoolean = null;
            f_native_xrGetActionStateFloat = null;
            f_native_xrGetActionStateVector2f = null;
            f_native_xrGetActionStatePose = null;
            f_native_xrCreateActionSet = null;
            f_native_xrCreateAction = null;
            f_native_xrSuggestInteractionProfileBindings = null;
            f_native_xrAttachSessionActionSets = null;
            f_native_xrGetCurrentInteractionProfile = null;
            f_native_xrSyncActions = null;
        }


    /* =================================================================================
       Hand-crafted section: Setup / teardown session
       ================================================================================= */

        protected override void OnSessionCreate(ulong session) {
            m_xrSessionHandle = session;
            XrResult xrResult;
        }
        protected override void OnSessionDestroy(ulong session) {
            m_xrSessionHandle = 0;
        }
                
    /* =================================================================================
       Hand-crafted section: Hooking
       ================================================================================= */
        // https://registry.khronos.org/OpenXR/specs/1.0/man/html/xrGetInstanceProcAddr.html
        // delegate XrResult delg_native_xrGetInstanceProcAddr(System.UInt64 a, [MarshalAs(UnmanagedType.LPUTF8Str)] string b, out System.IntPtr c);
        delegate XrResult delg_native_xrGetInstanceProcAddr(System.UInt64 a, [MarshalAs(UnmanagedType.LPStr)] string b, out System.IntPtr c);
        private delg_native_xrGetInstanceProcAddr f_native_xrGetInstanceProcAddr = null;
        private delg_native_xrGetInstanceProcAddr f_oxr_native_xrGetInstanceProcAddr = null;

        private System.IntPtr fp_oxr_native_xrGetInstanceProcAddr=System.IntPtr.Zero;
        protected override System.IntPtr HookGetInstanceProcAddr(System.IntPtr func) {
            // OpenXRFeature.HookGetInstancProcAddr defined prototype
            // Part of Unity OpenXRFeature, not part of OpenXR
            fp_oxr_native_xrGetInstanceProcAddr = func;
            f_oxr_native_xrGetInstanceProcAddr = (delg_native_xrGetInstanceProcAddr)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetInstanceProcAddr>(func);
            Log.V(TAG, $"Hooking xrGetInstanceProcAddr {func}");
            System.Delegate d = new delg_native_xrGetInstanceProcAddr(hooked_xrGetInstanceProcAddr);
            return Marshal.GetFunctionPointerForDelegate(d);
        }
        [MonoPInvokeCallback]
        public static XrResult hooked_xrGetInstanceProcAddr(System.UInt64 instance,string name,out System.IntPtr function) {
            // Log.I(TAG, $"Hooked {name}");
            OpenXRFeatureBase thisish = OpenXRFeatureBase.theInstance;
            System.IntPtr tempPtr = System.IntPtr.Zero;
            XrResult xrResult = thisish.f_oxr_native_xrGetInstanceProcAddr(instance,name,out tempPtr);
            
            System.Delegate delg = null;

                switch(name) {
            /*  =================================================================================
                Code-generated sub-section: provide hooks to all the (overrideable) hook implementations
                ================================================================================= */
                case "xrEnumerateApiLayerProperties":
                    thisish.f_oxr_native_xrEnumerateApiLayerProperties = (delg_native_xrEnumerateApiLayerProperties)Marshal.GetDelegateForFunctionPointer<delg_native_xrEnumerateApiLayerProperties>(tempPtr);
                    delg = new delg_native_xrEnumerateApiLayerProperties(hooked_xrEnumerateApiLayerProperties);
                    break;
                case "xrResultToString":
                    thisish.f_oxr_native_xrResultToString = (delg_native_xrResultToString)Marshal.GetDelegateForFunctionPointer<delg_native_xrResultToString>(tempPtr);
                    delg = new delg_native_xrResultToString(hooked_xrResultToString);
                    break;
                case "xrGetSystem":
                    thisish.f_oxr_native_xrGetSystem = (delg_native_xrGetSystem)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetSystem>(tempPtr);
                    delg = new delg_native_xrGetSystem(hooked_xrGetSystem);
                    break;
                case "xrGetSystemProperties":
                    thisish.f_oxr_native_xrGetSystemProperties = (delg_native_xrGetSystemProperties)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetSystemProperties>(tempPtr);
                    delg = new delg_native_xrGetSystemProperties(hooked_xrGetSystemProperties);
                    break;
                case "xrDestroySpace":
                    thisish.f_oxr_native_xrDestroySpace = (delg_native_xrDestroySpace)Marshal.GetDelegateForFunctionPointer<delg_native_xrDestroySpace>(tempPtr);
                    delg = new delg_native_xrDestroySpace(hooked_xrDestroySpace);
                    break;
                case "xrCreateReferenceSpace":
                    thisish.f_oxr_native_xrCreateReferenceSpace = (delg_native_xrCreateReferenceSpace)Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateReferenceSpace>(tempPtr);
                    delg = new delg_native_xrCreateReferenceSpace(hooked_xrCreateReferenceSpace);
                    break;
                case "xrCreateActionSpace":
                    thisish.f_oxr_native_xrCreateActionSpace = (delg_native_xrCreateActionSpace)Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateActionSpace>(tempPtr);
                    delg = new delg_native_xrCreateActionSpace(hooked_xrCreateActionSpace);
                    break;
                case "xrLocateSpace":
                    thisish.f_oxr_native_xrLocateSpace = (delg_native_xrLocateSpace)Marshal.GetDelegateForFunctionPointer<delg_native_xrLocateSpace>(tempPtr);
                    delg = new delg_native_xrLocateSpace(hooked_xrLocateSpace);
                    break;
                case "xrEnumerateViewConfigurationViews":
                    thisish.f_oxr_native_xrEnumerateViewConfigurationViews = (delg_native_xrEnumerateViewConfigurationViews)Marshal.GetDelegateForFunctionPointer<delg_native_xrEnumerateViewConfigurationViews>(tempPtr);
                    delg = new delg_native_xrEnumerateViewConfigurationViews(hooked_xrEnumerateViewConfigurationViews);
                    break;
                case "xrLocateViews":
                    thisish.f_oxr_native_xrLocateViews = (delg_native_xrLocateViews)Marshal.GetDelegateForFunctionPointer<delg_native_xrLocateViews>(tempPtr);
                    delg = new delg_native_xrLocateViews(hooked_xrLocateViews);
                    break;
                case "xrPollEvent":
                    thisish.f_oxr_native_xrPollEvent = (delg_native_xrPollEvent)Marshal.GetDelegateForFunctionPointer<delg_native_xrPollEvent>(tempPtr);
                    delg = new delg_native_xrPollEvent(hooked_xrPollEvent);
                    break;
                case "xrStringToPath":
                    thisish.f_oxr_native_xrStringToPath = (delg_native_xrStringToPath)Marshal.GetDelegateForFunctionPointer<delg_native_xrStringToPath>(tempPtr);
                    delg = new delg_native_xrStringToPath(hooked_xrStringToPath);
                    break;
                case "xrPathToString":
                    thisish.f_oxr_native_xrPathToString = (delg_native_xrPathToString)Marshal.GetDelegateForFunctionPointer<delg_native_xrPathToString>(tempPtr);
                    delg = new delg_native_xrPathToString(hooked_xrPathToString);
                    break;
                case "xrGetActionStateBoolean":
                    thisish.f_oxr_native_xrGetActionStateBoolean = (delg_native_xrGetActionStateBoolean)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStateBoolean>(tempPtr);
                    delg = new delg_native_xrGetActionStateBoolean(hooked_xrGetActionStateBoolean);
                    break;
                case "xrGetActionStateFloat":
                    thisish.f_oxr_native_xrGetActionStateFloat = (delg_native_xrGetActionStateFloat)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStateFloat>(tempPtr);
                    delg = new delg_native_xrGetActionStateFloat(hooked_xrGetActionStateFloat);
                    break;
                case "xrGetActionStateVector2f":
                    thisish.f_oxr_native_xrGetActionStateVector2f = (delg_native_xrGetActionStateVector2f)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStateVector2f>(tempPtr);
                    delg = new delg_native_xrGetActionStateVector2f(hooked_xrGetActionStateVector2f);
                    break;
                case "xrGetActionStatePose":
                    thisish.f_oxr_native_xrGetActionStatePose = (delg_native_xrGetActionStatePose)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetActionStatePose>(tempPtr);
                    delg = new delg_native_xrGetActionStatePose(hooked_xrGetActionStatePose);
                    break;
                case "xrCreateActionSet":
                    thisish.f_oxr_native_xrCreateActionSet = (delg_native_xrCreateActionSet)Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateActionSet>(tempPtr);
                    delg = new delg_native_xrCreateActionSet(hooked_xrCreateActionSet);
                    break;
                case "xrCreateAction":
                    thisish.f_oxr_native_xrCreateAction = (delg_native_xrCreateAction)Marshal.GetDelegateForFunctionPointer<delg_native_xrCreateAction>(tempPtr);
                    delg = new delg_native_xrCreateAction(hooked_xrCreateAction);
                    break;
                case "xrSuggestInteractionProfileBindings":
                    thisish.f_oxr_native_xrSuggestInteractionProfileBindings = (delg_native_xrSuggestInteractionProfileBindings)Marshal.GetDelegateForFunctionPointer<delg_native_xrSuggestInteractionProfileBindings>(tempPtr);
                    delg = new delg_native_xrSuggestInteractionProfileBindings(hooked_xrSuggestInteractionProfileBindings);
                    break;
                case "xrAttachSessionActionSets":
                    thisish.f_oxr_native_xrAttachSessionActionSets = (delg_native_xrAttachSessionActionSets)Marshal.GetDelegateForFunctionPointer<delg_native_xrAttachSessionActionSets>(tempPtr);
                    delg = new delg_native_xrAttachSessionActionSets(hooked_xrAttachSessionActionSets);
                    break;
                case "xrGetCurrentInteractionProfile":
                    thisish.f_oxr_native_xrGetCurrentInteractionProfile = (delg_native_xrGetCurrentInteractionProfile)Marshal.GetDelegateForFunctionPointer<delg_native_xrGetCurrentInteractionProfile>(tempPtr);
                    delg = new delg_native_xrGetCurrentInteractionProfile(hooked_xrGetCurrentInteractionProfile);
                    break;
                case "xrSyncActions":
                    thisish.f_oxr_native_xrSyncActions = (delg_native_xrSyncActions)Marshal.GetDelegateForFunctionPointer<delg_native_xrSyncActions>(tempPtr);
                    delg = new delg_native_xrSyncActions(hooked_xrSyncActions);
                    break;
                }
                if (delg==null) {
                    function = tempPtr;
                    Log.D(TAG, $"Hooked {name} : {xrResult} : passed-through");
                }
                else {
                    function = Marshal.GetFunctionPointerForDelegate(delg);
                    Log.D(TAG, $"Hooked {name} : {xrResult} : intercepted");
                }
            return xrResult;
        }

    }


}
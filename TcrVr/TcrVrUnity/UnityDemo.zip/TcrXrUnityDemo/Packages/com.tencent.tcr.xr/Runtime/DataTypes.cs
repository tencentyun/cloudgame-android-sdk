using UnityEngine;
using UnityEngine.XR;


namespace TCR {

    public enum TrackingEventType { noEvent, added, removed, trackingAcquired, trackingLost }
    public struct TrackingState {
        public TrackingEventType lastTrackingEvent;
        public XRNode nodeType;
        public XRNodeState nodeState;
        // ToString: print all fields
        public override string ToString() {
            return "lastTrackingEvent:" + lastTrackingEvent + " nodeType:" + nodeType + " nodeState:" + nodeState;
        }
    }
    
    public struct InputStateData {
        public XRNode xrnode;
        public string openxrPath;
        public string usageType; // used to select the right "template" for GetUsage
        public bool valid;
        public float floatVal;
        public bool boolVal;
        public Vector2 vector2Val;

        public override string ToString()
        {
            return $"valid: {valid}, floatVal: {floatVal}, boolVal: {boolVal}";
        }
    }
}
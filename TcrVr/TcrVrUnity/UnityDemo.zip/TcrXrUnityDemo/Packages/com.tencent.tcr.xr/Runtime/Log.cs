using System;
using UnityEngine;

namespace TCR {
    public enum DebugLevel{
        Verbose = 0,
        Debug = 1,
        Info = 2,
        Warning = 3,
        Error = 4,
    }
    public class Log {
        public static DebugLevel debugLevel = DebugLevel.Debug;
        public static void LogAtLevel(string tag, string msg, DebugLevel lvl) {
            if (lvl >= debugLevel) {
                int MAX_LENGTH = 3800;
                if (msg.Length > MAX_LENGTH) {
                    int lines = (int)Math.Ceiling((double)msg.Length / MAX_LENGTH);
                    for (int i = 0; i < lines; i++) {
                        int start = i * MAX_LENGTH;
                        int end = Math.Min(start + MAX_LENGTH, msg.Length);
                        Debug.Log($"[TCR][{lvl}] {tag}: {msg.Substring(start, end - start)}");
                    }   
                } else {
                    Debug.Log($"[TCR][{lvl}] {tag}: {msg}");
                }
            }
        }

        public static void Assert(string tag, bool wannaBeTrue, string msg) {
            if (!wannaBeTrue) {
                E(tag, msg);
            }
        }

        public static void V(string tag, string msg) => LogAtLevel(tag, msg,DebugLevel.Verbose);
        public static void D(string tag, string msg) => LogAtLevel(tag, msg,DebugLevel.Debug);
        public static void I(string tag, string msg) => LogAtLevel(tag, msg,DebugLevel.Info);
        public static void W(string tag, string msg) => LogAtLevel(tag, msg,DebugLevel.Warning);
        public static void E(string tag, string msg) => LogAtLevel(tag, msg,DebugLevel.Error);
    }
}
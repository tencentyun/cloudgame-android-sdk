using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEditor;

using TCR;

namespace OXR
{
    using XrAction = System.UInt64;
    using XrActionSet = System.UInt64;
    using XrInstance = System.UInt64;
    using XrPath = System.UInt64;
    using XrSession = System.UInt64;
    using XrSpace = System.UInt64;
    using XrTime = System.Int64;

    public struct SpaceLoc {
        public XrPosef pose;

        public XrVector3f linearVelocity;
        public XrVector3f angularVelocity ;

        public static SpaceLoc Identity = new() {
            pose = new() {
                orientation = new() {
                    x = 0,
                    y = 0,
                    z = 0,
                    w = 1
                },
                position = new() {
                    x = 0,
                    y = 0,
                    z = 0           
                }
            },
            linearVelocity = new XrVector3f() {
                x = 0,
                y = 0,
                z = 0
            },
            angularVelocity = new XrVector3f() {
                x = 0,
                y = 0,
                z = 0
            }
        };
    }

    #if UNITY_EDITOR
    [UnityEditor.XR.OpenXR.Features.OpenXRFeature(UiName = "CloudXR Tuned Pose Capture",
        BuildTargetGroups = new []{BuildTargetGroup.Standalone, BuildTargetGroup.Android},
        Company = "TCR",
        Desc = "CloudXR requires poses at precisely known times, which are not provided by the Unity XR APIs (by reasonable design intention).",
        OpenxrExtensionStrings = "XR_KHR_convert_timespec_time XR_META_headset_id", 
        Version = "0.0.1",
        FeatureId = featureId)]
    #endif
    class TcrOpenXRFeature : OpenXRFeatureBase {
        private static readonly string TAG = "TcrOpenXRFeature";
        public const string featureId = "com.tcr.cloudxr.openxrfeature";

        public bool xrRunning {
            get {return (m_xrInstanceHandle!=0); }
        }

        private struct ReferenceSpaceInfo {
            public XrReferenceSpaceType type;
            public XrReferenceSpaceCreateInfo createInfo;
            public XrSpace spaceHandle;
        }
        Dictionary<XrSpace,ReferenceSpaceInfo> m_referenceSpaceLookup_space_to_info = new Dictionary<XrSpace,ReferenceSpaceInfo>();
        ReferenceSpaceInfo stageSpace;
        protected override XrResult hooked_method_xrCreateReferenceSpace(XrSession session, ref XrReferenceSpaceCreateInfo createInfo, ref XrSpace space) {
            XrResult result = f_oxr_native_xrCreateReferenceSpace(session, ref createInfo, ref space);
            Log.D(TAG, $"Unity created a reference space: {createInfo.referenceSpaceType} : {result}");
            if (result==XrResult.XR_SUCCESS) {
                XrVector3f p = new XrVector3f {
                    x = createInfo.poseInReferenceSpace.position.x,
                    y = createInfo.poseInReferenceSpace.position.y,
                    z = createInfo.poseInReferenceSpace.position.z,
                };
                XrQuaternionf q = new XrQuaternionf{
                    x = createInfo.poseInReferenceSpace.orientation.x,
                    y = createInfo.poseInReferenceSpace.orientation.y,
                    z = createInfo.poseInReferenceSpace.orientation.z,
                    w = createInfo.poseInReferenceSpace.orientation.w,
                };
                Log.D(TAG, $"Unity pose in reference space: pos=({p.x},{p.y},{p.z}; quat=({q.x},{q.y},{q.z},{q.w})");
                m_referenceSpaceLookup_space_to_info[space] = new ReferenceSpaceInfo {
                    type = createInfo.referenceSpaceType,
                    // New-ify everything in sight to ensure memory safety
                    createInfo = new XrReferenceSpaceCreateInfo{
                        type = createInfo.type,
                        next = System.IntPtr.Zero,
                        referenceSpaceType = createInfo.referenceSpaceType,
                        poseInReferenceSpace = new XrPosef{
                            orientation = q,
                            position = p,
                        }
                    },
                    spaceHandle = space,
                };
                if (createInfo.referenceSpaceType == XrReferenceSpaceType.XR_REFERENCE_SPACE_TYPE_STAGE) {
                    if (stageSpace.spaceHandle == 0) {
                        stageSpace = m_referenceSpaceLookup_space_to_info[space];
                    }
                }
            }
            return result;
        }

        private Dictionary<XrPath,XrActionSuggestedBinding[]> currentBindings = new Dictionary<XrPath,XrActionSuggestedBinding[]>();
        protected override XrResult hooked_method_xrSuggestInteractionProfileBindings(XrInstance instance, ref XrInteractionProfileSuggestedBinding suggestedBindings) {
            XrResult result = f_oxr_native_xrSuggestInteractionProfileBindings(instance, ref suggestedBindings);

            XrPath interactionProfile = suggestedBindings.interactionProfile;
            foreach (XrActionSuggestedBinding suggestion in suggestedBindings.suggestedBindings_managed) {
                string path_b;
                XrResult result_inner = f_xrPathToString(m_xrInstanceHandle,suggestion.binding,out path_b);
                Log.D(TAG, $"    {suggestion.action} --> {suggestion.binding} : {path_b}   ({result_inner})");
            }
            if (result == XrResult.XR_SUCCESS) {
                foreach (XrActionSuggestedBinding suggestion in suggestedBindings.suggestedBindings_managed) {
                    XrPath p = suggestion.binding;
                    if (!currentBindings.ContainsKey(p)) {
                        currentBindings[p] = new XrActionSuggestedBinding[] {suggestion,};
                    } else {
                        XrActionSuggestedBinding[] old = currentBindings[p];
                        XrActionSuggestedBinding[] updated = new XrActionSuggestedBinding[old.Length+1];
                        System.Array.Copy(old, updated, old.Length);
                        updated[old.Length] = suggestion;
                        currentBindings[p] = updated;
                    }
                }
            }
            return result;
        }

        private Dictionary<XrActionSet,string> actionSetNames = new Dictionary<XrAction, string>();
        protected override XrResult hooked_method_xrCreateActionSet(XrInstance instance, ref XrActionSetCreateInfo createInfo, ref XrActionSet actionSet) {
            XrResult result = f_oxr_native_xrCreateActionSet(instance, ref createInfo, ref actionSet);
            Log.D(TAG, $"Unity xrCreateActionSet: {result} from {createInfo.actionSetName}");
            if (result==XrResult.XR_SUCCESS) {
                actionSetNames[actionSet] = createInfo.actionSetName.Value;
            }
            return result;
        }


        private Dictionary<XrPath,string> pathsToStrings = new Dictionary<XrAction, string>();
        protected override XrResult hooked_method_xrStringToPath(XrInstance instance, string pathString, ref XrPath path) {
            XrResult result = f_oxr_native_xrStringToPath(instance, pathString, ref path);
            Log.D(TAG, $"Unity applied for path {pathString} with result {result}");
            if (result == XrResult.XR_SUCCESS) {
                pathsToStrings[path] = pathString;
            }
            return result;
        }

        private struct OxrActionData {
            public XrAction actionHandle;
            public XrActionSet actionSet;
            public string actionName;
            public XrActionType actionType;
            public XrPath[] subactionPaths;
            public OxrString128 localizedActionName;
        }
        private Dictionary<XrAction,OxrActionData> actionLookup = new Dictionary<XrAction, OxrActionData>();
        protected override XrResult hooked_method_xrCreateAction(XrActionSet actionSet, ref XrActionCreateInfo createInfo, ref XrAction action) {
            XrResult result = f_oxr_native_xrCreateAction(actionSet, ref createInfo, ref action);
            string msg = $"Unity xrCreateAction: {result} from {createInfo.actionName.Value}, {createInfo.actionType}, {createInfo.countSubactionPaths}, {createInfo.localizedActionName.Value}";
            foreach (XrPath p in createInfo.subactionPaths_managed) {
                msg += $", {p}, {pathsToStrings[p]}";
            }
            Log.D(TAG, msg);
            if (result == XrResult.XR_SUCCESS) {
                actionLookup[action] = new OxrActionData {
                    actionHandle = action,
                    actionSet = actionSet,
                    actionName = createInfo.actionName.Value,
                    actionType = createInfo.actionType,
                    subactionPaths = createInfo.subactionPaths_managed,
                    localizedActionName = createInfo.localizedActionName,
                };
            }
            return result;
        }

        private struct OxrSpaceData {
            public OxrActionData actionData;
            public string actionSetName;
            public XrActionSpaceCreateInfo createInfo;
        }
        private Dictionary<XrSpace,OxrSpaceData> spaceLookup = new Dictionary<XrSpace,OxrSpaceData>();
        protected override XrResult hooked_method_xrCreateActionSpace(XrSession session, ref XrActionSpaceCreateInfo createInfo, ref XrSpace space) {
            XrResult result = f_oxr_native_xrCreateActionSpace(session, ref createInfo, ref space);

            XrPosef p = createInfo.poseInActionSpace;
            XrQuaternionf T = p.orientation;
            XrVector3f X = p.position;
            Log.D(TAG, $"Unity xrCreateActionSpace:"
                    + $" {result} = {createInfo.action}, {createInfo.subactionPath}, {pathsToStrings[createInfo.subactionPath]}"
                    + $", ({X.x},{X.y},{X.z}), ({T.x},{T.y},{T.z},{T.w}) ");

            if (result==XrResult.XR_SUCCESS) {
                // This is safe because the above call would not be successful without a valid action which will be in our dictionary
                OxrActionData data = actionLookup[createInfo.action];
                // This is safe because the above call would not be successful without a valid action>actionSet which will be in our dictionary
                string actionSetName = actionSetNames[data.actionSet];
                Log.D(TAG, $"KNOWN SPACE: {pathsToStrings[createInfo.subactionPath]}, {data.actionName} / {data.localizedActionName.Value}, {data.actionSet}, {actionSetName} ");
                spaceLookup[space] = new OxrSpaceData {
                    actionData = data,
                    actionSetName = actionSetName,
                    createInfo = createInfo,
                };
            }
            return result;
        }

        public bool GetViewPoses(out XrView leftView, out XrView rightView) {
            if (!xrRunning) {
                leftView = new XrView {};
                rightView = new XrView {};
                return false;
            }

            XrTime targetTime = GetXrTimeNow(); // NOW
            // XrTime targetTime = m_latestFrameState.predictedDisplayTime;  // when Oxr expects the next/current frame to be displayed
            XrViewLocateInfo viewLocateInfo = new XrViewLocateInfo {
                type = XrStructureType.XR_TYPE_VIEW_LOCATE_INFO, 
                next = System.IntPtr.Zero,
                viewConfigurationType = XrViewConfigurationType.XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,
                displayTime = targetTime,
                space = stageSpace.spaceHandle
                };
            XrViewState viewState = new XrViewState {
                type = XrStructureType.XR_TYPE_VIEW_STATE, 
                next = System.IntPtr.Zero
                // Remainder of structure is output parameters.
            };
            XrView[] views;
            XrResult result = f_xrLocateViews(m_xrSessionHandle,ref viewLocateInfo,ref viewState,out views);
            if (result != XrResult.XR_SUCCESS) {
                Log.W(TAG, $"xrLocateViews failed: {result}");
                leftView = new XrView {};
                rightView = new XrView {};
                return false;
            }
            leftView = views[0];
            rightView = views[1];
            return true;
        }

        protected override bool OnInstanceCreate(ulong instance) {
            base.OnInstanceCreate(instance);
            return true;
        }
        protected override void OnInstanceDestroy(ulong instance) {
            base.OnInstanceDestroy(instance);
        }


        protected override void OnSessionCreate(ulong session) {
            base.OnSessionCreate(session);

            // Allocate an unmanaged pointer for the Velocity struct. So... much... indirection...
            m_velocityStructPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(XrSpaceVelocity)));
            m_velocityStruct = new XrSpaceVelocity{type=XrStructureType.XR_TYPE_SPACE_VELOCITY};
            Marshal.StructureToPtr(m_velocityStruct, m_velocityStructPtr, false);
        }
        protected override void OnSessionDestroy(ulong session) {
            base.OnSessionDestroy(session);
            Marshal.FreeHGlobal(m_velocityStructPtr);
        }
              

        public System.UInt64 GetXrPath(string pathString) {
            XrPath outPath = (XrPath)0;
            XrResult result = f_xrStringToPath(m_xrInstanceHandle, pathString, ref outPath);
            if (result == XrResult.XR_SUCCESS){
                if (!pathsToStrings.ContainsKey(outPath)) {
                    pathsToStrings[outPath] = pathString;
                }
                return (System.UInt64)outPath;
            }
            else {
                return (System.UInt64)0;
            } 
        }

        private System.IntPtr m_velocityStructPtr;
        private XrSpaceVelocity m_velocityStruct;

        private XrSpace GetSpace(System.UInt64 componentPath) {
            XrSpace matchedSpace = (XrSpace)0;
            // The higher-level library presumably pulled a component path that makes sense. Grab it from the interaction profile.
            XrPath oxrPath = (XrPath)componentPath;
            if (!currentBindings.ContainsKey(oxrPath)) {
                Log.W(TAG, "NOPOSE: path not in bindings");
                return (XrSpace)0;
            }
            OxrSpaceData spaceData = new OxrSpaceData{
                actionSetName = "n/a",
                actionData = new OxrActionData {
                    actionName = "",
                },
            };
            XrActionSuggestedBinding[] bindings = currentBindings[componentPath];
            bool match = false;

            string componentPathString = "";
            foreach(XrActionSuggestedBinding binding in bindings) {
                componentPathString = pathsToStrings[binding.binding];
                // We're looking for poses. If this is a grip pose, ignore it.
                // if (componentPathString.Contains("grip")) {
                //     continue;
                // }

                foreach(XrSpace space in spaceLookup.Keys) {
                    spaceData = spaceLookup[space];
                    matchedSpace = space;
                    string userRoot = pathsToStrings[spaceData.createInfo.subactionPath];
                    match = (
                        (spaceData.actionData.actionHandle == binding.action)
                        && (componentPathString.StartsWith(userRoot))
                    );
                    if (match) break;
                }
            }
            if (!match) {
                Log.W(TAG, "NOPOSE: no space matches");
                return (XrSpace)0;
            }
            return matchedSpace;
        }




        public SpaceLoc GetNodePose(System.UInt64 componentPath) {
            SpaceLoc result = SpaceLoc.Identity;

            if (!xrRunning) {
                Log.W(TAG, "GetNodePose() xr not running");
                return result;
            }

            XrSpace matchedSpace = GetSpace(componentPath);
            if (matchedSpace==(XrSpace)0) {
                Log.W(TAG, "GetNodePose() matchedSpace=0");
                return result;
            }

            // We have a matching space! Get the gorram pose.
            XrSpace refSpace = stageSpace.spaceHandle;
            XrTime now = GetXrTimeNow();
            XrSpaceLocation location = new()
            {
                type = XrStructureType.XR_TYPE_SPACE_LOCATION,
                next = m_velocityStructPtr
            };

            XrResult res = f_xrLocateSpace(matchedSpace,refSpace,now,ref location);
            if (res != XrResult.XR_SUCCESS) {
                Log.W(TAG, $"NOPOSE: unsucessful call to locateSpace {result}");
                return result;
            }

            XrSpaceVelocity velocity = (XrSpaceVelocity)Marshal.PtrToStructure<XrSpaceVelocity>(m_velocityStructPtr);
            bool linear_position_valid = ((XrSpaceLocationFlagBits)location.locationFlags & XrSpaceLocationFlagBits.XR_SPACE_LOCATION_POSITION_VALID_BIT)>0;
            if (linear_position_valid) {
                result.pose.position = location.pose.position;
            }
            bool angular_position_valid = ((XrSpaceLocationFlagBits)location.locationFlags & XrSpaceLocationFlagBits.XR_SPACE_LOCATION_ORIENTATION_VALID_BIT)>0;
            if (angular_position_valid) {
                result.pose.orientation = location.pose.orientation;
            }
            bool linear_velocity_valid = ((XrSpaceVelocityFlagBits)velocity.velocityFlags & XrSpaceVelocityFlagBits.XR_SPACE_VELOCITY_LINEAR_VALID_BIT)>0;
            if (linear_velocity_valid) {
                result.linearVelocity = velocity.linearVelocity;
            }
            bool angular_velocity_valid = ((XrSpaceVelocityFlagBits)velocity.velocityFlags & XrSpaceVelocityFlagBits.XR_SPACE_VELOCITY_ANGULAR_VALID_BIT)>0;
            if (angular_velocity_valid) {
                result.angularVelocity = velocity.angularVelocity;
            }
            return result;
        }

        public Dictionary<string,string> FingerprintRunningEnvironment() {
            Dictionary<string,string> thePrint = new Dictionary<string, string>();

            XrSystemGetInfo system = new XrSystemGetInfo{
                type=XrStructureType.XR_TYPE_SYSTEM_GET_INFO,
                formFactor=XrFormFactor.XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY,
                };
            System.UInt64 system_id = 0;
            XrResult result = f_xrGetSystem(m_xrInstanceHandle,ref system, ref system_id);
            Log.I(TAG, $"xrGetSystem -> {result} : {system.formFactor}, {system_id}");
            XrSystemProperties system_props = new XrSystemProperties{type=XrStructureType.XR_TYPE_SYSTEM_PROPERTIES};
            result = f_xrGetSystemProperties(m_xrInstanceHandle,system_id,ref system_props);
            Log.I(TAG, $"xrGetSystemProperties -> {result} : {system_props.vendorId}, {system_props.systemName.Value}, {system_props.graphicsProperties.maxSwapchainImageHeight}, {system_props.graphicsProperties.maxSwapchainImageWidth}, {system_props.graphicsProperties.maxLayerCount}");
            thePrint["OpenXR.XrSystemProperties.systemName"] = system_props.systemName.Value;
            thePrint["OpenXR.XrSystemProperties.graphicsProperties.maxSwapchainImageHeight"] = $"{system_props.graphicsProperties.maxSwapchainImageHeight}";
            thePrint["OpenXR.XrSystemProperties.graphicsProperties.maxSwapchainImageWidth"] = $"{system_props.graphicsProperties.maxSwapchainImageWidth}";
            thePrint["OpenXR.XrSystemProperties.graphicsProperties.maxLayerCount"] = $"{system_props.graphicsProperties.maxLayerCount}";
            thePrint["OpenXR.XrSystemProperties.trackingProperties.orientationTracking"] = $"{system_props.trackingProperties.orientationTracking}";
            thePrint["OpenXR.XrSystemProperties.trackingProperties.positionTracking"] = $"{system_props.trackingProperties.positionTracking}";
            XrViewConfigurationView[] cs_views;
            result = f_xrEnumerateViewConfigurationViews(m_xrInstanceHandle, system_id, XrViewConfigurationType.XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, out cs_views);
            Log.I(TAG, $"xrEnumerateViewConfigurationViews -> {result}:");
            for (int i=0; i<cs_views.Length; i++) {
                XrViewConfigurationView v = cs_views[i];
                thePrint[$"OpenXR.XrViewConfigurationView[{i}].recommendedImageRectHeight"] = $"{v.recommendedImageRectHeight}";
                thePrint[$"OpenXR.XrViewConfigurationView[{i}].recommendedImageRectWidth"] = $"{v.recommendedImageRectWidth}";
                thePrint[$"OpenXR.XrViewConfigurationView[{i}].recommendedSwapchainSampleCount"] = $"{v.recommendedSwapchainSampleCount}";
                thePrint[$"OpenXR.XrViewConfigurationView[{i}].maxImageRectHeight"] = $"{v.maxImageRectHeight}";
                thePrint[$"OpenXR.XrViewConfigurationView[{i}].maxImageRectWidth"] = $"{v.maxImageRectWidth}";
                thePrint[$"OpenXR.XrViewConfigurationView[{i}].maxSwapchainSampleCount"] = $"{v.maxSwapchainSampleCount}";
            }

            XrApiLayerProperties[] apiLayers;
            f_xrEnumerateApiLayerProperties(out apiLayers);
            for (int i=0; i<apiLayers.Length; i++) {
                XrApiLayerProperties l = apiLayers[i];
                thePrint[$"OpenXR.XrApiLayer.{l.layerName}"] = $"enabled at spec version {l.specVersion}, layer version {l.layerVersion}; {l.description}";
            }


            foreach( string extension in UnityEngine.XR.OpenXR.OpenXRRuntime.GetAvailableExtensions() ) {
                thePrint[$"OpenXR.AvailableExtensions.{extension}"] = "true";
            }
            foreach( string extension in UnityEngine.XR.OpenXR.OpenXRRuntime.GetEnabledExtensions() ) {
                thePrint[$"OpenXR.EnabledExtensions.{extension}"] = "true";
            }

            return thePrint;
        }

    }
}
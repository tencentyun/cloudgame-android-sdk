
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

using TCR.Base;
using OXR;

namespace TCR
{
    namespace Base {

        [System.Serializable]
        public class Vector2
        {
            public float x;
            public float y;
        }

        [System.Serializable]
        public class Vector3
        {
            public float x;
            public float y;
            public float z;
        }

        [System.Serializable]
        public class Vector4
        {
            public float w;
            public float x;
            public float y;
            public float z;
        }

        [System.Serializable]
        public class Pose
        {
            public Vector3 angular_velocity = new();
            public Vector3 linear_velocity = new();
            public Vector4 orientation = new();
            public Vector3 position = new();
        }

        [System.Serializable]
        public class BaseInput 
        {
            public string part;
            public string path;
        }

        [System.Serializable]
        public class BoolInput : BaseInput{
            public bool bool_value;
        }

        [System.Serializable]
        public class FloatInput : BaseInput{
            public float float_value;
        }

        [System.Serializable]
        public class Vector2Input : BaseInput{
            public Vector2 vector2f;
        }

        [System.Serializable]
        public class PoseInput : BaseInput{
            public Pose pose = new();
        }
    }

    public static class Utils {
        private static readonly string TAG = "Utils";
        public static string ToJsonElmentString(SpaceLoc spaceLoc, bool leftHand) {
            PoseInput input = new()
            {
                part = leftHand ? "/hand/left" : "/hand/right",
                path = "/grip/pose"
            };
            
            input.pose.position.x = spaceLoc.pose.position.x;
            input.pose.position.y  = spaceLoc.pose.position.y;
            input.pose.position.z = spaceLoc.pose.position.z;
            input.pose.orientation.x = spaceLoc.pose.orientation.x;
            input.pose.orientation.y = spaceLoc.pose.orientation.y;
            input.pose.orientation.z = spaceLoc.pose.orientation.z;
            input.pose.orientation.w = spaceLoc.pose.orientation.w; 
            input.pose.linear_velocity.x = spaceLoc.linearVelocity.x;
            input.pose.linear_velocity.y = spaceLoc.linearVelocity.y;
            input.pose.linear_velocity.z = spaceLoc.linearVelocity.z;
            input.pose.angular_velocity.x = spaceLoc.angularVelocity.x;
            input.pose.angular_velocity.y = spaceLoc.angularVelocity.y;
            input.pose.angular_velocity.z = spaceLoc.angularVelocity.z;
            return JsonUtility.ToJson(input);
        }

        public static List<BaseInput> ToBaseInputList(InputStateData[] inputStates) {
            List<BaseInput> result = new ();
            for(int idx=0; idx<inputStates.Length; idx++ ) {
                BaseInput input = null;
                InputStateData data = inputStates[idx];
                
                switch (data.usageType) {
                    case "bool":
                        input = new BoolInput();
                        ((BoolInput)input).bool_value = data.boolVal;
                        input.part = data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right";
                        input.path = data.openxrPath;
                        result.Add(input);
                    break;

                    case "float":
                        input = new FloatInput();
                        ((FloatInput)input).float_value = data.floatVal;
                        input.part = data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right";
                        input.path = data.openxrPath;
                        result.Add(input);
                    break;

                    case "Vector2":
                        // Vector2 to float value for /thumbstick/x and /thumbstick/y
                        input = new FloatInput();
                        ((FloatInput)input).float_value = data.vector2Val.x;
                        input.part = data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right";
                        input.path = data.openxrPath + "/x";
                        result.Add(input);

                        input = new FloatInput();
                        ((FloatInput)input).float_value = data.vector2Val.y;
                        input.part = data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right";
                        input.path = data.openxrPath + "/y";
                        result.Add(input);

                    break;

                    default:
                        Log.E(TAG, $"ToJson() not process data.usageType{data.usageType} for {data.openxrPath}");
                    break;
                }
            }   
            return result;
        }

        public static List<string> ToJsonElmentList(List<BaseInput> list) {
            List<string> result = new ();
            for (int idx = 0; idx < list.Count; idx++) {
                result.Add(JsonUtility.ToJson(list[idx]));
            }
            return result;
        }

        public static string ToJsonArrayString(List<string> jsonElementArray) {
            if (jsonElementArray.Count == 0)  {
                return "";
            }
            string result = "[";
            for (int idx = 0; idx < jsonElementArray.Count; idx++) {
                result += jsonElementArray[idx].ToString();
                if (idx != jsonElementArray.Count - 1) {
                    result += ",";
                }
            }
            result += "]";

            return result;
        }
    }
}
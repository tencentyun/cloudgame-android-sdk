namespace TCR
{
    /**
    * 需要发送到云端的视觉信息.
    */
    public class EyeInfo
    {
        /**
        * 左眼视场角。
        */
        public Fov leftFov;
        /**
        * 右眼视场角。
        */
        public Fov rightFov;
        /**
        * 双眼瞳距。
        */
        public float ipd;

        public EyeInfo(Fov leftFov, Fov rightFov, float ipd)
        {
            this.leftFov = leftFov;
            this.rightFov = rightFov;
            this.ipd = ipd;
        }

        public override string ToString()
        {
            return "EyeInfo{"
                    + "leftFov=" + leftFov
                    + ", rightFov=" + rightFov
                    + ", ipd=" + ipd
                    + '}';
        }
    }
}
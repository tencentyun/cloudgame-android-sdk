using UnityEngine;

[System.Serializable]
public class Pose
{

    private Vector3f positon;
    private Quaternion4f orientation;
    public Pose(Vector3f positon, Quaternion4f orientation) 
    {
        this.positon = positon;
        this.orientation = orientation;
    }

    public Vector3f getPosition() {
        return positon;
    }
    
    public Quaternion4f getOrientation() {
        return orientation;
    }
    
}
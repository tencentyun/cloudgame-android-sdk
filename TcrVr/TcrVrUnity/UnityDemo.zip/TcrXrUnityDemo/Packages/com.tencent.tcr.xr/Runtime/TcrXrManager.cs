using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.XR;
using UnityEngine.XR.OpenXR;

using OXR;

namespace TCR
{

    [DefaultExecutionOrder(-30001)]
    [AddComponentMenu("Tencent/TcrXrManager")]
    public class TcrXrManager : MonoBehaviour
    {

        private static readonly string TAG = "TcrXrManager";

        private VideoFrame m_lastFrame;

        private readonly object m_lockObject = new();

        private TcrOpenXRFeature m_openXRFeature = null;
        private bool m_isXrInitialized = false;
        private bool m_startInitSdk = false;
        private bool m_isSdkInitialized = false;
        private long m_lastCheckedTicks = 0;
        private static readonly long minTicksBetweenInitChecks = TimeSpan.TicksPerSecond/2;

        private readonly List<XRDisplaySubsystem> m_displaySubsystems = new();
        private XRDisplaySubsystem m_displaySubsystem = null;
        private readonly List<XRInputSubsystem> m_inputSubsystems = new();
        private XRInputSubsystem m_inputSubsystem = null;
        private readonly List<InputDevice> m_inputDevices = new();
        private readonly List<XRInputSubsystemDescriptor> m_inputDescs = new();
        private readonly Dictionary<XRNode,TrackingState> trackingStates = new();


        private bool IsXrInitialized() {
            // Check frequently to see if we should initialize.
            long now = DateTime.Now.Ticks;
            long interval = (now - m_lastCheckedTicks);
            if (interval < minTicksBetweenInitChecks) {
                return false;
            }
            m_lastCheckedTicks = now;

            // Check if the display subsystem is running.
            if (m_displaySubsystem == null) {
                m_displaySubsystems.Clear();
                SubsystemManager.GetSubsystems(m_displaySubsystems);

                Log.Assert(TAG, m_displaySubsystems.Count == 0 | m_displaySubsystems.Count == 1, "Only one XR DisplaySubsystem is supported.");
                
                if (m_displaySubsystems.Count == 1) {
                    m_displaySubsystem = m_displaySubsystems[0];
                } else {
                    Log.W(TAG, "No XR DisplaySubsystem is Running.");
                    return false;
                }
            }

            if (!m_displaySubsystem.running) {
                Log.W(TAG, "XR DisplaySubsystem is not Running.");
                return false;
            }

            if (XRSettings.eyeTextureWidth < 257) {
                Log.W(TAG, "Waiting for XR settings to load");
                return false;
            }

            // Check if the projection matrix is the Identity matrix, in which case, we're not fully initialized yet (*sigh*)
            Camera cam = GetXrCamera();
            if (cam == null) {
                Log.W(TAG, "No camera found");
                return false;
            } else if (cam.GetStereoViewMatrix(Camera.StereoscopicEye.Left).isIdentity) {
                Log.W(TAG, "Identiy matrix as stero matrix; XR not inited");
                return false;
            }

            // -----------------------------------------------------------------------------------------
            // Unity XR InputSubsystems
            if (m_inputDescs.Count == 0)
            {
                m_inputDescs.Clear();
                SubsystemManager.GetSubsystemDescriptors(m_inputDescs);
                Log.Assert(TAG, m_inputDescs.Count > 0, "This code must be compiled with at least one XR input (tracking) subsystem.");
            }

            if (m_inputSubsystem == null) {
                m_inputSubsystems.Clear();
                SubsystemManager.GetSubsystems(m_inputSubsystems);
                Log.Assert(TAG, (m_inputSubsystems.Count == 0) | (m_inputSubsystems.Count == 1), "Only one XR InputSubsystem is supported.");
                if (m_inputSubsystems.Count == 1) m_inputSubsystem = m_inputSubsystems[0];
            }

            // -----------------------------------------------------------------------------------------
            // Unity XRSettings
            // Yet another way to test if XR is initialized. *sigh*

            if (!XRSettings.isDeviceActive) {
                Log.W(TAG, "!XRSettings.isDeviceActive");
                return false;
            }

            // -----------------------------------------------------------------------------------------
            // Yet ANOTHER another way to test if XR is initialized
            if (m_openXRFeature == null) {
                m_openXRFeature = OpenXRSettings.Instance.GetFeature<TcrOpenXRFeature>();
            }

            if (m_openXRFeature == null || !m_openXRFeature.xrRunning) {
                Log.W(TAG, $"OpenxrFeature is not Running, m_openXRFeature:{m_openXRFeature}");
                return false;
            }

            return true;
        }


        // Update is called once per frame
        void Update()
        {
            if (!m_isXrInitialized) {
                m_isXrInitialized = IsXrInitialized();
            }

            if (m_isXrInitialized && m_startInitSdk) {
                DoInitTcrXrSdk();
            }

            if (m_isSdkInitialized) {
                UpdateControllers();
                FireControllerEvents();
            }
        }

        public TcrXrManager() {
            Log.I(TAG, "TcrXrManager()");
            // Register for new devices.
            InputDevices.deviceConnected += OnInputDeviceConnected;
            InputDevices.deviceDisconnected += OnInputDeviceDisconnected;
            InputDevices.deviceConfigChanged += OnInputDeviceConfigChanged;

            InputTracking.nodeAdded += OnNodeAdded;
            InputTracking.nodeRemoved += OnNodeRemoved;
            InputTracking.trackingAcquired += OnTrackingAcquired;
            InputTracking.trackingLost += OnTrackingLost;
        }

        ~TcrXrManager() {
            Log.I(TAG, "~TcrXrManager()");
            InputDevices.deviceConnected -= OnInputDeviceConnected;
            InputDevices.deviceDisconnected -= OnInputDeviceDisconnected;
            InputDevices.deviceConfigChanged -= OnInputDeviceConfigChanged;
            InputTracking.nodeAdded -= OnNodeAdded;
            InputTracking.nodeRemoved -= OnNodeRemoved;
            InputTracking.trackingAcquired -= OnTrackingAcquired;
            InputTracking.trackingLost -= OnTrackingLost;
        }

        private void OnNodeAdded(XRNodeState ns) { 
            OnTrackingChanged(ns,TrackingEventType.added); 
        }
        private void OnNodeRemoved(XRNodeState ns) { OnTrackingChanged(ns,TrackingEventType.removed); }
        private void OnTrackingAcquired(XRNodeState ns) { OnTrackingChanged(ns,TrackingEventType.trackingAcquired); }
        private void OnTrackingLost(XRNodeState ns) { OnTrackingChanged(ns,TrackingEventType.trackingLost); }
        private void OnTrackingChanged(XRNodeState nodeState, TrackingEventType evt ) {
            Log.V(TAG, "TrackingEvent "+evt+": "+nodeState.nodeType);
            if (!(trackingStates.ContainsKey(nodeState.nodeType))) {
                trackingStates[nodeState.nodeType] = new TrackingState();
            }
            TrackingState state = trackingStates[nodeState.nodeType];
            state.lastTrackingEvent = evt;
            state.nodeType = nodeState.nodeType;
            state.nodeState = nodeState;
            trackingStates[nodeState.nodeType] = state;

            // InputNodeChangedEvent?.Invoke(this,state);
            Log.V(TAG, "HandleInputNodeChanged() !! trackingStatesQueue.Count:"+ trackingStatesQueue.Count + " newState:" + state);
            trackingStatesQueue.Enqueue(state);
        }

        public delegate void HandleInputNodeChanged(object source, TrackingState newState);
        public event HandleInputNodeChanged InputNodeChangedEvent;

        private enum DeviceEventType { connected, disconnected, configChanged }
        private void OnInputDeviceConfigChanged(InputDevice d) { OnInputDeviceChanged(d,DeviceEventType.connected); }
        private void OnInputDeviceDisconnected(InputDevice d) { OnInputDeviceChanged(d,DeviceEventType.disconnected); }
        private void OnInputDeviceConnected(InputDevice d) { OnInputDeviceChanged(d,DeviceEventType.configChanged); }
        private void OnInputDeviceChanged(InputDevice device, DeviceEventType evtType){
            Log.I(TAG, $"Input device changed {evtType}: {device.name}");
            if (evtType == DeviceEventType.connected)
                m_inputDevices.Add(device);
            else if (evtType == DeviceEventType.disconnected)
                m_inputDevices.Remove(device);
        }
        public bool GetHMDPose_openxr(out XrView leftView, out XrView rightView) {
            leftView = new XrView{};
            rightView = new XrView{};

            if (!trackingStates.ContainsKey(XRNode.Head)) {
                Log.I(TAG, "GetHMDPose_openxr() no XRNode.Head");
                return false;
            }

            if (m_openXRFeature==null) {
                Log.W(TAG, "GetHMDPose_openxr() m_openXRFeature==null");
                return false;
            }

            if (!m_openXRFeature.GetViewPoses(out leftView , out rightView)) {
                Log.W(TAG, "Error getting view poses.");
                return false;
            }
            return true;
        }

        private Dictionary<XRNode,string> unityXrNodes_to_oxrComponentPathStrings = new Dictionary<XRNode, string> {
            {XRNode.LeftHand, "/user/hand/left/input/grip/pose"},
            {XRNode.RightHand, "/user/hand/right/input/grip/pose"},
        };
        private Dictionary<XRNode,System.UInt64> unityXrNodes_to_oxrPathHandles = new Dictionary<XRNode, System.UInt64>();
        public SpaceLoc GetControllerPose(XRNode nodeType) {
            System.UInt64 oxrPath = 0;
            if (unityXrNodes_to_oxrPathHandles.ContainsKey(nodeType)) {
                oxrPath = unityXrNodes_to_oxrPathHandles[nodeType];
            } else {
                if (unityXrNodes_to_oxrComponentPathStrings.ContainsKey(nodeType)) {
                    oxrPath = m_openXRFeature.GetXrPath(unityXrNodes_to_oxrComponentPathStrings[nodeType]);
                }
                if (oxrPath!=0) {
                    unityXrNodes_to_oxrPathHandles[nodeType] = oxrPath;
                }
            }
            if (oxrPath==0) {
                Log.W(TAG, "GetControllerPose() oxrPath==0 nodeType:" + nodeType);
                return SpaceLoc.Identity;
            } else {
                if (!trackingStates.ContainsKey(nodeType)) {
                    Log.V(TAG, "GetControllerPose() not contains " + nodeType);
                    return SpaceLoc.Identity;
                }
                return m_openXRFeature.GetNodePose(oxrPath);
            }
        }

        public Int64 GetOpenXrTimeNow() {
            if (m_isXrInitialized) {
                if (m_openXRFeature==null) {
                    return 0;
                }
                return m_openXRFeature.GetXrTimeNow();
            }
            else {
                return 0;
            }
        }

        public static  Camera GetXrCamera() {
            // NOTE: This will return a single camera, but more than one camera can be marked as "main"
            return Camera.main;
        }
        
        public VideoFrame getLastFrame() {
            #if UNITY_EDITOR
                return null;
            #else
                VideoFrame tmp = null;
                lock (m_lockObject) {
                    if (m_lastFrame != null) {
                        tmp  = m_lastFrame;
                    }
                    m_lastFrame = null;
                }
                return tmp;
            #endif
        }

        public void StartSession(string serverSesion) {
            Log.I(TAG, "StartSession() serverSesion:" + serverSesion);
            TcrXrSdk.Instance.Start(serverSesion);
        }

        public void OnInited(string clientSession) {
            Log.I(TAG, "OnInited");
            onInitedSdk?.Invoke(clientSession);
        }

        public void OnRequestVrInfo() {
            SendPoses();
        }

        public void OnFrame(VideoFrame videoFrame) {
            lock (m_lockObject) {
                if (m_lastFrame != null) {
                    m_lastFrame.release();
                }
                videoFrame.retain();
                m_lastFrame = videoFrame;
            }
        }

        void OnPostRender() {
        }

        
        // Start is called before the first frame update
        void Start()
        {
        }

        public delegate void OnInitedSdk(string clientSession);
        public event OnInitedSdk onInitedSdk;

        public void StartInitTcrXrSdk() {
            Log.I(TAG, "StartInitTcrXrSdk()");
            m_startInitSdk = true;
        }

        public bool IsSdkInitilazed() {
            return m_isSdkInitialized;
        }

        private void DoInitTcrXrSdk() {
            if (m_isSdkInitialized)  {
                return;
            }

            if (!GetHMDPose_openxr(out XrView leftView, out XrView rightView)) {
                Log.E(TAG, "Get views failed, cannot init tcrxrsdk.");
                return;
            }

            TcrXrSdk.Instance.onInited += OnInited;
            TcrXrSdk.Instance.onRequestVrInfo += OnRequestVrInfo;
            TcrXrSdk.Instance.onFrame += OnFrame;

            XrFovf left = leftView.fov, right = rightView.fov;
            Fov leftFov = new(left.angleLeft, left.angleRight, left.angleUp, left.angleDown);
            Fov rightFov = new(right.angleLeft, right.angleRight, right.angleUp, right.angleDown);
            float ipd = Math.Abs(
                Vector3.Distance(
                    new Vector3(rightView.pose.position.x, rightView.pose.position.y, rightView.pose.position.z),
                    new Vector3(leftView.pose.position.x, leftView.pose.position.y, leftView.pose.position.z)
                )
            );
            TcrXrConfig xrConfig = new("oculus/touch_controller", new EyeInfo(leftFov, rightFov, ipd));
            TcrXrSdk.Instance.Init(xrConfig);
            m_isSdkInitialized = true;
        }

        public void SendPoses() {
            if (GetHMDPose_openxr(out XrView leftView, out XrView rightView))
            {
                TcrXrSdk.Instance.SendXrViews(leftView, rightView);
            }
        }

         // Internal tracking queue
        System.Collections.Concurrent.ConcurrentQueue<TrackingState> trackingStatesQueue = new System.Collections.Concurrent.ConcurrentQueue<TrackingState>();

        internal void UpdateControllers() {
            TrackingState nextState;
            bool dequeueSuccess = false;
            while (!trackingStatesQueue.IsEmpty) {
                
                lock(trackingStatesQueue) {
                    dequeueSuccess = trackingStatesQueue.TryDequeue(out nextState);
                }
                Log.V(TAG, "UpdateControllers trackingStatesQueue dequeueSuccess:" + dequeueSuccess + " nextState.lastTrackingEvent:" + nextState.lastTrackingEvent);
                if(dequeueSuccess) {
                    switch (nextState.lastTrackingEvent) {
                        case TrackingEventType.added:
                            AddController(nextState);
                            break;
                        case TrackingEventType.removed:
                            break;
                        case TrackingEventType.trackingAcquired:
                            break;
                        case TrackingEventType.trackingLost:
                            break;
                        case TrackingEventType.noEvent:
                            Log.W(TAG, "Tracking event with \"no event\"");
                            break;
                    }
                }
                else {
                    Log.W(TAG, $"Could not dequeue; trying again.");
                }
            }
        }    
        

        private readonly List<List<Binding>> m_controllersBindings = new ();
        private void AddController(TrackingState state) {
            // 节点添加时把这个节点所有的绑定找出来
            List<Binding> nodeBindings = new ();
            foreach(Binding b in Bindings.oculusTouchBindings) {
                 if(b.xrnode == state.nodeType) {
                    nodeBindings.Add(b);
                 }
            }
            Log.D(TAG, $"Found {nodeBindings.Count} bindings for {state.nodeType}");
            if (nodeBindings.Count > 0) {
                UpdateMappings(nodeBindings);
                m_controllersBindings.Add(nodeBindings);
            } 
        }

        public void FireControllerEvents() {
            // send controller keyevents
            foreach (List<Binding> bindings in m_controllersBindings)
            {
                InputStateData[] inputStates = new InputStateData[bindings.Count];
                GetLatestInputStates(bindings, inputStates);
                TcrXrSdk.Instance.SendControllerEvents(inputStates);
            }
            // send controller pose
            TcrXrSdk.Instance.SendControllerPose(GetControllerPose(XRNode.LeftHand), GetControllerPose(XRNode.RightHand));
        }        

        private Dictionary<XRNode, Dictionary<string,UsageData>> lookupUsage = new();
        public void UpdateMappings(List<Binding> bindings) {
            for (int i=0; i<bindings.Count; i++ ) {
                Binding binding = bindings[i];
                UsageData usageData = new(){};
                // Doing this the stupid way.
                bool succeeded = false;
                InputDevice inputDevice = InputDevices.GetDeviceAtXRNode(binding.xrnode);
                List<InputFeatureUsage> usages = new();
                if (inputDevice.TryGetFeatureUsages(usages)) {
                    foreach( InputFeatureUsage ifu in usages) {
                        if (ifu.name == binding.usageName) {
                            succeeded = true;
                            usageData.usage = ifu;
                            break;
                        }
                    }
                }
                
                usageData.valid = succeeded;
                usageData.device = inputDevice;
                if (!lookupUsage.ContainsKey(binding.xrnode)) {
                    lookupUsage[binding.xrnode] = new Dictionary<string, UsageData>();
                }
                lookupUsage[binding.xrnode][binding.openxrPath] = usageData;
                Log.D(TAG, $"Looking up {binding.usageName} on {binding.xrnode}: {succeeded}");
            }
        }

        private struct UsageData {
            public bool valid;
            public InputFeatureUsage usage;
            public InputDevice device;
        }
        
        public void GetLatestInputStates(List<Binding> bindings, InputStateData[] states) {
            for (int i=0; i<bindings.Count; i++ ) {
                Binding binding = bindings[i];
                if (!lookupUsage.ContainsKey(binding.xrnode)) {
                    Log.E(TAG, "lookupUsage not contains:" + binding.xrnode);
                    continue;
                }
                if (!lookupUsage[binding.xrnode].ContainsKey(binding.openxrPath)) {
                    Log.E(TAG, "lookupUsage not contains path:" + binding.openxrPath + " for xrnode:" + binding.xrnode);
                    continue;
                }

                UsageData usageData = lookupUsage[binding.xrnode][binding.openxrPath];
                InputStateData s = states[i];
                s.openxrPath = binding.openxrPath;
                s.xrnode = binding.xrnode;
                s.usageType = binding.usageType;

                if (!usageData.valid) {
                    s.valid = usageData.valid;
                } else {
                    switch(binding.usageType) {
                        case "bool":
                            s.valid = usageData.device.TryGetFeatureValue(usageData.usage.As<bool>(), out s.boolVal);
                            break;
                        case "float":
                            s.valid = usageData.device.TryGetFeatureValue(usageData.usage.As<float>(), out s.floatVal);
                            break;
                        case "Vector2":
                            Vector2 vec;
                            // Yeah, yeah, this is called twice, once for each "subaxis". Need to clean that up.
                            s.valid = usageData.device.TryGetFeatureValue(usageData.usage.As<Vector2>(), out vec);
                            switch(binding.subaxis) {
                                case "x":
                                    s.floatVal = vec[0];
                                    break;
                                case "y":
                                    s.floatVal = vec[1];
                                    break;
                                default:
                                    Log.E(TAG, $"Invalid subaxis: {binding.subaxis}");
                                    break;
                            }
                            s.vector2Val = vec;
                            break;
                    }
                }
                states[i] = s;
            }

        }
    }
} // namespace TCR
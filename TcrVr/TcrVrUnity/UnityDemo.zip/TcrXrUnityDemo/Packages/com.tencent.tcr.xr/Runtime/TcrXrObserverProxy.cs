using UnityEngine;
using TCR;

// TcrXrObserver接口的C#代理实现
public class TcrXrObserverProxy : AndroidJavaProxy
{
    private static readonly string TAG = "TcrXrObserverProxy";
    public TcrXrObserverProxy() : base("com.tencent.tcr.xr.api.TcrXrObserver") {}

    public delegate void OnInited(string serverSession);
    public event OnInited onInited;

    public delegate void OnRequestVrInfo();
    public event OnRequestVrInfo onRequestVrInfo;


    public delegate void OnFrame(VideoFrame videoFrame);
    public event OnFrame onFrame;

    public void onEvent(UnityEngine.AndroidJavaObject javaEvent, UnityEngine.AndroidJavaObject eventData)
    {
        string eventName = javaEvent.Call<string>("name");
        switch(eventName) {
            case "REQUEST_VR_INFO":
                onRequestVrInfo?.Invoke();
            break;

            case "ON_FRAME":
                onFrame?.Invoke(new VideoFrame(eventData));
            break;

            default:
                Log.W(TAG, $"onEvent event:{eventName} and eventData:{eventData}");
            break;
        }
        javaEvent.Dispose();
    }

    // Java接口TcrXrObserver回调的onEvent()函数第二个参数是Java的Object，当它是Java的String时c#会自动转换成c#的System.String
    public void onEvent(UnityEngine.AndroidJavaObject javaEvent, System.String eventData) {
        string eventName = javaEvent.Call<string>("name");
        if(eventName.Equals("STATE_INITED")) {
            onInited?.Invoke(eventData);
        } else {
            // 不应该执行到这里
            Log.E(TAG, $"onEvent not handled event:{eventName} and eventData:{eventData}");
        }
        
    }
}
using System;

namespace TCR {
    public class TcrXrConfig
    {
        private EyeInfo eyeInfo;
        private string controller = "oculus/touch_controller";
        private float srRatio;
        private bool enableFFR;
        // 开启超视角渲染后，会有以下影响:
        // 1.发送到云端的FOV会在用户的原始FOV基础上增加FOV_6_DEGREES角度。
        // 2.视频帧VideoFrame返回的左右眼FOV会相应增加。
        private bool enableWideFov;
        private int hmdRecommendedWidth;
        private int hmdRecommendedHeight;
        private int targetResolutionWidth;

        public TcrXrConfig(string controller, EyeInfo eyeInfo) {
            this.eyeInfo = eyeInfo;

            if (controller != "pico/neo3_controller" && controller != "oculus/touch_controller")
            {
                Log.E("TcrXrConfig", $"controller:{controller} not valid!");
            } else {
                this.controller = controller;
            }
        }

        /**
        * 设置HMD推荐的分辨率宽高。
        * 该宽高通常是通过HMD设备查询到的一个宽高，云端实际上会根据这个宽高的比例计算最终画面的实际分辨率。
        */
        public void HmdRecommendedResolution(int width, int height)
        {
            if (width < 1 || height < 1)
            {
                Log.E("TcrXrConfig", $"width:{width} or height:{height} not valid!");
                return;
            }

            this.hmdRecommendedWidth = width;
            this.hmdRecommendedHeight = height;
        }


        /**
        * 设置最终视频画面的目标分辨率宽度(双眼)。
        * 由于云端编码要求分辨率必须64对齐，所以传入的值必须对齐64，否则传入后会自动对齐。
        */
        public void TargetResolution(int width)
        {
            this.targetResolutionWidth = width / 64 * 64;
        }

        /**
        * 开启或关闭固定注视点渲染(FFR)功能.
        * 请注意: 云端实例启动后该配置不可修改(现阶段云端不支持)，若重连时修改该配置会导致用户看到异常的画面。
        */
        public void EnableFFR(bool enable)
        {
            this.enableFFR = enable;
        }

        /**
        * 超分辨率的比例，实际分辨率是 srcResolution * ratio * ratio
        */
        public void SrRatio(float ratio)
        {
            this.srRatio = ratio;
        }

        /**
        * 开启或关闭超视角渲染功能。
        * 开启该选项后，SDK发送给云端的FOV会在原有基础上增加6°，云端传回的画面分辨率也会相应增加。
        */
        public void EnableWideFov(bool enable)
        {
            this.enableWideFov = enable;
        }

        public EyeInfo GetEyeInfo() {
            return eyeInfo;
        }
        public string GetController() {
            return controller;
        }
        public float GetSrRatio() {
            return srRatio;
        }

        public bool getEnableFFR() {
            return enableFFR;
        }

        public bool getEnableWideFov() {
            return enableWideFov;
        }

        public int GetHmdRecommendedWidth() {
            return hmdRecommendedWidth;
        }
        public int GetHmdRecommendedHeight() {
            return hmdRecommendedHeight;
        }

        public int GetTargetResolutionWidth() {
            return targetResolutionWidth;
        }
    }
    

}
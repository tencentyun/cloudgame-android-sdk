using System;
using System.Reflection;
using OXR;
using UnityEngine;
using UnityEngine.XR;

namespace TCR {
    public class TcrXrSdk {
        private static readonly string TAG = "TcrXrSdk";

        private static readonly TcrXrSdk instance;
        static TcrXrSdk() {
            instance = new TcrXrSdk();
        }

        private TcrXrSdk() {

        }

        public static TcrXrSdk Instance {
            get {
                return instance;
            }
        }

    public delegate void OnInited(string clientSession);
    public event OnInited onInited;

    public delegate void OnRequestVrInfo();
    public event OnRequestVrInfo onRequestVrInfo;


    public delegate void OnFrame(VideoFrame videoFrame);
    public event OnFrame onFrame;


    public class TcrXrObserverProxy : AndroidJavaProxy
    {
        public TcrXrObserverProxy() : base("com.tencent.tcr.xr.api.TcrXrObserver") {}


        public void onEvent(UnityEngine.AndroidJavaObject javaEvent, UnityEngine.AndroidJavaObject eventData)
        {
            string eventName = javaEvent.Call<string>("name");
            switch(eventName) {
                case "REQUEST_VR_INFO":
                    Instance.onRequestVrInfo?.Invoke();
                break;

                case "ON_FRAME":
                    Instance.onFrame?.Invoke(new VideoFrame(eventData));
                break;

                default:
                    Log.W(TAG, $"event not handled, event:{eventName} eventData:{eventData}");
                break;
            }
            javaEvent.Dispose();
        }

        // Java接口TcrXrObserver回调的onEvent()函数第二个参数是Java的Object，当它是Java的String时c#会自动转换成c#的System.String
        public void onEvent(UnityEngine.AndroidJavaObject javaEvent, System.String eventData) {
            string eventName = javaEvent.Call<string>("name");
            if(eventName.Equals("STATE_INITED")) {
                TcrXrSdk.Instance.onInited?.Invoke(eventData);
            } else {
                // 不应该执行到这里
                Log.W(TAG, $"event not handled, event:{eventName} eventData:{eventData}");
            }
            
        }
    }

        public void Release() {
            if (!m_inited) {
                Log.W(TAG, "Release() inited=false");
                return;
            }
            Log.I(TAG, "Release()");
            if (m_tcrXrSdkInstance != null)  {
                m_tcrXrSdkInstance.Call("stop");
            }
            ReleaseResources();
            m_inited = false;
        }

        private bool m_inited = false;

        private AndroidJavaObject m_tcrXrSdkInstance;
        private AndroidJavaClass m_tcrHelper; 
        
        public void Init(TcrXrConfig config)
        {
            if (m_inited)
            {
                Log.W(TAG, "Init() inited=true");
                return;
            }
            Log.I(TAG, "Init() config=" + config);
            m_inited = true;

            try
            {
                using (AndroidJavaObject eyeInfo = new("com.tencent.tcr.xr.api.bean.EyeInfo"))
                using (AndroidJavaObject leftFov = new("com.tencent.tcr.xr.api.bean.math.Fov", config.GetEyeInfo().leftFov.left, config.GetEyeInfo().leftFov.right, config.GetEyeInfo().leftFov.top, config.GetEyeInfo().leftFov.bottom))
                using (AndroidJavaObject rightFov = new("com.tencent.tcr.xr.api.bean.math.Fov", config.GetEyeInfo().rightFov.left, config.GetEyeInfo().rightFov.right, config.GetEyeInfo().rightFov.top, config.GetEyeInfo().rightFov.bottom))
                {
                    eyeInfo.Set<AndroidJavaObject>("leftFov", leftFov);
                    eyeInfo.Set<AndroidJavaObject>("rightFov", rightFov);
                    eyeInfo.Set<float>("ipd", config.GetEyeInfo().ipd);

                    AndroidJavaObject tcrXrConfigBuilder = BuildTcrXrConfigBuilder(eyeInfo);
                    AndroidJavaObject tcrXrConfig = tcrXrConfigBuilder.Call<AndroidJavaObject>("build");
                    m_tcrXrSdkInstance = new AndroidJavaObject("com.tencent.tcr.xr.api.TcrXrSdk").CallStatic<AndroidJavaObject>("getInstance");
                    AndroidJavaObject currentActivity = new AndroidJavaObject("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity");

                    m_tcrXrSdkInstance.Call("initBasic", currentActivity);
                    m_tcrXrSdkInstance.Call("setCurrentEGLContext");
                    m_tcrXrSdkInstance.Call("init", tcrXrConfig);

                    m_tcrHelper = new AndroidJavaClass("com.tencent.tcr.xr.TcrXrHelper");
                }
            }
            catch (Exception e)
            {
                Log.E(TAG, "Error initializing TcrXrConfig: " + e.Message);
            }
        }

        private AndroidJavaObject BuildTcrXrConfigBuilder(AndroidJavaObject eyeInfo)
        {
            AndroidJavaObject tcrXrConfigClass = new AndroidJavaObject("com.tencent.tcr.xr.api.TcrXrConfig");
            AndroidJavaObject tcrXrConfigBuilder = tcrXrConfigClass.CallStatic<AndroidJavaObject>("builder", new TcrXrObserverProxy(), "oculus/touch_controller", eyeInfo);

            tcrXrConfigBuilder.Call<AndroidJavaObject>("enableFFR", false);
            tcrXrConfigBuilder.Call<AndroidJavaObject>("targetResolution", 4000);
            tcrXrConfigBuilder.Call<AndroidJavaObject>("hmdRecommendedResolution", 1440, 1584);

            return tcrXrConfigBuilder;
        }

        private void ReleaseResources()
        {
            if (m_tcrXrSdkInstance != null)
            {
                m_tcrXrSdkInstance.Dispose();
                m_tcrXrSdkInstance = null;
            }

            if (m_tcrHelper != null)
            {
                m_tcrHelper.Dispose();
                m_tcrHelper = null;
            }
        }

        public void Start(string serverSession) {
            Log.D(TAG, "Start() serverSession:" + serverSession);
            using(AndroidJavaObject serverSessionObj =  new("java.lang.String", serverSession)) {
                m_tcrXrSdkInstance.Call<bool>("start", serverSessionObj);
            }
        }

        public void SendXrViews(XrView left, XrView right) {
            if (m_tcrXrSdkInstance == null) {
                Log.W(TAG, "sendVrInfo() tcrXrSdkInstance=null");
                return;
            }

            XrPosef pose = Merge(left.pose, right.pose);
            using (AndroidJavaObject position = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)pose.position.x, (double)pose.position.y, (double)pose.position.z),
                orientation = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Quaternion4f", (double)pose.orientation.x, (double)pose.orientation.y, (double)pose.orientation.z, (double)pose.orientation.w),
                jpose = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Pose", position, orientation),
                vrInfo = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.VrInfo", jpose, 0.0629f, null)) {
                    m_tcrXrSdkInstance.Call("sendVrInfo", vrInfo);
            }
        }

        private XrPosef Merge(XrPosef left, XrPosef right) {
            XrVector3f lp = left.position;
            XrVector3f rp = right.position;
            XrVector3f position = new() {
                    x = (float)((lp.x + rp.x)/2.0),
                    y = (float)((lp.y + rp.y)/2.0),
                    z = (float)((lp.z + rp.z)/2.0)};
            XrPosef result = new()
            {
                position = position,
                orientation = left.orientation
            };
            return result;
        }

        public void SendControllerEvents(InputStateData[] inputStates) {
            using (AndroidJavaObject arrayList = new ("java.util.ArrayList"))
            {
                for(int idx=0; idx<inputStates.Length; idx++ ) {
                    InputStateData data = inputStates[idx];
                    AndroidJavaObject baseInput;
                    switch(data.usageType) {
                        case "bool":
                            baseInput = new ("com.tencent.tcr.xr.api.bean.BoolInput");
                            baseInput.Set("bool_value", data.boolVal);
                            baseInput.Set("part", data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right");
                            
                            break;
                        case "float":
                            baseInput = new ("com.tencent.tcr.xr.api.bean.FloatInput");
                            baseInput.Set("float_value", data.floatVal);
                            baseInput.Set("part", data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right");
                            break;
                        case "Vector2":
                            baseInput = new ("com.tencent.tcr.xr.api.bean.Vector2Input");
                            AndroidJavaObject vector2f = new ("com.tencent.tcr.xr.api.bean.math.Vector2f", (double)data.vector2Val.x, (double)data.vector2Val.y);
                            baseInput.Set("vector2f", vector2f);
                            baseInput.Set("part", data.xrnode == XRNode.LeftHand ? "/hand/left" : "/hand/right");
                            vector2f.Dispose();
                            break;
                        default:
                            Log.E(TAG, $"SendControllerEvents() not support usageType:{data.usageType}");
                            continue;
                    }
                    baseInput.Set("path", data.openxrPath);
                    arrayList.Call<bool>("add", baseInput);
                    baseInput.Dispose();
                }
                m_tcrXrSdkInstance.Call("sendControllerEvent", arrayList);
            }

        }

        public void SendControllerPose(SpaceLoc leftSpaceLoc, SpaceLoc rightSpaceLoc)
        {
            using (AndroidJavaObject arrayList = new AndroidJavaObject("java.util.ArrayList"))
            {
                using (AndroidJavaObject poseInputLeft = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.PoseInput"))
                using (AndroidJavaObject posLeft = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)leftSpaceLoc.pose.position.x, (double)leftSpaceLoc.pose.position.y, (double)leftSpaceLoc.pose.position.z))
                using (AndroidJavaObject oriLeft = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Quaternion4f", (double)leftSpaceLoc.pose.orientation.x, (double)leftSpaceLoc.pose.orientation.y, (double)leftSpaceLoc.pose.orientation.z, (double)leftSpaceLoc.pose.orientation.w))
                using (AndroidJavaObject poseLeft = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.PoseExt", posLeft, oriLeft))
                using (AndroidJavaObject linear_velocity = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)leftSpaceLoc.linearVelocity.x, (double)leftSpaceLoc.linearVelocity.y, (double)leftSpaceLoc.linearVelocity.z))
                using (AndroidJavaObject angular_velocity = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)leftSpaceLoc.angularVelocity.x, (double)leftSpaceLoc.angularVelocity.y, (double)leftSpaceLoc.angularVelocity.z))
                {
                    poseLeft.Set("linear_velocity", linear_velocity);
                    poseLeft.Set("angular_velocity", angular_velocity);
                    poseInputLeft.Set("pose", poseLeft);
                    poseInputLeft.Set("part", "/hand/left");
                    poseInputLeft.Set("path", "/grip/pose");
                    arrayList.Call<bool>("add", poseInputLeft);
                }

                using (AndroidJavaObject poseInputRight = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.PoseInput"))
                using (AndroidJavaObject posRight = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)rightSpaceLoc.pose.position.x, (double)rightSpaceLoc.pose.position.y, (double)rightSpaceLoc.pose.position.z))
                using (AndroidJavaObject oriRight = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Quaternion4f", (double)rightSpaceLoc.pose.orientation.x, (double)rightSpaceLoc.pose.orientation.y, (double)rightSpaceLoc.pose.orientation.z, (double)rightSpaceLoc.pose.orientation.w))
                using (AndroidJavaObject poseRight = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.PoseExt", posRight, oriRight))
                using (AndroidJavaObject linear_velocity = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)rightSpaceLoc.linearVelocity.x, (double)rightSpaceLoc.linearVelocity.y, (double)rightSpaceLoc.linearVelocity.z))
                using (AndroidJavaObject angular_velocity = new AndroidJavaObject("com.tencent.tcr.xr.api.bean.math.Vector3f", (double)rightSpaceLoc.angularVelocity.x, (double)rightSpaceLoc.angularVelocity.y, (double)rightSpaceLoc.angularVelocity.z))
                {
                    poseRight.Set("linear_velocity", linear_velocity);
                    poseRight.Set("angular_velocity", angular_velocity);
                    poseInputRight.Set("pose", poseRight);
                    poseInputRight.Set("part", "/hand/right");
                    poseInputRight.Set("path", "/grip/pose");
                    arrayList.Call<bool>("add", poseInputRight);
                }
                m_tcrXrSdkInstance.Call("sendControllerEvent", arrayList);
            }
        }
    }
}

using UnityEngine.XR;

namespace TCR {

    public struct Binding {
        public string usageName; // the Unity XR usage name
        public string usageType; // used to select the right "template" for GetUsage
        public string subaxis;  // x or y for Vector2 types
        public XRNode xrnode; // XRNode.LeftHand or .RightHand, possibly others but unsupported right now
        public string openxrPath; // the openxr path maping to the openxr path
    }

    public static class Bindings {
        public static Binding[] oculusTouchBindings = new Binding[] {
            new() {
                usageName = "Grip",
                usageType = "float",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/squeeze/value"
            },
            new() {
                usageName = "Grip",
                usageType = "float",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/squeeze/value"
            },
            new() {
                usageName = "GripButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/squeeze/click"
            },
            new() {
                usageName = "GripButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/squeeze/click"
            },
            new() {
                usageName = "MenuButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/system/click"
            },
            new() {
                usageName = "Primary2DAxis",
                usageType = "Vector2",
                subaxis = "x",
                xrnode = XRNode.LeftHand,
                openxrPath = "/thumbstick"
            },
            new() {
                usageName = "Primary2DAxis",
                usageType = "Vector2",
                subaxis = "x",
                xrnode = XRNode.RightHand,
                openxrPath = "/thumbstick"
            },
            new() {
                usageName = "Primary2DAxis",
                usageType = "Vector2",
                subaxis = "y",
                xrnode = XRNode.LeftHand,
                openxrPath = "/thumbstick"
            },
            new() {
                usageName = "Primary2DAxis",
                usageType = "Vector2",
                subaxis = "y",
                xrnode = XRNode.RightHand,
                openxrPath = "/thumbstick"
            },
            new() {
                usageName = "Primary2DAxisClick",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/thumbstick/click"
                
            },
            new() {
                usageName = "Primary2DAxisClick",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/thumbstick/click"
            },
            new() {
                usageName = "Primary2DAxisTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/thumbstick/touch"
            },
            new() {
                usageName = "Primary2DAxisTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/thumbstick/touch"
            },
            new() {
                usageName = "PrimaryButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/x/click"
            },
            new Binding {
                usageName = "PrimaryButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/a/click"
            },
            new Binding {
                usageName = "PrimaryTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/x/touch"
            },
            new() {
                usageName = "PrimaryTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/a/touch"
            },
            new() {
                usageName = "SecondaryButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/y/click"
            },
            new() {
                usageName = "SecondaryButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/b/click"
            },
            new() {
                usageName = "SecondaryTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/y/touch"
            },
            new() {
                usageName = "SecondaryTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/b/touch"
            },
            new() {
                usageName = "Trigger",
                usageType = "float",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/trigger/value"
            },
            new() {
                usageName = "Trigger",
                usageType = "float",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/trigger/value"
            },
            new() {
                usageName = "TriggerTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/trigger/touch"
            },
            new() {
                usageName = "TriggerTouch",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/trigger/touch"
            },
            new() {
                usageName = "TriggerButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.LeftHand,
                openxrPath = "/trigger/click"
            },
            new() {
                usageName = "TriggerButton",
                usageType = "bool",
                subaxis = "",
                xrnode = XRNode.RightHand,
                openxrPath = "/trigger/click"
            }
        };
    }

}

#pragma once
#ifndef TCR_INTERACTION_MANAGER_H
#  define TCR_INTERACTION_MANAGER_H
#  include <json/value.h>
#  include <algorithm>
#  include <array>
#  include <atomic>
#  include <cassert>
#  include <chrono>
#  include <cstdint>
#  include <cstring>
#  include <functional>
#  include <string>
#  include <string_view>
#  include <unordered_map>
#  include <utility>
#  include "check.h"
#  include "common.h"
#  include "interaction_profiles.h"
#  include "pch.h"
#  include "xr_utils.h"

namespace Side {
constexpr const std::size_t LEFT = 0;
constexpr const std::size_t RIGHT = 1;
constexpr const std::size_t COUNT = 2;
}  // namespace Side

namespace ActionType {
constexpr const std::size_t INPUT = 0;
constexpr const std::size_t OUTPUT = 1;
}  // namespace ActionType

namespace Tcr {

struct HapticsFeedback {
  std::string part;
  std::string path;
  unsigned int duration;
  float frequency;
  float amplitude;
};

struct InteractionManager {
  using PathMap = std::tuple<XrPath, std::string>;
  using HandPathList = std::array<PathMap, Side::COUNT>;
  using HandSpaceList = std::array<XrSpace, Side::COUNT>;
  using HandActiveList = std::array<XrBool32, Side::COUNT>;
  using HandTrackerList = std::array<XrHandTrackerEXT, Side::COUNT>;

  template <typename IsProfileSupportedFn>
  InteractionManager(XrInstance instance, XrSession session, IsProfileSupportedFn&& isProfileSupported);
  InteractionManager(const InteractionManager&) = delete;
  InteractionManager& operator=(const InteractionManager&) = delete;

  ~InteractionManager();
  void Clear();

  XrPath GetXrPath(const char* const str) const;
  XrPath GetXrPath(const InteractionProfile& profile) const;
  XrPath GetXrInputPath(const InteractionProfile& profile, const std::size_t hand, const char* const str) const;
  XrPath GetXrOutputPath(const InteractionProfile& profile, const std::size_t hand, const char* const str) const;
  XrPath GetCurrentProfilePath() const;
  std::string GetCurrentProfilePathString() const;

  void LogActions() const;

  void SyncActions();
  Json::Value PollActions(const XrSpace& baseSpace, const XrTime& time);

  void SetActiveProfile(const XrPath profilePath);
  const InteractionProfile* GetInteractionProfile(const XrPath newProfilePath);
  void SetActiveFromCurrentProfile();

 private:
  template <typename IsProfileSupportedFn>
  void InitializeActions(IsProfileSupportedFn&& isProfileSupported);
  template <typename IsProfileSupportedFn>
  void InitSuggestedBindings(IsProfileSupportedFn&& isProfileSupported) const;

  using SuggestedBindingList = std::vector<XrActionSuggestedBinding>;
  SuggestedBindingList MakeSuggestedBindings(const InteractionProfile& profile) const;

  void LogActionSourceName(XrAction action, const char* const actionName) const;

  XrInstance m_instance{XR_NULL_HANDLE};
  XrSession m_session{XR_NULL_HANDLE};

  using InteractionProfilePtr = std::atomic<const InteractionProfile*>;
  InteractionProfilePtr m_activeProfile{nullptr};

  HandPathList m_handSubactionPath{std::make_tuple(XR_NULL_PATH, ""), std::make_tuple(XR_NULL_PATH, "")};
  HandSpaceList m_handAimSpace{XR_NULL_HANDLE, XR_NULL_HANDLE};
  HandSpaceList m_handGripSpace{XR_NULL_HANDLE, XR_NULL_HANDLE};

  struct Action {
    const char* const name;
    const char* const localizedName;
    XrAction xrAction{XR_NULL_HANDLE};
  };
  using ActionMap = std::unordered_map<Path, Action>;

  ActionMap m_boolActionMap = {{SystemClick, {"system_click", "System Click"}},
                               {SqueezeClick, {"grip_click", "Grip Click"}},
                               {AClick, {"a_click", "A Click"}},
                               {ATouch, {"a_touch", "A Touch"}},
                               {BClick, {"b_click", "B Click"}},
                               {BTouch, {"b_touch", "B Touch"}},
                               {XClick, {"x_click", "X Click"}},
                               {XTouch, {"x_touch", "X Touch"}},
                               {YClick, {"y_click", "Y Click"}},
                               {YTouch, {"y_touch", "Y Touch"}},
                               {ThumbstickClick, {"joystick_click", "Joystick Click"}},
                               {ThumbstickTouch, {"joystick_touch", "Joystick Touch"}},
                               {BackClick, {"back_click", "Back Click"}},
                               {TriggerClick, {"trigger_click", "Trigger Click"}},
                               {TriggerTouch, {"trigger_touch", "Trigger Touch"}},
                               {ThumbrestTouch, {"thumbrest_touch", "Thumbrest Touch"}}};
  ActionMap m_scalarActionMap = {{SqueezeValue, {"grip_value", "Grip Value"}},
                                 {ThumbstickX, {"joystick_x", "Joystick X"}},
                                 {ThumbstickY, {"joystick_y", "Joystick Y"}},
                                 {TriggerValue, {"trigger_value", "Trigger Value"}}};
  ActionMap m_vector2fActionMap = {{ThumbstickPos, {"joystick_pos", "Joystick Pos"}}};
  XrAction m_aimPoseAction{XR_NULL_HANDLE};
  XrAction m_gripPoseAction{XR_NULL_HANDLE};
  XrActionSet m_actionSet{XR_NULL_HANDLE};
};
////////////////////////////////////////////////////////////////////////////////////////////////////

template <typename IsProfileSupportedFn>
inline InteractionManager::InteractionManager(XrInstance instance, XrSession session,
                                              IsProfileSupportedFn&& isProfileSupported)
    : m_instance{instance}, m_session{session} {
  CHECK(m_instance != XR_NULL_HANDLE);
  CHECK(m_session != XR_NULL_HANDLE);
  InitializeActions(std::forward<IsProfileSupportedFn>(isProfileSupported));
}

inline InteractionManager::~InteractionManager() {
  LogV("Destroying InteractionManager");
  Clear();
}

inline void InteractionManager::Clear() {
  m_activeProfile.store(nullptr);
  LogV("Destroying Hand Action Spaces");
  for (auto hand : {Side::LEFT, Side::RIGHT}) {
    if (m_handAimSpace[hand] != XR_NULL_HANDLE) {
      xrDestroySpace(m_handAimSpace[hand]);
    }
    m_handAimSpace[hand] = XR_NULL_HANDLE;
  }

  for (auto hand : {Side::LEFT, Side::RIGHT}) {
    if (m_handGripSpace[hand] != XR_NULL_HANDLE) {
      xrDestroySpace(m_handGripSpace[hand]);
    }
    m_handGripSpace[hand] = XR_NULL_HANDLE;
  }

  if (m_actionSet != XR_NULL_HANDLE) {
    LogV("Destroying ActionSet");
    xrDestroyActionSet(m_actionSet);
    m_actionSet = XR_NULL_HANDLE;
  }

  m_vector2fActionMap.clear();
  m_scalarActionMap.clear();
  m_boolActionMap.clear();
  m_aimPoseAction = XR_NULL_HANDLE;
  m_gripPoseAction = XR_NULL_HANDLE;

  m_session = XR_NULL_HANDLE;
  m_instance = XR_NULL_HANDLE;
}

inline XrPath InteractionManager::GetXrPath(const char* const str) const {
  XrPath path{XR_NULL_PATH};
  CHECK_XRCMD(xrStringToPath(m_instance, str, &path));
  assert(path != XR_NULL_PATH);
  return path;
}

inline XrPath InteractionManager::GetXrPath(const InteractionProfile& profile) const { return GetXrPath(profile.path); }

inline XrPath InteractionManager::GetXrInputPath(const InteractionProfile& profile, const std::size_t hand,
                                                 const char* const str) const {
  using namespace std::string_literals;
  const auto fullPath = profile.userHandPaths[hand] + "/input"s + str;
  return GetXrPath(fullPath.c_str());
}

inline XrPath InteractionManager::GetXrOutputPath(const InteractionProfile& profile, const std::size_t hand,
                                                  const char* const str) const {
  using namespace std::string_literals;
  const auto fullPath = profile.userHandPaths[hand] + "/output"s + str;
  return GetXrPath(fullPath.c_str());
}

inline std::string InteractionManager::GetCurrentProfilePathString() const {
  const auto activeProfilePtr = m_activeProfile.load();
  return activeProfilePtr == nullptr ? "" : activeProfilePtr->path;
}

inline XrPath InteractionManager::GetCurrentProfilePath() const {
  if (m_session == XR_NULL_HANDLE) return XR_NULL_PATH;
  for (const auto hand : {Side::LEFT, Side::RIGHT}) {
    auto [handPath, part] = m_handSubactionPath[hand];
    XrInteractionProfileState ps{
        .type = XR_TYPE_INTERACTION_PROFILE_STATE, .next = nullptr, .interactionProfile = XR_NULL_PATH};
    if (XR_SUCCEEDED(xrGetCurrentInteractionProfile(m_session, handPath, &ps)) &&
        ps.interactionProfile != XR_NULL_PATH) {
      return ps.interactionProfile;
    }
  }
  return XR_NULL_PATH;
}

inline InteractionManager::SuggestedBindingList InteractionManager::MakeSuggestedBindings(
    const InteractionProfile& profile) const {
  SuggestedBindingList bindings{
      XrActionSuggestedBinding{m_aimPoseAction, GetXrInputPath(profile, Side::LEFT, profile.aimPosePath)},
      {m_aimPoseAction, GetXrInputPath(profile, Side::RIGHT, profile.aimPosePath)},
      {m_gripPoseAction, GetXrInputPath(profile, Side::LEFT, profile.gripPosePath)},
      {m_gripPoseAction, GetXrInputPath(profile, Side::RIGHT, profile.gripPosePath)},

  };

  const auto helper = [&](const std::size_t hand, const ComponentPaths& inputMap, const auto& actionMap,
                          const size_t type) {
    for (const auto& path : inputMap) {
      const auto action_itr = actionMap.find(path);
      if (action_itr == actionMap.end()) {
        LogW("No action for  path: %s", path.c_str());
        continue;
      }
      XrPath binding;
      if (type == ActionType::INPUT) {
        binding = GetXrInputPath(profile, hand, path.c_str());
      } else {
        binding = GetXrOutputPath(profile, hand, path.c_str());
      }
      const auto& action = action_itr->second;
      bindings.push_back(XrActionSuggestedBinding{.action = action.xrAction, .binding = binding});
    }
  };
  for (const auto hand : {Side::LEFT, Side::RIGHT}) {
    helper(hand, profile.boolPaths[hand], m_boolActionMap, ActionType::INPUT);
    helper(hand, profile.scalarPaths[hand], m_scalarActionMap, ActionType::INPUT);
    helper(hand, profile.vector2fPaths[hand], m_vector2fActionMap, ActionType::INPUT);
  }
  return bindings;
}

template <typename IsProfileSupportedFn>
inline void InteractionManager::InitSuggestedBindings(IsProfileSupportedFn&& IsProfileSupported) const {
  CHECK(m_instance != XR_NULL_HANDLE);
  for (const auto& profile : Tcr::InteractionProfileMap) {
    if (!IsProfileSupported(profile)) {
      LogV(
          "Interaction profile \"%s\" is not enabled or supported, no suggested bindings will be made for this "
          "profile.",
          profile.path);
      continue;
    }
    LogI("Creating suggested bindings for profile: \"%s\"", profile.path);
    const auto bindings = MakeSuggestedBindings(profile);
    const XrInteractionProfileSuggestedBinding suggestedBindings{.type = XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING,
                                                                 .next = nullptr,
                                                                 .interactionProfile = GetXrPath(profile),
                                                                 .countSuggestedBindings = (uint32_t)bindings.size(),
                                                                 .suggestedBindings = bindings.data()};
    CHECK_XRCMD(xrSuggestInteractionProfileBindings(m_instance, &suggestedBindings));
  }
}

template <typename IsProfileSupportedFn>
inline void InteractionManager::InitializeActions(IsProfileSupportedFn&& isProfileSupported) {
  CHECK(m_session != XR_NULL_HANDLE);
  CHECK(m_instance != XR_NULL_HANDLE);

  m_handSubactionPath = {std::make_tuple(GetXrPath("/user/hand/left"), "/hand/left"),
                         std::make_tuple(GetXrPath("/user/hand/right"), "/hand/right")};
  CHECK(std::none_of(m_handSubactionPath.begin(), m_handSubactionPath.end(),
                     [](const PathMap p) { return std::get<0>(p) == XR_NULL_PATH; }));

  XrActionSetCreateInfo actionSetInfo{.type = XR_TYPE_ACTION_SET_CREATE_INFO, .next = nullptr, .priority = 0};
  std::strcpy(actionSetInfo.actionSetName, "tcr");
  std::strcpy(actionSetInfo.localizedActionSetName, "Tcr");
  CHECK_XRCMD(xrCreateActionSet(m_instance, &actionSetInfo, &m_actionSet));
  CHECK(m_actionSet != XR_NULL_HANDLE);
  {
    std::array<XrPath, Side::COUNT> handSubActionPath = {std::get<0>(m_handSubactionPath[Side::LEFT]),
                                                         std::get<0>(m_handSubactionPath[Side::RIGHT])};
    XrActionCreateInfo actionInfo{.type = XR_TYPE_ACTION_CREATE_INFO,
                                  .next = nullptr,
                                  .actionType = XR_ACTION_TYPE_POSE_INPUT,
                                  .countSubactionPaths = uint32_t(handSubActionPath.size()),
                                  .subactionPaths = handSubActionPath.data()};
    std::strcpy(actionInfo.actionName, "hand_aim_pose");
    std::strcpy(actionInfo.localizedActionName, "Hand Aim Pose");
    CHECK_XRCMD(xrCreateAction(m_actionSet, &actionInfo, &m_aimPoseAction));
    CHECK(m_aimPoseAction != XR_NULL_HANDLE);

    std::strcpy(actionInfo.actionName, "hand_grip_pose");
    std::strcpy(actionInfo.localizedActionName, "Hand Grip Pose");
    CHECK_XRCMD(xrCreateAction(m_actionSet, &actionInfo, &m_gripPoseAction));
    CHECK(m_gripPoseAction != XR_NULL_HANDLE);
  }

  const auto CreateActions = [&](const XrActionType actType, auto& actionMap) {
    std::array<XrPath, Side::COUNT> handSubActionPath = {std::get<0>(m_handSubactionPath[Side::LEFT]),
                                                         std::get<0>(m_handSubactionPath[Side::RIGHT])};
    XrActionCreateInfo actionInfo{.type = XR_TYPE_ACTION_CREATE_INFO,
                                  .next = nullptr,
                                  .actionType = actType,
                                  .countSubactionPaths = uint32_t(handSubActionPath.size()),
                                  .subactionPaths = handSubActionPath.data()};
    for (auto& [k, action] : actionMap) {
      std::strcpy(actionInfo.actionName, action.name);
      std::strcpy(actionInfo.localizedActionName, action.localizedName);
      CHECK_XRCMD(xrCreateAction(m_actionSet, &actionInfo, &action.xrAction));
      CHECK(action.xrAction != XR_NULL_HANDLE);
    }
  };
  CreateActions(XR_ACTION_TYPE_BOOLEAN_INPUT, m_boolActionMap);
  CreateActions(XR_ACTION_TYPE_FLOAT_INPUT, m_scalarActionMap);
  CreateActions(XR_ACTION_TYPE_VECTOR2F_INPUT, m_vector2fActionMap);

  auto funCreateSpace = [&](XrAction& action, HandSpaceList& spaceList) -> void {
    XrActionSpaceCreateInfo actionSpaceInfo{
        .type = XR_TYPE_ACTION_SPACE_CREATE_INFO,
        .next = nullptr,
        .action = action,
        .poseInActionSpace =
            {
                .orientation = {.x = 0.0f, .y = 0.0f, .z = 0.0f, .w = 1.f},
                .position = {.x = 0.0f, .y = 0.0f, .z = 0.0f},
            },
    };
    for (const auto hand : {Side::LEFT, Side::RIGHT}) {
      actionSpaceInfo.subactionPath = std::get<0>(m_handSubactionPath[hand]);
      CHECK_XRCMD(xrCreateActionSpace(m_session, &actionSpaceInfo, &spaceList[hand]));
      CHECK(spaceList[hand] != XR_NULL_HANDLE);
    }
  };

  funCreateSpace(m_aimPoseAction, m_handAimSpace);
  funCreateSpace(m_gripPoseAction, m_handGripSpace);

  InitSuggestedBindings(std::forward<IsProfileSupportedFn>(isProfileSupported));

  const XrSessionActionSetsAttachInfo attachInfo{
      .type = XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO,
      .next = nullptr,
      .countActionSets = 1,
      .actionSets = &m_actionSet,
  };
  CHECK_XRCMD(xrAttachSessionActionSets(m_session, &attachInfo));
}

inline void InteractionManager::SyncActions() {
  CHECK(m_session != XR_NULL_HANDLE);
  // Sync actions
  const XrActiveActionSet activeActionSet{.actionSet = m_actionSet, .subactionPath = XR_NULL_PATH};
  const XrActionsSyncInfo syncInfo{.type = XR_TYPE_ACTIONS_SYNC_INFO,
                                   .next = nullptr,
                                   .countActiveActionSets = 1,
                                   .activeActionSets = &activeActionSet};
  CHECK_XRCMD(xrSyncActions(m_session, &syncInfo));
}

inline Json::Value InteractionManager::PollActions(const XrSpace& baseSpace, const XrTime& time) {
  SyncActions();
  const auto activeProfilePtr = m_activeProfile.load();
  Json::Value events;
  if (activeProfilePtr == nullptr) {
    LogW("PollActions() activeProfile=null");
    return events;
  }

  auto funcGetPose = [&](std::size_t side, XrActionStateGetInfo& getInfo, XrAction& action, HandSpaceList& spaceList,
                         std::string part, std::string path) -> void {
    bool isHandTrackingActive = false;

    Json::Value event;
    event["part"] = part;
    event["path"] = path;

    getInfo.action = action;
    XrActionStatePose poseState{.type = XR_TYPE_ACTION_STATE_POSE, .next = nullptr, .isActive = XR_FALSE};
    CHECK_XRCMD(xrGetActionStatePose(m_session, &getInfo, &poseState));

    if (poseState.isActive == XR_TRUE) {
      auto spaceLocation = Tcr::GetSpaceLocation(spaceList[side], baseSpace, time);
      Json::Value pose;
      Json::Value orientation;
      orientation["x"] = spaceLocation.pose.orientation.x;
      orientation["y"] = spaceLocation.pose.orientation.y;
      orientation["z"] = spaceLocation.pose.orientation.z;
      orientation["w"] = spaceLocation.pose.orientation.w;
      Json::Value position;
      position["x"] = spaceLocation.pose.position.x;
      position["y"] = spaceLocation.pose.position.y;
      position["z"] = spaceLocation.pose.position.z;

      pose["orientation"] = orientation;
      pose["position"] = position;

      Json::Value linerVelocity;
      linerVelocity["x"] = spaceLocation.linearVelocity.x;
      linerVelocity["y"] = spaceLocation.linearVelocity.y;
      linerVelocity["z"] = spaceLocation.linearVelocity.z;

      Json::Value angularVelocity;
      angularVelocity["x"] = spaceLocation.angularVelocity.x;
      angularVelocity["y"] = spaceLocation.angularVelocity.y;
      angularVelocity["z"] = spaceLocation.angularVelocity.z;

      pose["linear_velocity"] = linerVelocity;
      pose["angular_velocity"] = angularVelocity;

      event["pose"] = pose;
    }
    if (isHandTrackingActive || poseState.isActive == XR_TRUE) {
      events.append(event);
    }
  };

  for (const auto hand : {Side::LEFT, Side::RIGHT}) {
    auto [xrPath, partStr] = m_handSubactionPath[hand];
    XrActionStateGetInfo getInfo{.type = XR_TYPE_ACTION_STATE_GET_INFO, .next = nullptr, .subactionPath = xrPath};
    funcGetPose(hand, getInfo, m_aimPoseAction, m_handAimSpace, partStr, XRPaths::AimPose);
    funcGetPose(hand, getInfo, m_gripPoseAction, m_handGripSpace, partStr, XRPaths::GripPose);

    std::string part = partStr;
    const auto forEachButton = [&getInfo](/*const*/ auto& actionMap, const Tcr::ComponentPaths& inputMap,
                                          auto&& fn) -> void {
      for (const auto& path : inputMap) {
        const auto actionItr = actionMap.find(path);
        if (actionItr == actionMap.end()) continue;
        auto& action = actionItr->second;
        if (action.xrAction == XR_NULL_HANDLE) continue;
        getInfo.action = action.xrAction;
        fn(path);
      }
    };
    const auto& activeProfile = *activeProfilePtr;
    forEachButton(m_boolActionMap, activeProfile.boolPaths[hand], [&](const Path path) {
      XrActionStateBoolean boolValue{.type = XR_TYPE_ACTION_STATE_BOOLEAN, .next = nullptr, .isActive = XR_FALSE};
      if (XR_FAILED(xrGetActionStateBoolean(m_session, &getInfo, &boolValue))) return;
      if (boolValue.changedSinceLastSync == XR_TRUE) {
        Json::Value event;
        event["bool_value"] = boolValue.currentState == XR_TRUE;
        event["part"] = part;
        event["path"] = path;
        events.append(event);
      }
    });

    forEachButton(m_scalarActionMap, activeProfile.scalarPaths[hand], [&](const Path path) {
      XrActionStateFloat floatValue{.type = XR_TYPE_ACTION_STATE_FLOAT, .next = nullptr, .isActive = XR_FALSE};
      if (XR_FAILED(xrGetActionStateFloat(m_session, &getInfo, &floatValue)) || floatValue.isActive == XR_FALSE) return;
      if (floatValue.changedSinceLastSync == XR_TRUE) {
        Json::Value event;
        event["float_value"] = floatValue.currentState;
        event["part"] = part;
        event["path"] = path;
        events.append(event);
      }
    });

    forEachButton(m_vector2fActionMap, activeProfile.vector2fPaths[hand], [&](const Path path) {
      XrActionStateVector2f vec2Value{.type = XR_TYPE_ACTION_STATE_VECTOR2F, .next = nullptr, .isActive = XR_FALSE};
      if (XR_FAILED(xrGetActionStateVector2f(m_session, &getInfo, &vec2Value)) || vec2Value.isActive == XR_FALSE)
        return;

      if (vec2Value.changedSinceLastSync) {
        Json::Value vector2;
        vector2["x"] = vec2Value.currentState.x;
        vector2["y"] = vec2Value.currentState.y;
        Json::Value event;
        event["vector2f"] = vector2;
        event["part"] = part;
        event["path"] = path;
        events.append(event);
      }
    });
  }
  return events;
}

inline const InteractionProfile* InteractionManager::GetInteractionProfile(const XrPath newProfilePath) {
  const auto newProfileItr =
      std::find_if(Tcr::InteractionProfileMap.begin(), Tcr::InteractionProfileMap.end(),
                   [&](const Tcr::InteractionProfile& ip) { return newProfilePath == GetXrPath(ip.path); });
  return newProfileItr == Tcr::InteractionProfileMap.end() ? nullptr : &*newProfileItr;
}

inline void InteractionManager::SetActiveProfile(const XrPath newProfilePath) {
  const auto* const newProfile = GetInteractionProfile(newProfilePath);
  m_activeProfile.store(newProfile);

  LogI("Interaction Profile Changed");
  if (newProfile)
    LogI("\tNew selected profile: \"%s\"", newProfile->path);
  else
    LogI("No new profile selected.");
}

inline void InteractionManager::SetActiveFromCurrentProfile() { SetActiveProfile(GetCurrentProfilePath()); }

inline void InteractionManager::LogActionSourceName(XrAction action, const char* const actionName) const {
  if (action == XR_NULL_HANDLE || actionName == nullptr) return;

  const XrBoundSourcesForActionEnumerateInfo getInfo{
      .type = XR_TYPE_BOUND_SOURCES_FOR_ACTION_ENUMERATE_INFO, .next = nullptr, .action = action};
  uint32_t pathCount = 0;
  CHECK_XRCMD(xrEnumerateBoundSourcesForAction(m_session, &getInfo, 0, &pathCount, nullptr));
  std::vector<XrPath> paths(pathCount);
  CHECK_XRCMD(xrEnumerateBoundSourcesForAction(m_session, &getInfo, uint32_t(paths.size()), &pathCount, paths.data()));

  constexpr const XrInputSourceLocalizedNameFlags NameFlagsAll =
      XR_INPUT_SOURCE_LOCALIZED_NAME_USER_PATH_BIT | XR_INPUT_SOURCE_LOCALIZED_NAME_INTERACTION_PROFILE_BIT |
      XR_INPUT_SOURCE_LOCALIZED_NAME_COMPONENT_BIT;
  std::string sourceName;
  for (uint32_t i = 0; i < pathCount; ++i) {
    const XrInputSourceLocalizedNameGetInfo nameInfo{.type = XR_TYPE_INPUT_SOURCE_LOCALIZED_NAME_GET_INFO,
                                                     .next = nullptr,
                                                     .sourcePath = paths[i],
                                                     .whichComponents = NameFlagsAll};
    uint32_t size = 0;
    CHECK_XRCMD(xrGetInputSourceLocalizedName(m_session, &nameInfo, 0, &size, nullptr));
    if (size < 1) continue;
    std::vector<char> grabSource(size);
    CHECK_XRCMD(
        xrGetInputSourceLocalizedName(m_session, &nameInfo, uint32_t(grabSource.size()), &size, grabSource.data()));
    if (!sourceName.empty()) sourceName += " and ";
    sourceName += "'";
    sourceName += std::string(grabSource.data(), size - 1);
    sourceName += "'";
  }

  LogI("%s action is bound to %s", actionName, ((!sourceName.empty()) ? sourceName.c_str() : "nothing"));
}

inline void InteractionManager::LogActions() const {
  if (m_session == XR_NULL_HANDLE) return;
  LogActionSourceName(m_aimPoseAction, "Aim Pose");
  LogActionSourceName(m_gripPoseAction, "Grip Pose");
  for (const auto& [k, v] : m_boolActionMap) LogActionSourceName(v.xrAction, v.localizedName);
  for (const auto& [k, v] : m_scalarActionMap) LogActionSourceName(v.xrAction, v.localizedName);
  for (const auto& [k, v] : m_vector2fActionMap) LogActionSourceName(v.xrAction, v.localizedName);
}

}  // namespace Tcr
#endif  // TCR_INTERACTION_MANAGER_H

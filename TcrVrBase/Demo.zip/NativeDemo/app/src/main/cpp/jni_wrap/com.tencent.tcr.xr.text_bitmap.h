//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "ObjectWrapperBase.h"

namespace wrap::tcr::xr {
class TextBitmap : public ObjectWrapperBase {
 public:
  using ObjectWrapperBase::ObjectWrapperBase;
  static constexpr const char *getTypeName() noexcept { return "com/tencent/tcr/xr/TextBitmap"; }


  /*!
   * Wrapper for the getByteBuffer method.
   * 这个函数可以直接调用到Java层的com.tencent.tcr.xr.TextBitmap.getByteBuffer()函数，
   *
   * Java prototype:
   * `public static java.nio.ByteBuffer getByteBuffer(java.lang.String);`
   *
   * JNI signature: (Ljava/lang/String;)Ljava/nio/ByteBuffer;
   *
   */
  inline static jni::Object getByteBuffer(std::string const &msg) {
    return Meta::data().clazz().call<jni::Object>(Meta::data().getByteBuffer, msg);
  }

  /*!
   * Class metadata
   */
  struct Meta : public MetaBase {
    jni::method_t getByteBuffer;

    /*!
     * Singleton accessor
     */
    static Meta &data() {
      static Meta instance{};
      return instance;
    }

   private:
    explicit Meta();
  };

};

}  // namespace wrap::tcr::xr
//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "../logger.h"

namespace wrap {
namespace tcr {
namespace xr {
inline void VideoFrame::retain() {
  assert(!isNull());
  object().call<void>(Meta::data(object().getClass()).retain);
}

inline void VideoFrame::release() {
  assert(!isNull());
  object().call<void>(Meta::data(object().getClass()).release);
}

inline std::uint64_t VideoFrame::getTextureId() {
  assert(!isNull());
  long long value = object().call<long long>(Meta::data(object().getClass()).getTextureId);
  return value;
}

inline std::int64_t VideoFrame::getWidth() {
  assert(!isNull());
  long long value = object().call<long long>(Meta::data(object().getClass()).getWidth);
  return value;
}

inline std::int64_t VideoFrame::getHeight() {
  assert(!isNull());
  long long value = object().call<long long>(Meta::data(object().getClass()).getHeight);
  return value;
}

inline std::string VideoFrame::getAssociateData() {
  assert(!isNull());
  return object().call<std::string>(Meta::data(object().getClass()).getAssociateData);
}

inline Pose VideoFrame::getPose() {
  assert(!isNull());
  return Pose(object().call<jni::Object>(Meta::data(object().getClass()).getPose));
}

inline Fov VideoFrame::getLeftFov() {
  assert(!isNull());
  return Fov(object().call<jni::Object>(Meta::data(object().getClass()).getLeftFov));
}

inline Fov VideoFrame::getRightFov() {
  assert(!isNull());
  return Fov(object().call<jni::Object>(Meta::data(object().getClass()).getRightFov));
}

inline std::int64_t VideoFrame::getLatency() {
  assert(!isNull());
  return object().call<long long>(Meta::data(object().getClass()).getLatency);
}

}  // namespace xr
}  // namespace tcr
}  // namespace wrap
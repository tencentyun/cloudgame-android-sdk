//
// Created by cyy on 2022/9/8.
//

#include "com.tencent.tcr.xr.api.bean.math_vector3f.h"
namespace wrap::tcr::xr {

Vector3f::Meta::Meta(jni::jclass clazz)
    : MetaBaseDroppable(getTypeName(), clazz),
      getX(classRef().getMethod("getX", "()D")),
      getY(classRef().getMethod("getY", "()D")),
      getZ(classRef().getMethod("getZ", "()D")) {
    MetaBaseDroppable::dropClassRef();
}

}  // namespace wrap::tcr::xr
//
// Created by cyy on 2022/9/8.
//

#pragma once
#include "ObjectWrapperBase.h"
#include "com.tencent.tcr.xr.api.bean.math_fov.h"
#include "com.tencent.tcr.xr.api.bean.math_pose.h"

namespace wrap::tcr::xr {
class VideoFrame : public ObjectWrapperBase {
 public:
  using ObjectWrapperBase::ObjectWrapperBase;
  static constexpr const char *getTypeName() noexcept { return "com/tencent/tcr/xr/VideoFrame"; }

  /*!
   * Wrapper for the retain method
   *
   * Java prototype:
   * `public void retain();`
   *
   * JNI signature: ()V
   *
   */
  void retain();

  /*!
   * Wrapper for the release method
   *
   * Java prototype:
   * `public void release();`
   *
   * JNI signature: ()V
   *
   */
  void release();

  /*!
   * Wrapper for the updateTexture method
   *
   * Java prototype:
   * `public long updateTexture();`
   *
   * JNI signature: ()J
   *
   */
  std::uint64_t updateTexture();

  /*!
   * Wrapper for the getWidth method
   *
   * Java prototype:
   * `public long getWidth();`
   *
   * JNI signature: ()J
   *
   */
  std::int64_t getWidth();

  /*!
   * Wrapper for the getHeight method
   *
   * Java prototype:
   * `public long getHeight();`
   *
   * JNI signature: ()J
   *
   */
  std::int64_t getHeight();

  /*!
   * Wrapper for the getAssociateData method.
   *
   * Java prototype:
   * `public java.lang.Object getAssociateData();`
   *
   * JNI signature: descriptor: ()Ljava/lang/Object;
   *
   */
  std::string getAssociateData();
  /*!
   * Wrapper for the getPose method
   *
   * Java prototype:
   * `public com.tencent.tcr.xr.api.bean.math.Pose getPose();`
   *
   * JNI signature:  descriptor: ()Lcom/tencent/tcr/xr/api/bean/math/Pose;
   *
   */
  Pose getPose();

  /*!
   * Wrapper for the getLeftFov method
   *
   * Java prototype:
   * `public com.tencent.tcr.xr.api.bean.math.Fov getLeftFov();`
   *
   * JNI signature: descriptor: ()Lcom/tencent/tcr/xr/api/bean/math/Fov;
   *
   */
  Fov getLeftFov();

  /*!
   * Wrapper for the getRightFov method
   *
   * Java prototype:
   * `public com.tencent.tcr.xr.api.bean.math.Fov getRightFov();`
   *
   * JNI signature: descriptor: ()Lcom/tencent/tcr/xr/api/bean/math/Fov;
   *
   */
  Fov getRightFov();

  /*!
   * Wrapper for the getLatency method
   *
   * Java prototype:
   * `public long getLatency();`
   *
   * JNI signature: ()J
   *
   */
  std::int64_t getLatency();

  /*!
   * Class metadata
   */
  struct Meta : public MetaBaseDroppable {
    jni::method_t retain;
    jni::method_t release;
    jni::method_t updateTexture;
    jni::method_t getWidth;
    jni::method_t getHeight;
    jni::method_t getAssociateData;
    jni::method_t getPose;
    jni::method_t getLeftFov;
    jni::method_t getRightFov;
    jni::method_t getLatency;

    /*!
     * Singleton accessor
     */
    static Meta &data(jni::jclass clazz) {
      static Meta instance{clazz};
      return instance;
    }

   private:
    explicit Meta(jni::jclass clazz);
  };
};

}  // namespace wrap::tcr::xr
#include "com.tencent.tcr.xr.tcr_videoFrame.impl.h"
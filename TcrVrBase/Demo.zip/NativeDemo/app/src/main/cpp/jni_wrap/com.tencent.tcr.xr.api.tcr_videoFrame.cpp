//
// Created by cyy on 2022/9/8.
//

#include "com.tencent.tcr.xr.api.tcr_videoFrame.h"
namespace wrap::tcr::xr {
VideoFrame::Meta::Meta(jni::jclass clazz)
    : MetaBaseDroppable(getTypeName(), clazz),
      retain(classRef().getMethod("retain", "()V")),
      release(classRef().getMethod("release", "()V")),
      getTextureId(classRef().getMethod("getTextureId", "()J")),
      getWidth(classRef().getMethod("getWidth", "()J")),
      getHeight(classRef().getMethod("getHeight", "()J")),
      getAssociateData(classRef().getMethod("getAssociateData", "()Ljava/lang/Object;")),
      getPose(classRef().getMethod("getPose", "()Lcom/tencent/tcr/xr/api/bean/math/Pose;")),
      getLeftFov(classRef().getMethod("getLeftFov", "()Lcom/tencent/tcr/xr/api/bean/math/Fov;")),
      getRightFov(classRef().getMethod("getRightFov", "()Lcom/tencent/tcr/xr/api/bean/math/Fov;")),
      getLatency(classRef().getMethod("getLatency", "()J")){
  MetaBaseDroppable::dropClassRef();
}

}  // namespace wrap::tcr::xr
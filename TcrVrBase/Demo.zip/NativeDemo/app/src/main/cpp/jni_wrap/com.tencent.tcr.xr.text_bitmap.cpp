//
// Created by cyy on 2022/9/8.
//

#include "com.tencent.tcr.xr.text_bitmap.h"
namespace wrap::tcr::xr {

TextBitmap::Meta::Meta()
    : MetaBase(getTypeName()), getByteBuffer(classRef().getStaticMethod("getByteBuffer", "(Ljava/lang/String;)Ljava/nio/ByteBuffer;")) {}

}  // namespace wrap::tcr::xr
#pragma once

#ifndef TCRXRSDK_TCR_XR_SRC_MAIN_CPP_OPENXR_WRAPPER_H_
#  define TCRXRSDK_TCR_XR_SRC_MAIN_CPP_OPENXR_WRAPPER_H_

struct SwapchainRect {
  XrSwapchain swapchain;
  XrRect2Di rect;
};

inline XrSwapchain CreateSwapchain(const XrSession& session, uint32_t width, uint32_t height, int64_t format) {
  CHECK(session != XR_NULL_HANDLE);

  XrSwapchainCreateInfo swapChainCreateInfo{XR_TYPE_SWAPCHAIN_CREATE_INFO,
                                            XR_NULL_HANDLE,
                                            0x0,
                                            XR_SWAPCHAIN_USAGE_SAMPLED_BIT | XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT,
                                            format,
                                            1,
                                            width,
                                            height,
                                            1,
                                            1,
                                            1};

  XrSwapchain handle;
  CHECK_XRCMD(xrCreateSwapchain(session, &swapChainCreateInfo, &handle));
  return handle;
}

inline SwapchainRect CreateSwapchainRect(const XrSession& session, uint32_t width, uint32_t height, int64_t format) {
  XrSwapchain swapchain = CreateSwapchain(session, width, height, format);
  XrRect2Di rect = {{0, 0}, {static_cast<int32_t>(width), static_cast<int32_t>(height)}};
  return SwapchainRect{swapchain, rect};
}

inline std::vector<XrExtensionProperties> EnumerateExtensions(const char* layerName) {
  uint32_t instanceExtensionCount;
  CHECK_XRCMD(xrEnumerateInstanceExtensionProperties(layerName, 0, &instanceExtensionCount, nullptr));

  std::vector<XrExtensionProperties> extensions(instanceExtensionCount);
  for (XrExtensionProperties& extension : extensions) {
    extension.type = XR_TYPE_EXTENSION_PROPERTIES;
  }

  CHECK_XRCMD(xrEnumerateInstanceExtensionProperties(layerName, (uint32_t)extensions.size(), &instanceExtensionCount,
                                                     extensions.data()));
  return extensions;
}

inline std::vector<int64_t> EnumerateSwapChainFormats(const XrSession& session) {
  CHECK(session != XR_NULL_HANDLE);
  uint32_t swapChainFormatCount;
  CHECK_XRCMD(xrEnumerateSwapchainFormats(session, 0, &swapChainFormatCount, nullptr));
  std::vector<int64_t> swapChainFormats(swapChainFormatCount);
  CHECK_XRCMD(xrEnumerateSwapchainFormats(session, (uint32_t)swapChainFormats.size(), &swapChainFormatCount,
                                          swapChainFormats.data()));
  CHECK(swapChainFormatCount == swapChainFormats.size());
  return swapChainFormats;
}

inline std::vector<uint32_t> EnumerateSwapchainImages(const XrSwapchain& handle) {
  // 查询Swap chain支持的图像数量
  uint32_t imageCount;
  CHECK_XRCMD(xrEnumerateSwapchainImages(handle, 0, &imageCount, nullptr));
  std::vector<XrSwapchainImageOpenGLESKHR> swapchianImages(imageCount);
  for (XrSwapchainImageOpenGLESKHR& image : swapchianImages) {
    image.type = XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_ES_KHR;
  }

  // 拿到Swap chain支持的图像
  CHECK_XRCMD(
      xrEnumerateSwapchainImages(handle, imageCount, &imageCount, (XrSwapchainImageBaseHeader*)(&swapchianImages[0])));
  std::vector<uint32_t> result;
  result.resize(swapchianImages.size());

  std::transform(swapchianImages.begin(), swapchianImages.end(), result.begin(),
                 [](XrSwapchainImageOpenGLESKHR img) -> uint32_t { return img.image; });
  return result;
}

inline std::vector<XrApiLayerProperties> EnumerateLayers() {
  uint32_t layerCount;
  CHECK_XRCMD(xrEnumerateApiLayerProperties(0, &layerCount, nullptr));

  std::vector<XrApiLayerProperties> layers(layerCount);
  for (XrApiLayerProperties& layer : layers) {
    layer.type = XR_TYPE_API_LAYER_PROPERTIES;
  }
  CHECK_XRCMD(xrEnumerateApiLayerProperties((uint32_t)layers.size(), &layerCount, layers.data()));
  return layers;
}

inline std::vector<XrViewConfigurationType> EnumerateViewConfigurations(const XrInstance& instance,
                                                                        const XrSystemId& systemId) {
  uint32_t viewConfigTypeCount;
  CHECK_XRCMD(xrEnumerateViewConfigurations(instance, systemId, 0, &viewConfigTypeCount, nullptr));
  std::vector<XrViewConfigurationType> viewConfigTypes(viewConfigTypeCount);
  CHECK_XRCMD(xrEnumerateViewConfigurations(instance, systemId, viewConfigTypeCount, &viewConfigTypeCount,
                                            viewConfigTypes.data()));
  CHECK((uint32_t)viewConfigTypes.size() == viewConfigTypeCount);
  return viewConfigTypes;
}

inline std::vector<XrViewConfigurationView> EnumerateViewConfigurationViews(
    const XrInstance& instance, const XrSystemId& systemId, const XrViewConfigurationType& viewConfigType) {
  uint32_t viewCount;
  CHECK_XRCMD(xrEnumerateViewConfigurationViews(instance, systemId, viewConfigType, 0, &viewCount, nullptr));
  CHECK(viewCount > 1);

  std::vector<XrViewConfigurationView> views(viewCount, {XR_TYPE_VIEW_CONFIGURATION_VIEW});
  CHECK_XRCMD(
      xrEnumerateViewConfigurationViews(instance, systemId, viewConfigType, viewCount, &viewCount, views.data()));
  return views;
}

inline void BeginSession(const XrSession& session) {
  CHECK(session != XR_NULL_HANDLE);
  XrSessionBeginInfo sessionBeginInfo{XR_TYPE_SESSION_BEGIN_INFO, XR_NULL_HANDLE,
                                      XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO};
  sessionBeginInfo.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
  CHECK_XRCMD(xrBeginSession(session, &sessionBeginInfo));
}

inline bool LocateViews(const XrSession& session, const XrSpace& space, const XrTime predictedDisplayTime,
                        const std::uint32_t viewCapacityInput, XrView* views) {
  CHECK(session != XR_NULL_HANDLE);
  CHECK(space != XR_NULL_HANDLE);

  const XrViewLocateInfo viewLocateInfo{
      .type = XR_TYPE_VIEW_LOCATE_INFO,
      .next = nullptr,
      .viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,
      .displayTime = predictedDisplayTime,
      .space = space,
  };
  XrViewState viewState{.type = XR_TYPE_VIEW_STATE, .next = nullptr};
  uint32_t viewCountOutput = 0;
  const XrResult res = xrLocateViews(session, &viewLocateInfo, &viewState, viewCapacityInput, &viewCountOutput, views);

  CHECK_XRRESULT(res, "LocateViews");
  if ((viewState.viewStateFlags & XR_VIEW_STATE_POSITION_VALID_BIT) == 0 ||
      (viewState.viewStateFlags & XR_VIEW_STATE_ORIENTATION_VALID_BIT) == 0) {
    return false;  // There is no valid tracking poses for the views.
  }
  CHECK(viewCountOutput == viewCapacityInput);
  return true;
}

inline std::vector<XrReferenceSpaceType> EnumerateReferenceSpaces(const XrSession& session) {
  CHECK(session != XR_NULL_HANDLE);

  uint32_t spaceCount;
  CHECK_XRCMD(xrEnumerateReferenceSpaces(session, 0, &spaceCount, nullptr));
  std::vector<XrReferenceSpaceType> spaces(spaceCount);
  CHECK_XRCMD(xrEnumerateReferenceSpaces(session, spaceCount, &spaceCount, spaces.data()));
  CHECK(spaceCount == spaces.size());
  return spaces;
}

inline std::vector<XrViewConfigurationView> EnumerateViewConfigurationViews(XrInstance instance, XrSystemId systemId) {
  CHECK(instance != XR_NULL_HANDLE);
  uint32_t viewCount;
  CHECK_XRCMD(xrEnumerateViewConfigurationViews(instance, systemId, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 0,
                                                &viewCount, nullptr));
  std::vector<XrViewConfigurationView> views;
  views.resize(viewCount, {XR_TYPE_VIEW_CONFIGURATION_VIEW});
  CHECK_XRCMD(xrEnumerateViewConfigurationViews(instance, systemId, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,
                                                viewCount, &viewCount, views.data()));
  return views;
}

inline void CreateSession(const XrInstance& instance, const XrSystemId& systemId, XrSession* session,
                          const XrBaseInStructure* next) {
  CHECK(instance != XR_NULL_HANDLE);

  LogD("Creating session...");
  XrSessionCreateInfo createInfo{XR_TYPE_SESSION_CREATE_INFO};
  createInfo.next = next;
  createInfo.systemId = systemId;
  CHECK_XRCMD(xrCreateSession(instance, &createInfo, session));
}

void DestroySwapchain(SwapchainRect& swapChainRect) {
  bool swapChainValid = swapChainRect.rect.extent.width != 0 && swapChainRect.rect.extent.height != 0;
  if (swapChainValid) {
    CHECK_XRCMD(xrDestroySwapchain(swapChainRect.swapchain));
  }
}

void EndFrame(const XrSession& session, const XrSpace& space, const XrTime& displayTime,
              std::array<XrCompositionLayerProjectionView, 2> projectionViews) {
  CHECK(session != XR_NULL_HANDLE);
  CHECK(space != XR_NULL_HANDLE);
  CHECK(projectionViews.size() == 2);

  XrCompositionLayerProjection layer{
      XR_TYPE_COMPOSITION_LAYER_PROJECTION, XR_NULL_HANDLE, 0, space, projectionViews.size(), projectionViews.data()};

  std::array<XrCompositionLayerBaseHeader*, 1> layers = {(XrCompositionLayerBaseHeader*)&layer};

  XrFrameEndInfo frameEndInfo{XR_TYPE_FRAME_END_INFO};
  frameEndInfo.displayTime = displayTime;
  frameEndInfo.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
  frameEndInfo.layerCount = (uint32_t)layers.size();
  frameEndInfo.layers = layers.data();
  CHECK_XRCMD(xrEndFrame(session, &frameEndInfo));
}

uint32_t AcquireSwapchianImage(XrSwapchain handle) {
  XrSwapchainImageAcquireInfo acquireInfo{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
  uint32_t swapchainImageIndex;
  CHECK_XRCMD(xrAcquireSwapchainImage(handle, &acquireInfo, &swapchainImageIndex));
  return swapchainImageIndex;
}

void WaitSwapchainImage(XrSwapchain handle) {
  XrSwapchainImageWaitInfo waitInfo{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
  waitInfo.timeout = XR_INFINITE_DURATION;
  CHECK_XRCMD(xrWaitSwapchainImage(handle, &waitInfo));
}

void ReleaseSwapchainImage(XrSwapchain handle) {
  XrSwapchainImageReleaseInfo releaseInfo{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
  CHECK_XRCMD(xrReleaseSwapchainImage(handle, &releaseInfo));
}

void EndEmptyFrame(const XrSession& session, XrTime displayTime) {
  CHECK(session != XR_NULL_HANDLE);
  XrFrameEndInfo frameEndInfo{XR_TYPE_FRAME_END_INFO};
  frameEndInfo.displayTime = displayTime;
  frameEndInfo.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
  frameEndInfo.layerCount = 0;
  frameEndInfo.layers = XR_NULL_HANDLE;
  CHECK_XRCMD(xrEndFrame(session, &frameEndInfo));
}

void CreateHandTracker(const XrInstance& instance, const XrSession& session, XrHandTrackerEXT& leftHandTracker,
                       XrHandTrackerEXT& rightHandTracker) {
  PFN_xrCreateHandTrackerEXT pfnXrCreateHandTrackerExt;
  // 获取xrCreateHandTrackerEXT的函数指针
  CHECK_XRCMD(xrGetInstanceProcAddr(instance, "xrCreateHandTrackerEXT",
                                    reinterpret_cast<PFN_xrVoidFunction*>(&pfnXrCreateHandTrackerExt)));

  XrHandTrackerCreateInfoEXT createInfo{XR_TYPE_HAND_TRACKER_CREATE_INFO_EXT};

  // 创建左手
  createInfo.hand = XR_HAND_LEFT_EXT;
  createInfo.handJointSet = XR_HAND_JOINT_SET_DEFAULT_EXT;
  CHECK_XRCMD(pfnXrCreateHandTrackerExt(session, &createInfo, &leftHandTracker));

  // 创建右手
  createInfo.hand = XR_HAND_RIGHT_EXT;
  createInfo.handJointSet = XR_HAND_JOINT_SET_DEFAULT_EXT;
  CHECK_XRCMD(pfnXrCreateHandTrackerExt(session, &createInfo, &rightHandTracker));
}

inline XrReferenceSpaceCreateInfo GetXrReferenceSpaceCreateInfo(XrReferenceSpaceType referenceSpaceType) {
  XrReferenceSpaceCreateInfo referenceSpaceCreateInfo{.type = XR_TYPE_REFERENCE_SPACE_CREATE_INFO,
                                                      .next = nullptr,
                                                      .referenceSpaceType = referenceSpaceType,
                                                      .poseInReferenceSpace = Tcr::Pose::Identity};
  return referenceSpaceCreateInfo;
}

inline void CreateReferenceSpace(XrSession sesison, XrReferenceSpaceType referenceSpaceType, XrSpace* space) {
  CHECK(sesison != XR_NULL_HANDLE);
  XrReferenceSpaceCreateInfo referenceSpaceCreateInfo = GetXrReferenceSpaceCreateInfo(referenceSpaceType);
  CHECK_XRCMD(xrCreateReferenceSpace(sesison, &referenceSpaceCreateInfo, space));
}

inline void LogReferenceSpaces(const XrSession& session) {
  auto spaces = EnumerateReferenceSpaces(session);
  LogD("Available reference spaces: %zu", spaces.size());
  for (XrReferenceSpaceType space : spaces) {
    LogD("  Name: %s", to_string(space));
  }
}

inline void LogInstanceInfo(const XrInstance& instance) {
  CHECK(instance != XR_NULL_HANDLE);

  XrInstanceProperties instanceProperties{XR_TYPE_INSTANCE_PROPERTIES};
  CHECK_XRCMD(xrGetInstanceProperties(instance, &instanceProperties));

  LogD("Instance RuntimeName=%s RuntimeVersion=%s", instanceProperties.runtimeName,
       Tcr::GetXrVersionString(instanceProperties.runtimeVersion).c_str());
}

inline void LogEnvironmentBlendMode(const XrInstance& instance, const XrSystemId& systemId,
                                    XrViewConfigurationType type) {
  CHECK(instance != XR_NULL_HANDLE);
  CHECK(systemId != 0);

  uint32_t count;
  CHECK_XRCMD(xrEnumerateEnvironmentBlendModes(instance, systemId, type, 0, &count, nullptr));
  CHECK(count > 0);

  LogI("Available Environment Blend Mode count : (%d)", count);

  std::vector<XrEnvironmentBlendMode> blendModes(count);
  CHECK_XRCMD(xrEnumerateEnvironmentBlendModes(instance, systemId, type, count, &count, blendModes.data()));

  bool blendModeFound = false;
  for (XrEnvironmentBlendMode mode : blendModes) {
    const bool blendModeMatch = (mode == XR_ENVIRONMENT_BLEND_MODE_OPAQUE);
    LogI("Environment Blend Mode (%s) : %s", to_string(mode), blendModeMatch ? "(Selected)" : "");
    blendModeFound |= blendModeMatch;
  }
  CHECK(blendModeFound);
}

inline void LogViewConfigurations(const XrInstance& instance, const XrSystemId& systemId) {
  CHECK(instance != XR_NULL_HANDLE);
  CHECK(systemId != XR_NULL_SYSTEM_ID);

  auto viewConfigTypes = EnumerateViewConfigurations(instance, systemId);
  LogI("Available View Configuration Types: (%zu)", viewConfigTypes.size());

  for (XrViewConfigurationType viewConfigType : viewConfigTypes) {
    LogV("  View Configuration Type: %s %s", to_string(viewConfigType),
         viewConfigType == XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO ? "(Selected)" : "");

    XrViewConfigurationProperties viewConfigProperties{XR_TYPE_VIEW_CONFIGURATION_PROPERTIES};
    CHECK_XRCMD(xrGetViewConfigurationProperties(instance, systemId, viewConfigType, &viewConfigProperties));

    LogV("  View configuration FovMutable=%s", viewConfigProperties.fovMutable == XR_TRUE ? "True" : "False");

    auto views = EnumerateViewConfigurationViews(instance, systemId, viewConfigType);
    for (uint32_t i = 0; i < views.size(); i++) {
      const XrViewConfigurationView& view = views[i];

      LogV("    View [%d]: Recommended Width=%d Height=%d SampleCount=%d", i, view.recommendedImageRectWidth,
           view.recommendedImageRectHeight, view.recommendedSwapchainSampleCount);
      LogV("    View [%d]:     Maximum Width=%d Height=%d SampleCount=%d", i, view.maxImageRectWidth,
           view.maxImageRectHeight, view.maxSwapchainSampleCount);
    }
    LogEnvironmentBlendMode(instance, systemId, viewConfigType);
  }
}

inline void LogSystemProperties(const XrInstance& instance, const XrSystemId& systemId) {
  CHECK(instance != XR_NULL_HANDLE);
  // 获取系统属性，为创建Swap chain提供相应参数
  XrSystemProperties systemProperties{XR_TYPE_SYSTEM_PROPERTIES};
  CHECK_XRCMD(xrGetSystemProperties(instance, systemId, &systemProperties));

  // 打印部分系统属性
  LogI("System Properties: Name=%s VendorId=%d", systemProperties.systemName, systemProperties.vendorId);
  LogI("System Graphics Properties: MaxWidth=%d MaxHeight=%d MaxLayers=%d",
       systemProperties.graphicsProperties.maxSwapchainImageWidth,
       systemProperties.graphicsProperties.maxSwapchainImageHeight, systemProperties.graphicsProperties.maxLayerCount);
  LogI("System Tracking Properties: OrientationTracking=%s PositionTracking=%s",
       systemProperties.trackingProperties.orientationTracking == XR_TRUE ? "True" : "False",
       systemProperties.trackingProperties.positionTracking == XR_TRUE ? "True" : "False");
}

#endif  // TCRXRSDK_TCR_XR_SRC_MAIN_CPP_OPENXR_WRAPPER_H_

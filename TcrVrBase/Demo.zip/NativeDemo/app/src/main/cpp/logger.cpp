// Copyright (c) 2017-2022, The Khronos Group Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include "logger.h"
#include <cstdarg>
#include <vector>
#include <cstdio>
#include "pch.h"

namespace {
Log::Level g_minSeverity{Log::Level::Info};
}  // namespace

namespace Log {
void SetLevel(Level minSeverity) { g_minSeverity = minSeverity; }

void Write(Level severity, const char* fmt, ...) {
  if (severity < g_minSeverity) {
    return;
  }

  // https://codereview.stackexchange.com/questions/115760/use-va-list-to-format-a-string
  auto temp = std::vector<char>{};
  auto length = std::size_t{63};
  std::va_list args;
  while (temp.size() <= length) {
    temp.resize(length + 1);
    va_start(args, fmt);
    const auto status = std::vsnprintf(temp.data(), temp.size(), fmt, args);
    va_end(args);
    if (status < 0) throw std::runtime_error{"string formatting error"};
    length = static_cast<std::size_t>(status);
  }

  const char* TAG = "tcr-xr";
  if (severity == Level::Error)
    __android_log_print(ANDROID_LOG_ERROR, TAG, "%s", temp.data());
  else if (severity == Level::Warning)
    __android_log_print(ANDROID_LOG_WARN, TAG, "%s", temp.data());
  else if (severity == Level::Info)
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", temp.data());
  else if (severity == Level::Debug)
    __android_log_print(ANDROID_LOG_DEBUG, TAG, "%s", temp.data());
  else
    __android_log_print(ANDROID_LOG_VERBOSE, TAG, "%s", temp.data());
}

}  // namespace Log

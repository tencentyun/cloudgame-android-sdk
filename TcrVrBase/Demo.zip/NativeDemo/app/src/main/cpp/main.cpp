#include <jni.h>
#include <jni_wrap/com.tencent.tcr.xr.api.tcr_activity.h>
#include <jni_wrap/com.tencent.tcr.xr.text_bitmap.h>
#include <jni_wrap/java.lang.h>
#include <jnipp.h>
#include <unistd.h>
#include <atomic>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include "common.h"
#include "json/json.h"
#include "openxr_program.h"
#include "pch.h"
#include "platformdata.h"

class GlobalContext {
 public:
  int readCmdFd{};
  int writeCmdFd{};
  bool requestingTrackingInfo;
  std::mutex requestingMtx;
  std::shared_ptr<IOpenXrProgram> xrProgram;
  bool streamReady = false;
};

namespace {
GlobalContext g_ctx{};
}  // namespace

struct Cmd {
  std::string type;
  std::string message;
};

inline void write_string(const std::string &str) {
  uint32_t len = str.length();
  if (write(g_ctx.writeCmdFd, &len, sizeof(len)) != sizeof(len)) {
    LogE("write len failed cmd:%s msg:%s %s", str.c_str(), str.c_str(), strerror(errno));
  }
  if (write(g_ctx.writeCmdFd, str.c_str(), len) != len) {
    LogE("write string failed cmd:%s msg:%s %s", str.c_str(), str.c_str(), strerror(errno));
  }
}

inline std::string read_string() {
  uint32_t len = 0;
  if (read(g_ctx.readCmdFd, &len, sizeof(len)) != sizeof(len)) {
    LogE("read len failed: %s", strerror(errno));
  }
  std::string str(len, '\0');
  if (read(g_ctx.readCmdFd, &str[0], len) != len) {
    LogE("read string failed: %s", strerror(errno));
  }
  return str;
}

inline void write_cmd(const Cmd &cmd) {
  write_string(cmd.type);
  write_string(cmd.message);
}

inline Cmd read_cmd() {
  Cmd cmd{};
  cmd.type = read_string();
  cmd.message = read_string();
  return cmd;
}

bool initPipe(ALooper *looper) {
  int msgPipe[2];
  if (pipe(msgPipe)) {
    LogE("could not create pipe: %s", strerror(errno));
    return false;
  }
  g_ctx.readCmdFd = msgPipe[0];
  g_ctx.writeCmdFd = msgPipe[1];
  if (ALooper_addFd(looper, g_ctx.readCmdFd, LOOPER_ID_USER, ALOOPER_EVENT_INPUT, nullptr, nullptr) == -1) {
    LogE("ALooper_addFd() = -1 %s", strerror(errno));
    return false;
  }
  return true;
}

inline void initLoader(JavaVM *vm, jobject activityJavaObj) {
  PFN_xrInitializeLoaderKHR initializeLoader = nullptr;
  if (XR_SUCCEEDED(
          xrGetInstanceProcAddr(XR_NULL_HANDLE, "xrInitializeLoaderKHR", (PFN_xrVoidFunction *)(&initializeLoader)))) {
    XrLoaderInitInfoAndroidKHR loaderInitInfoAndroid;
    memset(&loaderInitInfoAndroid, 0, sizeof(loaderInitInfoAndroid));
    loaderInitInfoAndroid.type = XR_TYPE_LOADER_INIT_INFO_ANDROID_KHR;
    loaderInitInfoAndroid.next = nullptr;
    loaderInitInfoAndroid.applicationVM = vm;
    loaderInitInfoAndroid.applicationContext = activityJavaObj;
    initializeLoader((const XrLoaderInitInfoBaseHeaderKHR *)&loaderInitInfoAndroid);
  }
}

void pauseRequesting() {
  std::lock_guard<std::mutex> lock(g_ctx.requestingMtx);
  g_ctx.requestingTrackingInfo = false;
}

void resumeRequesting() {
  std::lock_guard<std::mutex> lock(g_ctx.requestingMtx);
  g_ctx.requestingTrackingInfo = true;
}

inline void entry(struct android_app *app, JavaVM *vm, jobject activityJavaObj,
                  const std::shared_ptr<IOpenXrProgram> &xrProgram) {
  if (!initPipe(app->looper)) {
    LogE("entry() !initPipe");
    return;
  }

  // 标记是否需要重新创建并启动会话.
  // 当需要重启会话的时候, 我们需要重新初始化Loader并创建XrInstance以及会话。
  // 为什么需要这么做呢?
  // 根据openxr spec文档描述(https://registry.khronos.org/OpenXR/specs/1.0/html/xrspec.html#instancelosspending-description)
  // 我们在收到XR_SESSION_STATE_LOSS_PENDING消息的时候,
  // Runtime无法再和我们的会话进行交互，此时我们需要销毁会话并重新创建。
  // 我们在收到XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING消息的时候，意味着应用程序的XrInstance无法再使用，需要销毁该实例等可用时再重新创建。
  // 我们在收到XR_SESSION_STATE_EXITING消息的时候，意味着用户在退出应用程序，此时我们需要直接退出。
  // 该标记用于记录我们是否需要重新创建并启动OpenXR的一系列对象，当值为false时意味着程序需要退出，我们需要把进程中所有对象都清除并退出。
  bool requestRestart = false;
  // 标记是否需要退出渲染循环。
  // 什么时候需要退出渲染循环呢?
  // 根据openxr spec文档描述，应用程序在收到XR_SESSION_STATE_STOPPING消息时，
  // 意味着Runtime需要应用程序停止Frame Loop并调用xrEndSession终止会话。
  // 该消息在系统认为资源不足时会发给应用程序，可以类比Android App中的Activity靠在后台时被系统销毁的场景。
  bool exitRenderLoop = false;
  while (true) {
    LogI("Session Loop start");
    initLoader(vm, activityJavaObj);
    xrProgram->CreateInstance();
    xrProgram->InitSystem();
    xrProgram->InitSession();

    while (app->destroyRequested == 0) {
      for (;;) {
        void *source;
        int identifier = ALooper_pollAll(0, nullptr, nullptr, &source);
        if (identifier < 0) {
          break;
        }
        if (identifier == LOOPER_ID_USER) {
          Cmd cmd = read_cmd();
          xrProgram->HandleMessage(cmd.type, cmd.message);
          break;
        }

        // 处理android_native_app_glue中往队列塞入的事件, 这些事件包括Activity的生命周期回调事件
        // 这段代码是android_native_app_glue的要求，目的是让其有一个时机处理相关事件。
        // identifier == LOOPER_ID_MAIN || LOOPER_ID_INPUT
        if (source != nullptr) {
          auto androidPollSource = (struct android_poll_source *)source;
          androidPollSource->process(app, androidPollSource);
        }
      }
      // 先等待Java层下发初始化命令再启动我们的xr程序
      // 原因是xr程序的运行依赖于Java层的某些信息(例如渲染本地视图时需要Java层告知渲染资源的路径)
      if (!xrProgram->IsInitializationStart()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
        continue;
      }

      xrProgram->PollEvents(&exitRenderLoop, &requestRestart);

      // 会话还没有Ready时不需要进行渲染
      if (!xrProgram->IsSessionRunning()) {
        pauseRequesting();
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
        continue;
      }
      resumeRequesting();
      if (exitRenderLoop) {
        LogD("Exit render loop.");
        break;
      }
      xrProgram->RenderFrame();
    }
    LogI("Render Loop finished, restart:%d", requestRestart);
    if (!requestRestart) {
      xrProgram->Destroy();
      break;
    }
  }
}

/**
 * 这个函数是程序入口。
 * 我们使用了ndk的代码android_native_app_glue，它会在加载so时启动一个线程，并在线程中调用这个函数。
 * 这个线程拥有自己的native event loop，通过这个event loop我们的程序能够触发和接收输入事件。
 */
void android_main(struct android_app *app) {
  // 初始化jnipp
  jni::init(app->activity->vm);

  // 初始化Jni层的TcrActivity
  auto activityJavaObj = app->activity->clazz;
  wrap::tcr::xr::TcrActivity::staticInitClass(jni::env()->GetObjectClass(activityJavaObj));
  std::shared_ptr<wrap::tcr::xr::TcrActivity> tcrActivity =
      std::make_shared<wrap::tcr::xr::TcrActivity>(jni::jobject(activityJavaObj));

  // 从TcrActivity拿到ClassLoader以便jnipp能够找到APK中的类(JNI默认的ClassLoader不包含APK的路径)
  jni::initJavaClassLoader(tcrActivity->getClassLoader().object());

  std::shared_ptr<PlatformData> data = std::make_shared<PlatformData>();
  data->applicationVM = app->activity->vm;
  data->applicationActivity = activityJavaObj;

  g_ctx.streamReady = false;
  g_ctx.xrProgram = CreateOpenXrProgram(data, tcrActivity);
  entry(app, app->activity->vm, activityJavaObj, g_ctx.xrProgram);
  g_ctx.xrProgram.reset();
  app->activity->vm->DetachCurrentThread();
  LogD("android_main end");
}

inline std::string JString2String(JNIEnv *env, jstring java_str) {
  if (!java_str) return "";
  const char *c_str = env->GetStringUTFChars(java_str, nullptr);
  std::string cpp_str = std::string(c_str);
  env->ReleaseStringUTFChars(java_str, c_str);
  return cpp_str;
}

extern "C" {
JNIEXPORT void JNICALL Java_com_tencent_tcr_demo_gameplay_XrActivity_nativeSetMessage(JNIEnv *env, jobject, jstring j_string_type,
                                                                                      jstring j_string_message) {
  Cmd cmd{JString2String(env, j_string_type), JString2String(env, j_string_message)};
  write_cmd(cmd);
}

JNIEXPORT void JNICALL Java_com_tencent_tcr_demo_gameplay_XrActivity_nativeRequestTrackingInfo__(JNIEnv *env, jobject) {
  std::lock_guard<std::mutex> lock(g_ctx.requestingMtx);
  if (!g_ctx.requestingTrackingInfo) {
    return;
  }
  const std::shared_ptr<IOpenXrProgram> xrProgram = g_ctx.xrProgram;
  if (xrProgram) {
    xrProgram->UpdateVrInfo();
  }
}

JNIEXPORT void JNICALL Java_com_tencent_tcr_demo_gameplay_XrActivity_nativeSetVideoFrame(JNIEnv *env, jobject, jobject j_frame) {
  const std::shared_ptr<IOpenXrProgram> xrProgram = g_ctx.xrProgram;
  if (!xrProgram) {
    LogW("nativeSetVideoFrame() !xrProgram");
    return;
  }
  wrap::tcr::xr::VideoFrame frame = wrap::tcr::xr::VideoFrame(j_frame);

  // 开始处理视频流
  if (!g_ctx.streamReady) {
    g_ctx.streamReady = true;
    Json::StreamWriterBuilder jsonBuilder;
    Json::Value value;
    value["width"] = frame.getWidth();
    value["height"] = frame.getHeight();
    write_cmd(Cmd{"stream_ready", Json::writeString(jsonBuilder, value)});
  }
  // 把视频帧存起来
  xrProgram->SetVideoFrame(std::move(frame));
}
}
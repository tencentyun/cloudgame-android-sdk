#pragma once
#ifndef TCR_INTERACTION_PROFILES_H
#  define TCR_INTERACTION_PROFILES_H

#  include <array>
#  include <cstdint>
#  include <optional>
#  include "pch.h"
#  include "xrpaths.h"

namespace Tcr {

using Path = std::string;
using ComponentPaths = std::vector<const Path>;

constexpr inline const std::size_t HandSize = 2;
using HandPaths = std::array<const ComponentPaths, HandSize>;
using HandPathList = std::array<const char* const, HandSize>;

inline const Path EmptyPath{""};
inline const ComponentPaths EmptyPaths{EmptyPath};
inline const HandPaths EmptyHandMap{EmptyPaths, EmptyPaths};
constexpr inline const HandPathList UserHandPaths{XRPaths::UserHandLeft, XRPaths::UserHandRight};
struct InteractionProfile {
  const HandPaths boolPaths = EmptyHandMap;
  const HandPaths scalarPaths = EmptyHandMap;
  const HandPaths vector2fPaths = EmptyHandMap;
  const char* const path;
  const char* const extensionName = nullptr;
  const char* const aimPosePath = XRPaths::AimPose;
  const char* const gripPosePath = XRPaths::GripPose;
  const HandPathList userHandPaths = UserHandPaths;

  constexpr inline bool IsCore() const { return extensionName == nullptr; }
  constexpr inline bool IsExt() const { return !IsCore(); }
};

using namespace XRPaths;
constexpr inline const std::size_t ProfileMapSize = 2;
inline const std::array<const InteractionProfile, ProfileMapSize> InteractionProfileMap{
    InteractionProfile{
        .boolPaths =
            {
                ComponentPaths{
                    BackClick,
                    SqueezeClick,
                    XClick,
                    XTouch,
                    YClick,
                    YTouch,
                    ThumbstickClick,
                    ThumbstickTouch,
                    TriggerClick,
                    TriggerTouch,
                    ThumbrestTouch,
                },
                ComponentPaths{
                    BackClick,
                    SqueezeClick,
                    AClick,
                    ATouch,
                    BClick,
                    BTouch,
                    ThumbstickClick,
                    ThumbstickTouch,
                    TriggerClick,
                    TriggerTouch,
                    ThumbrestTouch,
                },
            },
        .scalarPaths = {ComponentPaths{
                            SqueezeValue,
                            TriggerValue,
                        },
                        ComponentPaths{
                            SqueezeValue,
                            TriggerValue,
                        }},
        .vector2fPaths = {ComponentPaths{
                              ThumbstickPos,
                          },
                          ComponentPaths{
                              ThumbstickPos,
                          }},
        .path = "/interaction_profiles/pico/neo3_controller",
        .extensionName = "XR_PICO_android_controller_function_ext_enable",
    },
    InteractionProfile{
        .boolPaths =
            {
                ComponentPaths{
                    MenuClick,
                    XClick,
                    XTouch,
                    YClick,
                    YTouch,
                    ThumbstickClick,
                    ThumbstickTouch,
                    TriggerTouch,
                    ThumbrestTouch,
                },
                ComponentPaths{
                    SystemClick,
                    AClick,
                    ATouch,
                    BClick,
                    BTouch,
                    ThumbstickClick,
                    ThumbstickTouch,
                    TriggerTouch,
                    ThumbrestTouch,
                },
            },
        .scalarPaths = {ComponentPaths{
                            SqueezeValue,
                            ThumbstickX,
                            ThumbstickY,
                            TriggerValue,
                        },
                        ComponentPaths{
                            SqueezeValue,
                            ThumbstickX,
                            ThumbstickY,
                            TriggerValue,
                        }},
        .path = "/interaction_profiles/oculus/touch_controller",
    }};
}  // namespace Tcr

#endif  // TCR_INTERACTION_PROFILES_H
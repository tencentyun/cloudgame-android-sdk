// Copyright (c) 2017-2022, The Khronos Group Inc.
//
// SPDX-License-Identifier: Apache-2.0

#include "openxr_program.h"
#include <GLES3/gl3.h>
#include <jni_wrap/com.tencent.tcr.xr.text_bitmap.h>
#include <jnipp.h>
#include <unistd.h>
#include <array>
#include <cmath>
#include <fstream>
#include <thread>
#include <atomic>
#include <glm/gtx/transform.hpp>
#include <numeric>
#include <shared_mutex>
#include <unordered_map>
#include "gfxwrapper/gfxwrapper_opengl.h"
#include "graphics/graphics.h"
#include "interaction_manager.h"
#include "interaction_profiles.h"
#include "json/json.h"
#include "openxr_wrapper.h"
#include "xr_utils.h"

namespace {

// 用于统计平均总延迟(总延迟指从位姿发送后到对应画面被渲染的时长，即整个链路的耗时)，以便我们来预测头显位姿。
// 该类的设计了一个滑动窗口，总是记录一系列最新的总延迟，最新的总延迟在尾部插入，当延迟记录达到窗口大小时会将最旧的延迟移除。
class LatencySlidingWindow {
  // 计算平局总延迟的滑动窗口大小.
  // 网络本身会波动，一小段时间内的网络延迟大致一致，因此该值不宜过大也不宜太小.
  static constexpr const std::size_t SlidingWindowSize = 256;

 public:
  // 提交总延迟。
  // 该值会被塞到窗口尾部，当窗口达到上限时会将最早的一个总延迟删除。
  void SubmitLatency(const XrDuration& totalLatency) {
    assert(totalLatency > 0);
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_historyBuffer.size() >= SlidingWindowSize) {
      m_historyBuffer.pop_front();
    }
    m_historyBuffer.push_back(totalLatency);
  }

  // 返回窗口中所有延迟的平均值。
  XrDuration GetAverage() {
    std::lock_guard<std::mutex> lock(m_mutex);
    XrDuration sum = std::accumulate(m_historyBuffer.begin(), m_historyBuffer.end(), 0LL);
    return sum / (int64_t)m_historyBuffer.size();
  }

 private:
  // 我们使用队列来实现滑动窗口。
  // 每插入一个元素时判断元素总数，当超过historySize时移除队头元素以实现窗口滑动效果。
  std::deque<XrDuration> m_historyBuffer;
  std::mutex m_mutex;
};

struct OpenXrProgram : IOpenXrProgram {
  OpenXrProgram(const std::shared_ptr<PlatformData>& platformData,
                const std::shared_ptr<wrap::tcr::xr::TcrActivity>& tcrActivity)
      : m_platformData(platformData), m_tcrActivity(tcrActivity) {}

  ~OpenXrProgram() override {
    LogD("~OpenXrProgram()");
    destroyGraphicsNative();
  }

  void Destroy() override {
    LogD("OpenXrProgram Destroy");

    m_interactionManager.reset();

    if (m_appSpace != XR_NULL_HANDLE) {
      xrDestroySpace(m_appSpace);
      m_appSpace = XR_NULL_HANDLE;
    }
    if (m_session != XR_NULL_HANDLE) {
      xrDestroySession(m_session);
      m_session = XR_NULL_HANDLE;
    }

    if (m_instance != XR_NULL_HANDLE) {
      xrDestroyInstance(m_instance);
      m_instance = XR_NULL_HANDLE;
    }
    ksGpuWindow_Destroy(&window);
  }

  using ExtensionMap = std::unordered_map<std::string_view, bool>;
  ExtensionMap m_availableSupportedExtMap = {{XR_EXT_PERFORMANCE_SETTINGS_EXTENSION_NAME, false},
                                             {XR_KHR_CONVERT_TIMESPEC_TIME_EXTENSION_NAME, false},
                                             {XR_FB_COLOR_SPACE_EXTENSION_NAME, false},
                                             {"XR_PICO_android_controller_function_ext_enable", false}};

  void EnumerateLayersAndExtensions() {
    // 查询支持的所有扩展
    auto extensions = EnumerateExtensions(nullptr);
    LogD(" Available Extensions: (%zu)", extensions.size());
    for (auto&& extension : extensions) {
      const auto itr = m_availableSupportedExtMap.find(extension.extensionName);
      bool enable = itr != m_availableSupportedExtMap.end();
      if (enable) {
        itr->second = true;
      }
      LogD("   Name=%s SpecVersion=%d %s", extension.extensionName, extension.extensionVersion, enable ? "enable" : "");
    }

    // 查询所有支持的Layer以及它们的扩展
    auto layers = EnumerateLayers();
    LogD("Available Layers: (%zu)", layers.size());
    for (const XrApiLayerProperties& layer : layers) {
      LogV("  Name=%s SpecVersion=%s LayerVersion=%d Description=%s", layer.layerName,
           Tcr::GetXrVersionString(layer.specVersion).c_str(), layer.layerVersion, layer.description);
      EnumerateExtensions(layer.layerName);
    }
  }

  void CreateInstanceInternal() {
    CHECK(m_instance == XR_NULL_HANDLE);

    // 需要启用的扩展功能
    std::vector<const char*> extensions;
    for (const auto& [extName, extAvailable] : m_availableSupportedExtMap) {
      if (extAvailable) {
        extensions.push_back(extName.data());
      }
    }

    XrInstanceCreateInfoAndroidKHR instanceCreate{.type = XR_TYPE_INSTANCE_CREATE_INFO_ANDROID_KHR,
                                                  .next = XR_NULL_HANDLE,
                                                  .applicationVM = m_platformData->applicationVM,
                                                  .applicationActivity = m_platformData->applicationActivity};

    // 平台扩展: 我们仅运行在Android平台上
    extensions.push_back(XR_KHR_ANDROID_CREATE_INSTANCE_EXTENSION_NAME);

    // 图像API扩展: 我们使用OpenGLES进行绘制
    extensions.push_back(XR_KHR_OPENGL_ES_ENABLE_EXTENSION_NAME);

    XrInstanceCreateInfo createInfo{XR_TYPE_INSTANCE_CREATE_INFO};
    createInfo.next = &instanceCreate;
    createInfo.enabledExtensionCount = (uint32_t)extensions.size();
    createInfo.enabledExtensionNames = extensions.data();

    strcpy(createInfo.applicationInfo.applicationName, "TcrXr");
    createInfo.applicationInfo.apiVersion = XR_CURRENT_API_VERSION;

    CHECK_XRCMD(xrCreateInstance(&createInfo, &m_instance));
  }

  void CreateInstance() override {
    EnumerateLayersAndExtensions();
    CreateInstanceInternal();
    LogInstanceInfo(m_instance);
  }

  void InitEGL(uint64_t glSharedContext) {
    LogD("Initialize glSharedContext:%" PRIu64 "", glSharedContext);

    // Extension function must be loaded by name
    PFN_xrGetOpenGLESGraphicsRequirementsKHR pfnGetOpenGLESGraphicsRequirementsKHR = nullptr;
    CHECK_XRCMD(xrGetInstanceProcAddr(m_instance, "xrGetOpenGLESGraphicsRequirementsKHR",
                                      reinterpret_cast<PFN_xrVoidFunction*>(&pfnGetOpenGLESGraphicsRequirementsKHR)));

    XrGraphicsRequirementsOpenGLESKHR graphicsRequirements{XR_TYPE_GRAPHICS_REQUIREMENTS_OPENGL_ES_KHR};
    CHECK_XRCMD(pfnGetOpenGLESGraphicsRequirementsKHR(m_instance, m_systemId, &graphicsRequirements));

    // Initialize the gl extensions. Note we have to open a window.
    ksDriverInstance driverInstance{};
    ksGpuQueueInfo queueInfo{};
    ksGpuSurfaceColorFormat colorFormat{KS_GPU_SURFACE_COLOR_FORMAT_B8G8R8A8};
    ksGpuSurfaceDepthFormat depthFormat{KS_GPU_SURFACE_DEPTH_FORMAT_D24};
    ksGpuSampleCount sampleCount{KS_GPU_SAMPLE_COUNT_1};
    if (!ksGpuWindow_Create(&window, &driverInstance, &queueInfo, 0, colorFormat, depthFormat, sampleCount, 640, 480,
                            false, reinterpret_cast<EGLContext>(glSharedContext))) {
      THROW("Unable to create GL context");
    }

    GLint major = 0;
    GLint minor = 0;
    glGetIntegerv(GL_MAJOR_VERSION, &major);
    glGetIntegerv(GL_MINOR_VERSION, &minor);

    const XrVersion desiredApiVersion = XR_MAKE_VERSION(major, minor, 0);
    if (graphicsRequirements.minApiVersionSupported > desiredApiVersion) {
      THROW("Runtime does not support desired Graphics API and/or version");
    }

    m_graphicsBinding.display = window.display;
    m_graphicsBinding.config = (EGLConfig)0;
    m_graphicsBinding.context = window.context.context;
    glEnable(GL_DEBUG_OUTPUT);
    glDebugMessageCallback(
        [](GLenum source, GLenum type, GLuint id, GLenum severity, GLsizei length, const GLchar* message,
           const void* userParam) { LogV("GLES Debug: %s", std::string(message, 0, length).c_str()); },
        nullptr);
  }

  void InitSystem() override {
    CHECK(m_instance != XR_NULL_HANDLE);
    CHECK(m_systemId == XR_NULL_SYSTEM_ID);

    XrSystemGetInfo systemInfo{XR_TYPE_SYSTEM_GET_INFO};
    systemInfo.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    CHECK_XRCMD(xrGetSystem(m_instance, &systemInfo, &m_systemId));

    LogI("Using system %d for form factor %s", m_systemId, to_string(XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY));
    CHECK(m_instance != XR_NULL_HANDLE);
    CHECK(m_systemId != XR_NULL_SYSTEM_ID);

    LogViewConfigurations(m_instance, m_systemId);

    uint64_t glSharedContext = m_tcrActivity->getGLSharedContext();
    // The graphics API can initialize the graphics device now that the systemId and instance
    // handle are available.
    InitEGL(glSharedContext);
    m_streamReady = false;
  }

  void InitActions() {
    const auto IsProfileSupported = [this](const auto& profile) {
      return profile.IsCore() || IsExtEnabled(profile.extensionName);
    };
    m_interactionManager = std::make_unique<Tcr::InteractionManager>(m_instance, m_session, IsProfileSupported);
  }

  void InitJsonWriter() override {
    m_jsonBuilder.settings_["precision"] = 6;
    m_jsonBuilder.settings_["precisionType"] = "decimal";
  }

  void StartInitialize(std::string xrAssetsPath) {
    initGraphicsNative(xrAssetsPath);
    m_initializationStart = true;
    LogI("StartInitialize()");
  }

  void HandleMessage(std::string type, std::string msg) override {
    if (type == "update_lobby_text") {
      LogI("update_lobby_text msg:%s", msg.c_str());
      auto directBuffer = jni::env()->GetDirectBufferAddress(wrap::tcr::xr::TextBitmap::getByteBuffer(msg).getHandle());
      CHECK(directBuffer);
      UpdateLobbyText(static_cast<uint8_t*>(directBuffer));
    } else {
      Json::Reader reader;
      Json::Value value;
      if (!reader.parse(msg, value)) {
        LogW("parse value failed type:%s value:%s", type.c_str(), msg.c_str());
        return;
      }

      if (type == "start_init") {
        StartInitialize(value["xr_assets_path"].asString());
      } else if (type == "stream_ready") {
        OnStreamReady(value["width"].asInt(), value["height"].asInt());
      }
    }
  }

  void InitSession() override {
    CHECK(m_instance != XR_NULL_HANDLE);
    CHECK(m_session == XR_NULL_HANDLE);

    CreateSession(m_instance, m_systemId, &m_session, reinterpret_cast<const XrBaseInStructure*>(&m_graphicsBinding));
    InitJsonWriter();
    LogReferenceSpaces(m_session);
    InitActions();
    InitExtensions();
    CreateReferenceSpace(m_session, XR_REFERENCE_SPACE_TYPE_STAGE, &m_appSpace);
    InitViews();
    CheckSwapChainFormat();
    LogSystemProperties(m_instance, m_systemId);
  }

  inline void InitViews() {
    CHECK(m_configViews.empty());
    m_configViews = std::move(EnumerateViewConfigurationViews(m_instance, m_systemId));
    m_views.resize(m_configViews.size(), {XR_TYPE_VIEW});
  }

  // 目前服务端只会给我们推送SRGB这一种颜色格式。
  // 如果未来有多种情况，我们再针对不同情况进行处理，这里检查系统是否支持目前选中的格式。
  inline void CheckSwapChainFormat() {
    auto swapChainFormats = EnumerateSwapChainFormats(m_session);
    CHECK_MSG(
        std::find(swapChainFormats.begin(), swapChainFormats.end(), m_colorSwapchainFormat) != swapChainFormats.end(),
        Fmt("not support color format:%x", m_colorSwapchainFormat))
  }

  inline void NotifyEvent(const std::string& event, const std::string& msg) {
    const bool ready = m_isXrInitNotified.load();
    if (!ready) {
      LogW("NotifyEvent() !ready event:%s", event.c_str());
      return;
    }
    m_tcrActivity->onEvent(event, msg);
  }

  // 返回下一个事件或者nullptr
  const XrEventDataBaseHeader* TryReadNextEvent() {
    // 获取新事件前先清空缓冲区
    auto baseHeader = reinterpret_cast<XrEventDataBaseHeader*>(&m_eventDataBuffer);
    *baseHeader = {XR_TYPE_EVENT_DATA_BUFFER};
    const XrResult xr = xrPollEvent(m_instance, &m_eventDataBuffer);
    if (xr == XR_SUCCESS) {
      if (baseHeader->type == XR_TYPE_EVENT_DATA_EVENTS_LOST) {
        const auto* const eventsLost = reinterpret_cast<const XrEventDataEventsLost*>(baseHeader);
        LogW("%" PRIu32 " events lost", eventsLost->lostEventCount);
      }
      return baseHeader;
    }
    if (xr == XR_EVENT_UNAVAILABLE) {
      return nullptr;
    }
    THROW_XR(xr, "xrPollEvent");
  }

  inline void NotifyXrInit() {
    if (!m_isXrInitNotified.load()) {
      LogI("NotifyXrInit");
      m_isXrInitNotified.store(true);

      auto eyeInfo = GetEyeInfo(XrTimeNow());
      CHECK(!eyeInfo.empty());

      Tcr::XrInitInfo info{};
      info.eyeInfo = eyeInfo;
      NotifyEvent("xr_init_finish", Json::writeString(m_jsonBuilder, Tcr::toJson(info)));
    }
  }

  void PollEvents(bool* exitRenderLoop, bool* requestRestart) override {
    *exitRenderLoop = *requestRestart = false;
    while (const XrEventDataBaseHeader* event = TryReadNextEvent()) {
      switch (event->type) {
        case XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING: {
          const auto& instanceLossPending = *reinterpret_cast<const XrEventDataInstanceLossPending*>(event);
          LogW("XrEventDataInstanceLossPending by %lld", instanceLossPending.lossTime);
          *exitRenderLoop = true;
          *requestRestart = false;
          return;
        }
        case XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED: {  // 会话状态变化
          auto sessionStateChangedEvent = *reinterpret_cast<const XrEventDataSessionStateChanged*>(event);
          HandleSessionStateChangedEvent(sessionStateChangedEvent, exitRenderLoop, requestRestart);
          break;
        }
        case XR_TYPE_EVENT_DATA_INTERACTION_PROFILE_CHANGED:  // 交互配置文件变更
          m_interactionManager->SetActiveFromCurrentProfile();
          m_interactionManager->LogActions();
          break;
        case XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING:
        default: {
          LogV("Ignoring event type %d", event->type);
          break;
        }
      }
    }
  }

  void HandleSessionStateChangedEvent(const XrEventDataSessionStateChanged& stateChangedEvent, bool* exitRenderLoop,
                                      bool* requestRestart) {
    const XrSessionState oldState = m_sessionState;
    m_sessionState = stateChangedEvent.state;

    LogI("XrEventDataSessionStateChanged: state %s->%s session=%lld time=%lld", to_string(oldState),
         to_string(m_sessionState), stateChangedEvent.session, stateChangedEvent.time);

    if ((stateChangedEvent.session != XR_NULL_HANDLE) && (stateChangedEvent.session != m_session)) {
      LogE("XrEventDataSessionStateChanged for unknown session");
      return;
    }

    switch (m_sessionState) {
      case XR_SESSION_STATE_READY: {
        CHECK(m_session != XR_NULL_HANDLE);
        BeginSession(m_session);
        m_sessionRunning = true;
        SetPerformanceLevels();
        const uint32_t recommendedWidth = m_configViews[0].recommendedImageRectWidth;
        const uint32_t recommendedHeight = m_configViews[0].recommendedImageRectHeight;
        m_lobbySwapChains = {
            CreateSwapchainRect(m_session, recommendedWidth, recommendedHeight, m_colorSwapchainFormat),
            CreateSwapchainRect(m_session, recommendedWidth, recommendedHeight, m_colorSwapchainFormat)};

        prepareLobbyRoom(recommendedWidth, recommendedHeight,
                         {EnumerateSwapchainImages(m_lobbySwapChains[0].swapchain),
                          EnumerateSwapchainImages(m_lobbySwapChains[1].swapchain)});
        NotifyEvent("xr_resume_streaming", "");
        break;
      }
      case XR_SESSION_STATE_FOCUSED:
        NotifyXrInit();
        break;
      case XR_SESSION_STATE_STOPPING: {
        CHECK(m_session != XR_NULL_HANDLE);
        NotifyEvent("xr_pause_streaming", "");
        m_sessionRunning = false;
        destroyRenderers();
        CHECK_XRCMD(xrEndSession(m_session))
        DestroySwapchain(m_lobbySwapChains[0]);
        DestroySwapchain(m_lobbySwapChains[1]);
        m_lobbySwapChains = {};
        DestroySwapchain(m_streamSwapChains[0]);
        DestroySwapchain(m_streamSwapChains[1]);
        m_streamSwapChains = {};
        m_VideoFrame.reset();
        m_streamReady = false;
      } break;
      case XR_SESSION_STATE_EXITING: {
        m_isXrInitNotified.store(false);
        *exitRenderLoop = true;
        *requestRestart = false;
        break;
      }
      case XR_SESSION_STATE_LOSS_PENDING: {
        *exitRenderLoop = true;
        *requestRestart = true;
        break;
      }
      default:
        break;
    }
  }

  bool IsSessionRunning() const override { return m_sessionRunning; }

  bool IsSessionFocused() const override { return m_sessionState == XR_SESSION_STATE_FOCUSED; }

  bool IsInitializationStart() const override { return m_initializationStart; }

  inline Json::Value GetControllerEvents() {
    Json::Value events;
    if (!m_interactionManager) {
      LogW("PollHandActions() !m_interactionManager");
      return events;
    }
    events = m_interactionManager->PollActions(m_appSpace, XrTimeNow());
    return events;
  }

  inline bool IsExtEnabled(const std::string_view& extName) const {
    auto ext_itr = m_availableSupportedExtMap.find(extName);
    return ext_itr != m_availableSupportedExtMap.end() && ext_itr->second;
  }

  void InitExtensions() override {
    if (IsExtEnabled(XR_KHR_CONVERT_TIMESPEC_TIME_EXTENSION_NAME)) {
      LogI("%s enabled.", XR_KHR_CONVERT_TIMESPEC_TIME_EXTENSION_NAME);
      CHECK_XRCMD(xrGetInstanceProcAddr(m_instance, "xrConvertTimespecTimeToTimeKHR",
                                        reinterpret_cast<PFN_xrVoidFunction*>(&m_pfnConvertTimespecTimeToTimeKHR)));
    }
    if (IsExtEnabled(XR_FB_COLOR_SPACE_EXTENSION_NAME)) {
      LogI("%s enabled.", XR_FB_COLOR_SPACE_EXTENSION_NAME);
      CHECK_XRCMD(xrGetInstanceProcAddr(m_instance, "xrEnumerateColorSpacesFB",
                                        reinterpret_cast<PFN_xrVoidFunction*>(&m_pfnEnumerateColorSpacesFB)));
      CHECK_XRCMD(xrGetInstanceProcAddr(m_instance, "xrSetColorSpaceFB",
                                        reinterpret_cast<PFN_xrVoidFunction*>(&m_pfnSetColorSpaceFB)));
    }
    SetDeviceColorSpace();
  }

  bool SetDeviceColorSpace() {
    if (m_pfnSetColorSpaceFB == nullptr) return false;

    const XrColorSpaceFB selectedColorSpace = XR_COLOR_SPACE_REC2020_FB;
    const auto colorSpaceName = Tcr::ColorSpace::to_string(selectedColorSpace);

    if (m_pfnSetColorSpaceFB(m_session, selectedColorSpace) != XR_SUCCESS) {
      LogI("Failed to set color space to \"%s\"", colorSpaceName);
      return false;
    }
    LogI("Set color space to \"%s\"", colorSpaceName);
    return true;
  }

  virtual inline XrTime XrTimeNow() const {
    if (!m_pfnConvertTimespecTimeToTimeKHR) return -1;
    struct timespec ts {};
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return -1;
    XrTime xrTimeNow;
    return m_pfnConvertTimespecTimeToTimeKHR(m_instance, &ts, &xrTimeNow) == XR_ERROR_TIME_INVALID ? -1 : xrTimeNow;
  }

  static constexpr inline const XrView IdentityView{
      .type = XR_TYPE_VIEW, .next = nullptr, .pose = Tcr::Pose::Identity, .fov = {0, 0, 0, 0}};

  void SetPerformanceLevels() {
    if (IsExtEnabled(XR_EXT_PERFORMANCE_SETTINGS_EXTENSION_NAME)) {
      PFN_xrPerfSettingsSetPerformanceLevelEXT setPerfLevel = nullptr;
      CHECK_XRCMD(xrGetInstanceProcAddr(m_instance, "xrPerfSettingsSetPerformanceLevelEXT",
                                        reinterpret_cast<PFN_xrVoidFunction*>(&setPerfLevel)));
      CHECK(setPerfLevel != nullptr);
      CHECK_XRCMD(setPerfLevel(m_session, XR_PERF_SETTINGS_DOMAIN_CPU_EXT, XR_PERF_SETTINGS_LEVEL_SUSTAINED_HIGH_EXT));
      CHECK_XRCMD(setPerfLevel(m_session, XR_PERF_SETTINGS_DOMAIN_GPU_EXT, XR_PERF_SETTINGS_LEVEL_BOOST_EXT));
    }
  }

  static inline Tcr::EyeInfo GetEyeInfo(const XrView& left_view, const XrView& right_view) {
    float ipd = std::fabs(
        glm::length(glm::vec3(right_view.pose.position.x, right_view.pose.position.y, right_view.pose.position.z) -
                    glm::vec3(left_view.pose.position.x, left_view.pose.position.y, left_view.pose.position.z)));
    if (ipd < 0.00001f) ipd = 0.063f;

    return Tcr::EyeInfo{.eyeFov = {left_view.fov, right_view.fov}, .ipd = ipd};
  }

  virtual inline Tcr::EyeInfo GetEyeInfo(const XrTime& time) {
    std::array<XrView, 2> newViews{IdentityView, IdentityView};
    LocateViews(m_session, m_appSpace, time, static_cast<const std::uint32_t>(newViews.size()), newViews.data());
    return GetEyeInfo(newViews[0], newViews[1]);
  }

  virtual void UpdateLobbyText(const unsigned char* data) override { updateLobbyHudTexture(data); }

  void OnStreamReady(int32_t width, int32_t height) override {
    width = width / 2;
    height = height;
    LogW("create swapchain stream Width = %d, height = %d", width, height);
    m_streamSwapChains = {CreateSwapchainRect(m_session, width, height, m_colorSwapchainFormat),
                          CreateSwapchainRect(m_session, width, height, m_colorSwapchainFormat)};
    streamStartNative({static_cast<unsigned int>(width),
                       static_cast<unsigned int>(height),
                       {EnumerateSwapchainImages(m_streamSwapChains[0].swapchain),
                        EnumerateSwapchainImages(m_streamSwapChains[1].swapchain)}});
    m_streamReady = true;
  }

  // 双眼瞳距
  inline float GetIpd() {
    auto eyeInfo = GetEyeInfo(XrTimeNow());
    if (eyeInfo.empty()) {
      LogW("GetIpd() eyeInfo.empty");
      return 0;
    }
    return eyeInfo.ipd;
  }

  void UpdateVrInfo() override {
    const auto sessionRunning = IsSessionRunning();
    if (!sessionRunning) {
      LogW("UpdateVrInfo() !sessionRunning");
      return;
    }

    auto xrViews = GetHmdTrackingInfo();
    float ipd = GetIpd();

    if (xrViews.isNull() || ipd < 0.00001) {
      LogW("UpdateVrInfo() vrInfo not valid!!");
      return;
    }
    Json::Value result;
    result["xrViewsJsonString"] = Json::writeString(m_jsonBuilder, xrViews);
    result["ipd"] = ipd;
    NotifyEvent("xr_info_update", Json::writeString(m_jsonBuilder, result));

    auto now = std::chrono::steady_clock::now();
    auto elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(now - m_lastUpdateTime).count();
    if (elapsed_time >= 15) {
      NotifyEvent("xr_ctrl_events_update", Json::writeString(m_jsonBuilder, GetControllerEvents()));
      m_lastUpdateTime = now;
    }
  }

  void SetVideoFrame(wrap::tcr::xr::VideoFrame&& videoFrame) override {
    std::lock_guard<std::mutex> lock(m_VideoFrameMutex);
    // drop old frame
    if (m_VideoFrame) {
      m_VideoFrame->release();
    }
    m_VideoFrame = std::make_unique<wrap::tcr::xr::VideoFrame>(std::move(videoFrame));
    m_VideoFrame->retain();
  }

  Json::Value GetHmdTrackingInfo() override {
    Json::Value result;
    const auto now = XrTimeNow();
    const auto targetTimestamp = now + m_latencyAverage.GetAverage();

    std::array<XrView, 2> newViews{IdentityView, IdentityView};
    // 当前这个函数在异步线程调用，有可能会调用失败，因为在异步线程调用该函数,
    if (!LocateViews(m_session, m_appSpace, targetTimestamp, (const std::uint32_t)newViews.size(), newViews.data())) {
      return result;
    }
    result = Tcr::toJson(newViews, targetTimestamp);
    return result;
  }

  void RenderStreamFrame(const XrFrameState& frameState, std::array<SwapchainRect, 2> swapChains,
                         const std::unique_ptr<wrap::tcr::xr::VideoFrame>&& videoFrame) {
    std::string xrViewsJson = videoFrame->getAssociateData();
    std::array<XrView, 2> newViews{IdentityView, IdentityView};
    int64_t targetTimestamp;
    if (!Tcr::fromJson(newViews, targetTimestamp, xrViewsJson)) {
      LogE("RenderStreamFrame() fromJson failed:%s", xrViewsJson.c_str());
      return;
    }
    uint32_t leftSwapchainIdx = AcquireSwapchianImage(swapChains[0].swapchain);
    uint32_t rightSwapchainIdx = AcquireSwapchianImage(swapChains[1].swapchain);

    WaitSwapchainImage(swapChains[0].swapchain);
    WaitSwapchainImage(swapChains[1].swapchain);
    renderStreamNative(videoFrame->updateTexture(), {leftSwapchainIdx, rightSwapchainIdx});
    ReleaseSwapchainImage(swapChains[0].swapchain);
    ReleaseSwapchainImage(swapChains[1].swapchain);
    const auto now = XrTimeNow();
    // 距离提交到渲染的时长
    auto vsyncDuration = frameState.predictedDisplayTime - now;
    // 计算着一帧画面从触发到渲染的总延迟
    XrDuration totalLatency = videoFrame->getLatency() + vsyncDuration;
    if (totalLatency > 0) {
      m_latencyAverage.SubmitLatency(totalLatency);
    }
    auto lFov = videoFrame->getLeftFov();
    auto rFov = videoFrame->getRightFov();
    EndFrame(m_session, m_appSpace, targetTimestamp,
             {{{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW, XR_NULL_HANDLE, newViews[0].pose,
                XrFovf{lFov.getLeft(), lFov.getRight(), lFov.getTop(), lFov.getBottom()},
                XrSwapchainSubImage{swapChains[0].swapchain, swapChains[0].rect}},
               {XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW, XR_NULL_HANDLE, newViews[1].pose,
                XrFovf{rFov.getLeft(), rFov.getRight(), rFov.getTop(), rFov.getBottom()},
                XrSwapchainSubImage{swapChains[1].swapchain, swapChains[1].rect}}}});
    videoFrame->release();
  }

  void RenderLobbyFrame(XrFrameState frameState, std::array<SwapchainRect, 2> swapchains) {
    uint32_t leftSwapchainIdx = AcquireSwapchianImage(swapchains[0].swapchain);
    uint32_t rightSwapchainIdx = AcquireSwapchianImage(swapchains[1].swapchain);
    WaitSwapchainImage(swapchains[0].swapchain);
    WaitSwapchainImage(swapchains[1].swapchain);

    XrTime displayTime = frameState.predictedDisplayTime;
    std::array<XrView, 2> views{IdentityView, IdentityView};

    CHECK(
        LocateViews(m_session, m_appSpace, displayTime, static_cast<const std::uint32_t>(views.size()), views.data()));

    auto lo = views[0].pose.orientation;
    auto lp = views[0].pose.position;
    auto lFov = views[0].fov;
    auto ro = views[1].pose.orientation;
    auto rp = views[1].pose.position;
    auto rFov = views[1].fov;
    renderLobbyNative(
        {FfiViewInput{leftSwapchainIdx, FfiOrientation{lo.x, lo.y, lo.z, lo.w}, FfiPosition{lp.x, lp.y, lp.z},
                      lFov.angleLeft, lFov.angleRight, lFov.angleUp, lFov.angleDown},
         FfiViewInput{rightSwapchainIdx, FfiOrientation{ro.x, ro.y, ro.z, ro.w}, FfiPosition{rp.x, rp.y, rp.z},
                      rFov.angleLeft, rFov.angleRight, rFov.angleUp, rFov.angleDown}});

    ReleaseSwapchainImage(swapchains[0].swapchain);
    ReleaseSwapchainImage(swapchains[1].swapchain);

    EndFrame(m_session, m_appSpace, displayTime,
             {{{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW, XR_NULL_HANDLE, views[0].pose, views[0].fov,
                XrSwapchainSubImage{swapchains[0].swapchain, swapchains[0].rect}},
               {XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW, XR_NULL_HANDLE, views[1].pose, views[1].fov,
                XrSwapchainSubImage{swapchains[1].swapchain, swapchains[1].rect}}}});
  }

  void RenderFrame() override {
    CHECK(m_session != XR_NULL_HANDLE);
    std::unique_ptr<wrap::tcr::xr::VideoFrame> frame;
    {
      std::lock_guard<std::mutex> lock(m_VideoFrameMutex);
      frame.swap(m_VideoFrame);
    }
    // 本地刷新帧率比解码帧率要快的时候，我们总会碰到渲染时解码帧未准备好的情况。
    // 这种时候我们跳过未准备好的帧
    if (m_streamReady && !frame) {
      return;
    }
    XrFrameWaitInfo frameWaitInfo{XR_TYPE_FRAME_WAIT_INFO};
    XrFrameState frameState{XR_TYPE_FRAME_STATE};
    CHECK_XRCMD(xrWaitFrame(m_session, &frameWaitInfo, &frameState));

    BeginFrame();

    if (frameState.shouldRender != XR_TRUE) {
      EndEmptyFrame(m_session, frameState.predictedDisplayTime);
      return;
    }
    if (m_streamReady) {
      RenderStreamFrame(frameState, m_streamSwapChains, std::move(frame));
    } else {
      RenderLobbyFrame(frameState, m_lobbySwapChains);
    }
  }

  inline void BeginFrame() {
    XrFrameBeginInfo frameBeginInfo{XR_TYPE_FRAME_BEGIN_INFO};
    // 开始绘制一帧
    CHECK_XRCMD(xrBeginFrame(m_session, &frameBeginInfo));
  }

 private:
  Json::StreamWriterBuilder m_jsonBuilder;
  std::shared_ptr<wrap::tcr::xr::TcrActivity> m_tcrActivity;
  std::shared_ptr<PlatformData> m_platformData;
  XrInstance m_instance{XR_NULL_HANDLE};
  XrSession m_session{XR_NULL_HANDLE};
  XrSpace m_appSpace{XR_NULL_HANDLE};
  XrSystemId m_systemId{XR_NULL_SYSTEM_ID};

  std::vector<XrViewConfigurationView> m_configViews;
  std::vector<XrView> m_views;
  int64_t m_colorSwapchainFormat{GL_SRGB8_ALPHA8};
  ksGpuWindow window{};
  XrGraphicsBindingOpenGLESAndroidKHR m_graphicsBinding{XR_TYPE_GRAPHICS_BINDING_OPENGL_ES_ANDROID_KHR};

  // Application's current lifecycle state according to the runtime
  XrSessionState m_sessionState{XR_SESSION_STATE_UNKNOWN};
  // 用于标记当前会话是否在运行
  std::atomic<bool> m_sessionRunning{false};
  // 用于标记是否开始初始化(该事件是由Java层触发的)
  std::atomic<bool> m_initializationStart{false};
  std::unique_ptr<wrap::tcr::xr::VideoFrame> m_VideoFrame;
  std::mutex m_VideoFrameMutex;

  XrEventDataBuffer m_eventDataBuffer;
  // 用来计算平均总延迟的滑动窗口
  LatencySlidingWindow m_latencyAverage{};
  // 标记云端视频流是否在正常推送.
  // 当视频流在正常推送时，我们会切换到视频帧的渲染模式进行渲染。
  bool m_streamReady;
  // XR_KHR_convert_timespec_time
  PFN_xrConvertTimespecTimeToTimeKHR m_pfnConvertTimespecTimeToTimeKHR = nullptr;

  std::chrono::steady_clock::time_point m_lastUpdateTime = std::chrono::steady_clock::now();
  std::unique_ptr<Tcr::InteractionManager> m_interactionManager{nullptr};

  // XR_FB_color_space
  PFN_xrEnumerateColorSpacesFB m_pfnEnumerateColorSpacesFB = nullptr;
  PFN_xrSetColorSpaceFB m_pfnSetColorSpaceFB = nullptr;
  // 是否开始可以给Java层发送消息
  std::atomic<bool> m_isXrInitNotified{false};

  std::array<SwapchainRect, 2> m_lobbySwapChains{};
  std::array<SwapchainRect, 2> m_streamSwapChains{};
};
}  // namespace

std::shared_ptr<IOpenXrProgram> CreateOpenXrProgram(const std::shared_ptr<PlatformData>& platformData,
                                                    const std::shared_ptr<wrap::tcr::xr::TcrActivity>& tcrActivity) {
  return std::make_shared<OpenXrProgram>(platformData, tcrActivity);
}

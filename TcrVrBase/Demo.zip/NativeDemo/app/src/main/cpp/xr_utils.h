#pragma once
#ifndef TCR_XR_UTILS_H
#  define TCR_XR_UTILS_H

#  include "json/reader.h"
#  include "pch.h"
namespace Tcr {

constexpr inline const XrFovf ZeroFov{0, 0, 0, 0};
constexpr inline bool operator==(const XrFovf& lhs, const XrFovf& rhs) {
  return lhs.angleLeft == rhs.angleLeft && lhs.angleRight == rhs.angleRight && lhs.angleUp == rhs.angleUp &&
         lhs.angleDown == rhs.angleDown;
}

struct EyeInfo {
  XrFovf eyeFov[2];
  float ipd;

  constexpr inline bool empty() const { return eyeFov[0] == ZeroFov && eyeFov[1] == ZeroFov && ipd == 0; }
};

struct XrInitInfo {
  EyeInfo eyeInfo;
  // 原本初始化消息中应该包含profile,
  // 但在我们测试的过程中会有极少数xrSyncActions接口调用后XR_TYPE_EVENT_DATA_INTERACTION_PROFILE_CHANGED事件没有触发的情况,
  // 从而导致我们无法获取profile path.
  // 由于我们在Java层就能够通过android.os.Build判断到运行的设备类型，因此我们在Java层自动填充这个profile path.
  //  std::string profile;
};

namespace Pose {
using float_limits = std::numeric_limits<float>;

constexpr inline const XrPosef Identity{{0, 0, 0, 1}, {0, 0, 0}};
constexpr inline const XrPosef Zero{{0, 0, 0, 0}, {0, 0, 0}};
constexpr inline const XrPosef Infinity{{
                                            float_limits::infinity(),
                                            float_limits::infinity(),
                                            float_limits::infinity(),
                                            float_limits::infinity(),
                                        },
                                        {
                                            float_limits::infinity(),
                                            float_limits::infinity(),
                                            float_limits::infinity(),
                                        }};
}  // namespace Pose

constexpr inline bool operator==(const XrPosef& lhs, const XrPosef& rhs) {
  return lhs.position.x == rhs.position.x && lhs.position.y == rhs.position.y && lhs.position.z == rhs.position.z &&
         lhs.orientation.x == rhs.orientation.x && lhs.orientation.y == rhs.orientation.y &&
         lhs.orientation.z == rhs.orientation.z && lhs.orientation.w == rhs.orientation.w;
}

constexpr inline bool operator!=(const XrPosef& lhs, const XrPosef& rhs) { return !(lhs == rhs); }

struct SpaceLoc {
  XrPosef pose = Pose::Identity;
  XrVector3f linearVelocity = {0, 0, 0};
  XrVector3f angularVelocity = {0, 0, 0};

  constexpr inline bool is_zero() const { return pose == Pose::Zero; }
  constexpr inline bool is_infinity() const { return pose == Pose::Infinity; }
};

constexpr inline const SpaceLoc IdentitySpaceLoc = {Pose::Identity, {0, 0, 0}, {0, 0, 0}};
constexpr inline const SpaceLoc ZeroSpaceLoc = {Pose::Zero, {0, 0, 0}, {0, 0, 0}};
constexpr inline const SpaceLoc InfinitySpaceLoc = {Pose::Infinity, {0, 0, 0}, {0, 0, 0}};

inline SpaceLoc GetSpaceLocation(const XrSpace& targetSpace, const XrSpace& baseSpace, const XrTime& time,
                                 const SpaceLoc& initLoc = IdentitySpaceLoc) {
  XrSpaceVelocity velocity{XR_TYPE_SPACE_VELOCITY, nullptr};
  XrSpaceLocation spaceLocation{XR_TYPE_SPACE_LOCATION, &velocity};
  const auto res = xrLocateSpace(targetSpace, baseSpace, time, &spaceLocation);
  // CHECK_XRRESULT(res, "xrLocateSpace");

  SpaceLoc result = initLoc;
  if (!XR_UNQUALIFIED_SUCCESS(res)) return result;

  const auto& pose = spaceLocation.pose;
  if ((spaceLocation.locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT) != 0) result.pose.position = pose.position;

  if ((spaceLocation.locationFlags & XR_SPACE_LOCATION_ORIENTATION_VALID_BIT) != 0)
    result.pose.orientation = pose.orientation;

  if ((velocity.velocityFlags & XR_SPACE_VELOCITY_LINEAR_VALID_BIT) != 0)
    result.linearVelocity = velocity.linearVelocity;

  if ((velocity.velocityFlags & XR_SPACE_VELOCITY_ANGULAR_VALID_BIT) != 0)
    result.angularVelocity = velocity.angularVelocity;

  return result;
}

inline std::string GetXrVersionString(XrVersion ver) {
  return Fmt("%d.%d.%d", XR_VERSION_MAJOR(ver), XR_VERSION_MINOR(ver), XR_VERSION_PATCH(ver));
}

namespace ColorSpace {
constexpr static auto const to_string = [](const XrColorSpaceFB csType) {
  switch (csType) {
    case XR_COLOR_SPACE_UNMANAGED_FB:
      return "UNMANAGED";
    case XR_COLOR_SPACE_REC2020_FB:
      return "REC2020";
    case XR_COLOR_SPACE_REC709_FB:
      return "REC709";
    case XR_COLOR_SPACE_RIFT_CV1_FB:
      return "RIFT_CV1";
    case XR_COLOR_SPACE_RIFT_S_FB:
      return "RIFT_S";
    case XR_COLOR_SPACE_QUEST_FB:
      return "QUEST";
    case XR_COLOR_SPACE_P3_FB:
      return "P3";
    case XR_COLOR_SPACE_ADOBE_RGB_FB:
      return "ADOBE_RGB";
    case XR_COLOR_SPACE_MAX_ENUM_FB:
      return "MAX_ENUM_FB";
  }
  return "unknown-color-space-type";
};
}  // namespace ColorSpace

inline Json::Value toJson(const XrFovf& xrFov) {
  Json::Value value;
  value["left"] = xrFov.angleLeft;
  value["right"] = xrFov.angleRight;
  value["top"] = xrFov.angleUp;
  value["bottom"] = xrFov.angleDown;
  return value;
}

inline Json::Value toJson(const XrQuaternionf& orientation) {
  Json::Value value;
  value["x"] = orientation.x;
  value["y"] = orientation.y;
  value["z"] = orientation.z;
  value["w"] = orientation.w;
  return value;
}

inline Json::Value toJson(const XrVector3f& position) {
  Json::Value value;
  value["x"] = position.x;
  value["y"] = position.y;
  value["z"] = position.z;
  return value;
}

inline Json::Value toJson(const XrPosef& xrPose) {
  Json::Value pose;
  pose["orientation"] = toJson(xrPose.orientation);
  pose["position"] = toJson(xrPose.position);
  return pose;
}

inline Json::Value toJson(const XrFovf& xrFov, const XrPosef& xrPose) {
  Json::Value view;
  view["fov"] = toJson(xrFov);
  Json::Value pose;
  pose["orientation"] = toJson(xrPose.orientation);
  pose["position"] = toJson(xrPose.position);
  view["pose"] = pose;
  return view;
}

inline Json::Value toJson(const Tcr::EyeInfo& newEyeInfo) {
  Json::Value eyeInfo;
  eyeInfo["leftFov"] = Tcr::toJson(newEyeInfo.eyeFov[0]);
  eyeInfo["rightFov"] = Tcr::toJson(newEyeInfo.eyeFov[1]);
  eyeInfo["ipd"] = newEyeInfo.ipd;
  return eyeInfo;
}

inline Json::Value toJson(const Tcr::XrInitInfo& info) {
  Json::Value value;
  value["eyeInfo"] = toJson(info.eyeInfo);
  return value;
}

inline Json::Value toJson(const std::array<XrView, 2>& views, const int64_t& targetTimestamp) {
  Json::Value left;
  left["pose"] = toJson(views[0].pose);
  left["fov"] = toJson(views[0].fov);
  Json::Value right;
  right["pose"] = toJson(views[1].pose);
  right["fov"] = toJson(views[1].fov);
  Json::Value value;
  value["left"] = left;
  value["right"] = right;
  value["targetTimestamp"] = targetTimestamp;
  return value;
}

inline bool fromJson(std::array<XrView, 2>& views, int64_t& targetTimestamp, const std::string& json) {
  Json::Reader reader;
  Json::Value value;
  if (!reader.parse(json, value)) {
    LogW("fromJson() parse value failed json:%s ", json.c_str());
    return false;
  }
  auto& lp = views[0].pose;
  lp.orientation.x = value["left"]["pose"]["orientation"]["x"].asFloat();
  lp.orientation.y = value["left"]["pose"]["orientation"]["y"].asFloat();
  lp.orientation.z = value["left"]["pose"]["orientation"]["z"].asFloat();
  lp.orientation.w = value["left"]["pose"]["orientation"]["w"].asFloat();
  lp.position.x = value["left"]["pose"]["position"]["x"].asFloat();
  lp.position.y = value["left"]["pose"]["position"]["y"].asFloat();
  lp.position.z = value["left"]["pose"]["position"]["z"].asFloat();
  auto& rp = views[1].pose;
  rp.orientation.x = value["right"]["pose"]["orientation"]["x"].asFloat();
  rp.orientation.y = value["right"]["pose"]["orientation"]["y"].asFloat();
  rp.orientation.z = value["right"]["pose"]["orientation"]["z"].asFloat();
  rp.orientation.w = value["right"]["pose"]["orientation"]["w"].asFloat();
  rp.position.x = value["right"]["pose"]["position"]["x"].asFloat();
  rp.position.y = value["right"]["pose"]["position"]["y"].asFloat();
  rp.position.z = value["right"]["pose"]["position"]["z"].asFloat();
  auto& lf = views[0].fov;
  lf.angleLeft = value["left"]["fov"]["left"].asFloat();
  lf.angleRight = value["left"]["fov"]["right"].asFloat();
  lf.angleUp = value["left"]["fov"]["top"].asFloat();
  lf.angleDown = value["left"]["fov"]["bottom"].asFloat();
  auto& rf = views[1].fov;
  rf.angleLeft = value["right"]["fov"]["left"].asFloat();
  rf.angleRight = value["right"]["fov"]["right"].asFloat();
  rf.angleUp = value["right"]["fov"]["top"].asFloat();
  rf.angleDown = value["right"]["fov"]["bottom"].asFloat();
  targetTimestamp = value["targetTimestamp"].asInt64();
  return true;
}

}  // namespace Tcr
#endif  // TCR_XR_UTILS_H

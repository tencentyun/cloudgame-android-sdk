目前我们针对不同的Build Variant使用不同的OpenXR Loader，这里对不同的OpenXR Loader进行说明:
1.oculus版openxr-loader:
描述:从oculus官网下载的openxr loader。
下载地址: https://developer.oculus.com/downloads/package/oculus-openxr-mobile-sdk
版本:ovr_openxr_mobile_sdk_42.0


2.pico版openxr-loader
描述:从pico官网下载的openxr loader。
下载地址:https://developer-global.pico-interactive.com/sdk?deviceId=1&platformId=3&itemId=11
版本:Pico_OpenXR_SDK_v210
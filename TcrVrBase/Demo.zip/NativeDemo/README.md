# 描述: Demo工程说明

# 简介: 本工程用于演示如何使用TcrXrSdk与云端VR实例进行交互。

# 演示功能:
本工程演示了如何使用TcrXrSdk，演示的内容包括以下

## 初始化流程:
 - 创建TcrXrConfig: 客户端先初始化XR Runtime并获得左右眼的瞳距和FOV，之后通过`TcrXrConfig.Builder`创建一个`TcrXrConfig`.
 - 初始化TcrXr: 调用`TcrXrSdk.getInstance().init()`进行初始化。初始化成功后`TcrXrObserver.onEvent(Event, Object)`接口会回调`Event.STATE_INITED`事件, 事件关联的eventData是一个ClientSession字符串。
 - 启动: 通过ClientSession请求云API后能够拿到ServerSession, 客户端调用`TcrXrSdk.getInstance().start()`连接云端实例。

## 云端事件交互
 - 获取VR事件: 该工程演示了如何通过OpenXR接口获得VR头盔的位姿、瞳距、手柄事件等信息
 - 发送VR事件: 客户端`TcrXrSdk.getInstance().sendVrInfo()`接口给云端发送VR事件

## 渲染视频帧
 - 获取视频帧: 客户端通过监听`TcrXrObserver.onEvent(Event, Object)`接口的`Event.ON_FRAME`事件获得视频帧`VideoFrame`
 - 渲染视频帧: 该工程在`openxr_programe.cpp::RenderStreamFrame()`中演示了如何处理VideoFrame, 并在graphics.cpp中演示了如何通过OpenGL渲染视频帧的纹理。

# 技术实现：

## OpenGL
TcrXrSdk内部使用OpenGL作为渲染引擎，因此暴露给客户端的视频画面是OpenGL的纹理Texture2D，客户端需要了解如何使用OpenGL进行渲染。
本工程亦演示了如何使用OpenGL进行绘制。渲染的主要实现在graphics目录，该目录代码来自开源项目(ALVR)[https://github.com/alvr-org/ALVR]。

## OpenXR API

用TcrXrSdk的客户端需要通过VR头盔获取姿态、手柄控制数据等信息，并将TcrXrSdk输出的画面渲染到VR头盔上。
为了能够和VR头盔进行交互，客户端必须能够和VR Runtime进行交互。(如果您使用游戏引擎开发客户端程序那么游戏引擎会提供相应的访问接口)
作为演示，本工程使用OpenXR API与VR头盔进行交互，实现了对VR头盔的控制和渲染。
OpenXR是由Khronos Group开发的一个跨平台、开放式的VR和AR应用程序标准接口，它使得VR和AR应用程序可以在不同的设备和平台上运行。
在阅读本工程代码时，您需要对OpenXR API的使用有所了解。
本工程参考了OpenXR官方的Demo (hello_xr)[https://github.com/KhronosGroup/OpenXR-SDK-Source/tree/main/src/tests/hello_xr]，使用OpenXR API提供的一些基本功能，如手柄输入、头部追踪、渲染等。

## android_native_app_glue
本工程使用了Android NDK的android_native_app_glue库。
android_native_app_glue是Android NDK提供的一个库，它的作用是将Android的原生应用程序与Android系统框架进行连接，提供了一些方便的接口和工具，帮助开发者更好地编写和调试Android原生应用程序。
请参考Android官方文档了解(android-native-app-glue)[https://developer.android.com/reference/games/game-activity/group/android-native-app-glue]。

# 工程目录以及核心文件说明
以下是工程中重要的目录和文件

├── LICENSE		该项目的协议说明
├── README.md   本文件
├── app
│             ├── openxr-loader	  	不同Runtime支持的OpenXR Loader
│             └── src
│                 └── main
│                     ├── assets	该工程本地3D场景的渲染资源, 包含buffer.bin和loading.gltf两个文件
│                     ├── cpp
│                     │             ├── graphics                渲染模块, 包括启动时本地画面的渲染以及视频画面的渲染
│                     │             ├── interaction_manager.h   OpenXR的交互事件管理类
│                     │             ├── jni_wrap                JNI层到Java层的映射类定义
│                     │             ├── jnipp                   开源JNIPP项目
│                     │             ├── jsoncpp                 开源JSON库
│                     │             ├── main.cpp                程序主入口
│                     │             ├── openxr_program.cpp      OpenXR程序主逻辑
│                     ├── java
│                     │             └── com
│                     │                 └── tencent
│                     │                     └── tcr
│                     │                         ├── demo
│                     │                         │             └── gameplay
│                     │                         │                 ├── CloudGameApi.java    云渲染体验后台交互接口
│                     │                         │                 ├── XrActivity.java      和Native层以及SDK交互的Activity

package com.tencent.simplemobliedemo.server;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.tencent.simplemobliedemo.server.gson.RequestGameStart;
import com.tencent.simplemobliedemo.server.gson.RequestGameStop;
import com.tencent.simplemobliedemo.server.gson.RequestParam;
import com.tencent.tcr.TLog;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * 该类用于请求业务后台接口。<br>
 *
 * 其中使用到的参数仅为演示，客户可以根据实际需求实现自己的业务后台。
 */
public class CloudGameApi {
    private final static String TAG = "CloudGameApi";

    /**
     * 云游后台游戏ID，该ID对应云游后台部署的游戏。<br>
     * 可以联系云游团队接口人部署自己的游戏。
     */
    public static final String GAME_ID = "game-fvokabtq";

    /**
     * 网络请求库Volley提供的{@link RequestQueue}，我们通过它发起网络请求
     */
    private RequestQueue mQueue;

    /**
     * 用户ID。请求业务后台的参数之一。
     *
     */
    private String mUserID;

    public void setContext(Context context){
        mQueue = Volley.newRequestQueue(context);
        mUserID = getIdentity(context);
    }

    /**
     * 通过自定义全局唯一 ID (GUID) 对应用实例进行唯一标识
     * 参考Google唯一标识符最佳做法：https://developer.android.com/training/articles/user-data-ids?hl=zh-cn
     * 卸载之后UserId会发生更改
     */
    public static String getIdentity(Context context) {
        SharedPreferences preference = PreferenceManager.getDefaultSharedPreferences(context);
        String identity = preference.getString("identity", null);
        if (identity == null) {
            identity = UUID.randomUUID().toString();
            SharedPreferences.Editor editor = preference.edit();
            editor.putString("identity", identity);
            editor.apply();
        }
        return identity;
    }

    private static JsonObjectRequest createRequest(String requestAddress, RequestParam param,
            Listener<JSONObject> listener, ErrorListener errorListener) {
        TLog.i(TAG, "createRequest url " + requestAddress);
        TLog.i(TAG, "createRequest " + param);
        JSONObject requestJson = null;
        try {
            requestJson = new JSONObject(new Gson().toJson(param));
        } catch (JSONException e) {
            TLog.e(TAG, "Create request error " + e.getMessage());
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                requestAddress, requestJson, listener, errorListener);
        request.setRetryPolicy(new DefaultRetryPolicy(50000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        return request;
    }


    /**
     * 开始请求业务后台，获取云端游戏实例
     * 该接口调用成功后, 云端会锁定机器实例, 并返回相应的server session
     *
     * @param clientSession sdk初始化成功后返回的client session
     * @param listener 服务端返回结果
     */
    public void startGame(String clientSession, Listener<JSONObject> listener, ErrorListener errorListener) {
        // 业务后台接口: 启动游戏
        final String START_GAME_URL = "https://microcg.myqcloud.com/StartGame";

        RequestParam param = new RequestGameStart(mUserID, GAME_ID, clientSession, 30, 1, 5);
        JsonObjectRequest request = createRequest(START_GAME_URL, param, listener, errorListener);
        mQueue.add(request);
    }

    /**
     * 请求业务后台，停止游戏(释放云端实例)
     */
    public void stopGame(Listener<JSONObject> listener, ErrorListener errorListener) {
        // 业务后台接口: 停止游戏。这会让云端关闭游戏实例。
        final String STOP_GAME_URL = "https://microcg.myqcloud.com/StopGame";
        RequestParam param = new RequestGameStop(mUserID);
        JsonObjectRequest request = createRequest(STOP_GAME_URL, param, listener, errorListener);
        mQueue.add(request);
    }


    private static final class Holder {
        private static final CloudGameApi INSTANCE = new CloudGameApi();
    }

    public static CloudGameApi getInstance() {
        return Holder.INSTANCE;
    }

}

package com.tencent.simplemobliedemo;

import android.app.Application;
import android.util.Log;
import com.tencent.simplemobliedemo.server.CloudGameApi;
import com.tencent.tcr.TLog;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.TcrSdk;

/**
 * APP 入口，SDK初始化可以在游戏activity启动之前完成
 */
public class App extends Application {

    private static final String TAG = "App";
    @Override
    public void onCreate() {
        super.onCreate();
        CloudGameApi.getInstance().setContext(this);
        TcrSdk.getInstance().init(this, null, new AsyncCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                TLog.i(TAG,"init SDK success");
            }
            @Override
            public void onFailure(int code, String msg) {
                // 当出现这种情况时，无法使用SDK，只能退出处理。
                Log.i(TAG, "init SDK failed:" + code + " msg:" + msg);
            }
        });
    }
}

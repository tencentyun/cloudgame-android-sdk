package com.tencent.simplelightdemo.server.gson;

import com.google.gson.annotations.SerializedName;
import com.tencent.simplelightdemo.Constant;
import com.tencent.simplelightdemo.utils.CommonUtil;

/**
 * 该类封装了开始游戏所需要的参数
 * 客户端需要根据实际需求自定义业务后台的请求参数
 * 业务后台API文档：https://cloud.tencent.com/document/product/1162/40740
 */
public class GameStartParam extends RequestParam{

    @SerializedName("GameId")
    public String gameId;
    @SerializedName("ClientSession")
    public String clientSession;
    @SerializedName("Sign")
    public String sign;

    @SerializedName("MaxBitrate")
    public int maxBitrate;              //可选，单位Mbps，动态调整最大码率
    @SerializedName("MinBitrate")
    public int minBitrate;             //可选，单位Mbps，动态调整最小码率
    @SerializedName("Fps")
    public int fps;


    public GameStartParam(String userId, String gameId, String clientSession, int fps, int minBitrate, int maxBitrate) {
        super(userId);
        this.clientSession = clientSession;
        this.gameId = gameId;
        this.fps = fps;
        this.minBitrate = minBitrate;
        this.maxBitrate = maxBitrate;
        this.sign = getSignature();
    }

    private String getSignature() {
        return CommonUtil.getSHA256(clientSession + fps + gameId + maxBitrate + minBitrate
                + requestId + timeStamp + userId + Constant.SOLT);
    }

    @Override
    public String toString() {
        return "StartGameRequestParam{" +
                "gameId='" + gameId + '\'' +
                ", sign='" + sign + '\'' +
                ", maxBitrate=" + maxBitrate +
                ", minBitrate=" + minBitrate +
                ", fps=" + fps +
                ", requestId='" + requestId + '\'' +
                ", userId='" + userId + '\'' +
                ", timeStamp=" + timeStamp +
                '}';
    }

}

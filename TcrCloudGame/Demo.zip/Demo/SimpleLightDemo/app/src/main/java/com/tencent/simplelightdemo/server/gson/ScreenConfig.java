package com.tencent.simplelightdemo.server.gson;

import com.google.gson.annotations.SerializedName;

public class ScreenConfig {

    @SerializedName("orientation")
    public String orientation;

    @SerializedName("width")
    public int width;

    @SerializedName("height")
    public int height;
}

package com.tencent.simplelightdemo;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import com.tencent.component.utils.ToastUtils;
import com.tencent.simplelightdemo.server.CloudGameApi;
import com.tencent.simplelightdemo.utils.DownloadManagerHelper;
import com.tencent.tcr.TLog;
import com.tencent.tcr.internal.util.ThreadUtils;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.TcrSdk;
import java.io.File;

/**
 * 该类作为APP入口。演示了如何通过网络下载云游SDK插件和初始化SDK。
 */
public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";

    // 初始化SDK按钮
    private Button initButton;
    // 启动云游按钮
    private Button startButton ;

    // 初始化SDK回调
    private final AsyncCallback<Void> mInitSdkCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            Log.i(TAG,"init SDK success");
            startButton.setEnabled(true);
        }
        @Override
        public void onFailure(int code, String msg) {
            Log.e(TAG, "init SDK failed:" + code + " msg:" + msg);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initButton = this.findViewById(R.id.initSDK);
        startButton = this.findViewById(R.id.startGame);
        // 初始化和业务后台交互的类
        CloudGameApi.getInstance().init(this);

        initButton.setOnClickListener(v -> {
            // 下载插件并初始化云游SDK
            initSDKPlugin();
        });

        startButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,GameActivity.class);
            startActivity(intent);
        });
    }

    /**
     * 下载SDK插件，下载完成后初始化SDK
     */
    private void initSDKPlugin() {
        Context mContext = getApplicationContext();
        File dest = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                "plugin");
        if (dest.exists()){
            TcrSdk.getInstance().init(mContext,
                    dest.getAbsolutePath(),
                    mInitSdkCallback);
            Toast.makeText(mContext,"插件已存在,开始初始化SDK",Toast.LENGTH_SHORT).show();
        }else {
            DownloadManagerHelper.getInstance().setContext(this);
            Toast.makeText(mContext,"下载插件中...",Toast.LENGTH_SHORT).show();
            DownloadManagerHelper.getInstance().download("下载插件",
                    "使用轻量版SDK",
                    TcrSdk.getPluginUrl(),
                    dest,
                    new DownloadManagerHelper.Listener() {
                        @Override
                        public void onStatusChange(int status) {
                            Log.d(TAG, "onStatusChange:" + status);
                            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                Log.i(TAG,"download plugin successful");
                                Toast.makeText(mContext,"插件下载成功，初始化SDK",Toast.LENGTH_SHORT).show();
                                TcrSdk.getInstance().init(mContext,
                                        dest.getAbsolutePath(),
                                        mInitSdkCallback);
                            }
                        }
                        @Override
                        public void onFailed(String msg) {
                            Log.e(TAG,"download plugin failed : "+msg);
                        }
                    });
        }

    }
}

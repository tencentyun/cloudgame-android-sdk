package com.tencent.simplelightdemo;

import android.app.Activity;
import android.app.Application;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import androidx.annotation.Nullable;
import com.tencent.simplelightdemo.server.CloudGameApi;
import com.tencent.simplelightdemo.utils.DownloadManagerHelper;
import com.tencent.tcr.TLog;
import com.tencent.tcr.internal.util.ThreadUtils;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.TcrSdk;
import java.io.File;

/**
 * APP 入口，SDK初始化可以在游戏activity启动之前完成
 */
public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";

    private final AsyncCallback<Void> mInitSdkCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            TLog.i(TAG,"init SDK success");
            Intent intent = new Intent(MainActivity.this,LightDemoActivity.class);
            startActivity(intent);
        }
        @Override
        public void onFailure(int code, String msg) {
            // 当出现这种情况时，无法使用SDK，只能退出处理。
            Log.i(TAG, "init SDK failed:" + code + " msg:" + msg);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CloudGameApi.getInstance().setContext(this);
        initSDKPlugin();
    }

    /**
     * 下载SDK插件，成功后初始化SDK
     */
    private void initSDKPlugin() {
        File dest = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                "plugin");
        TLog.d(TAG, "plugin path:" + dest.getAbsolutePath());
        DownloadManagerHelper.getInstance().setContext(this);
        Context mContext = getApplicationContext();
        DownloadManagerHelper.getInstance().setContext(this);
        ThreadUtils.runOnMainThread(() -> DownloadManagerHelper.getInstance().download("下载插件",
                "使用轻量版SDK",
                TcrSdk.getPluginUrl(),
                dest,
                new DownloadManagerHelper.Listener() {
                    @Override
                    public void onStatusChange(int status) {
                        TLog.d(TAG, "onStatusChange:" + status);
                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            TLog.d(TAG,"download plugin successful");
                            ThreadUtils.runOnMainThread(() -> TcrSdk.getInstance().init(mContext,
                                    dest.getAbsolutePath(),
                                    mInitSdkCallback));
                        }
                    }
                    @Override
                    public void onFailed(String msg) {
                        TLog.d(TAG,"download plugin failed : "+msg);
                    }
                }));

    }
}

package com.tencent.simplelightdemo;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import com.tencent.component.utils.ToastUtils;
import com.tencent.simplelightdemo.server.CloudGameApi;
import com.tencent.simplelightdemo.server.gson.GameStartResponse;
import com.tencent.simplelightdemo.server.gson.ServerResponse;
import com.tencent.simplelightdemo.utils.DownloadManagerHelper;
import com.tencent.tcr.TLog;
import com.tencent.tcr.internal.util.ThreadUtils;
import com.tencent.tcr.sdk.api.AsyncCallback;
import com.tencent.tcr.sdk.api.MobileTouchHandler;
import com.tencent.tcr.sdk.api.PcTouchHandler;
import com.tencent.tcr.sdk.api.TcrRenderView;
import com.tencent.tcr.sdk.api.TcrRenderViewType;
import com.tencent.tcr.sdk.api.TcrSdk;
import com.tencent.tcr.sdk.api.TcrSession;
import com.tencent.tcr.sdk.api.TcrSessionListener;
import com.tencent.tcr.sdk.api.config.TcrSessionConfig;
import java.io.File;

public class LightDemoActivity extends Activity {
    private static final String TAG = "LightDemoActivity";
    Context mContext;
    /**
     * 请求云游API失败
     **/
    public static final int ERROR_CODE_CALL_CLOUD_GAME_API_FAILED = -1;
    /**
     * 网络异常
     **/
    public static final int ERROR_NETWORK_ERROR = -2;
    /**
     * 启动会话失败
     **/
    public static final int ERROR_START_SESSION_FAILED = -3;
    private AsyncCallback<String> mSdkCallback;
    // 渲染实现
    private TcrRenderView mTcrRenderViewImpl;
    // 业务后台交互的API
    private CloudGameApi mCloudGameApi;
    // 会话
    private TcrSession mTcrSession;
    // 启动会话回调，成功后开始设置游戏画面
    private final AsyncCallback<Void> mStartSessionCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            TLog.d(TAG, "mStartSessionCallback onSuccess.");
            mSdkCallback.onSuccess("success");
        }

        @Override
        public void onFailure(int code, String msg) {
            TLog.d(TAG, "mStartSessionCallback onFailure code:" + code + " msg:" + msg);
            mSdkCallback.onFailure(ERROR_START_SESSION_FAILED, "code:" + code + " msg:" + msg);
        }
    };

    // 初始化会话回调，回调中会返回的clientSession需要给到后台
    private final AsyncCallback<String> mInitSessionCallback = new AsyncCallback<String>() {
        @Override
        public void onSuccess(String clientSession) {
            ToastUtils.show(LightDemoActivity.this, "初始化会话成功");
            TLog.d(TAG, "CreateSessionCallback:" + clientSession);
            // 拿客户端的clientSession去交互服务端的ServerSession
            mCloudGameApi
                    .startGame(Constant.PC_GAME_ID,clientSession, new CloudGameApi.IServerSessionListener() {
                        @Override
                        public void onSuccess(ServerResponse resp) {
                            ToastUtils.show(LightDemoActivity.this, resp.toString());
                            GameStartResponse response = (GameStartResponse) resp;
                            TLog.d(TAG, "onSuccess: " + response.toString());
                            // 请求成功，获取服务端的server session，启动游戏
                            if (response.code==0) {
                                mTcrSession.start(response.sessionDescribe.serverSession, mStartSessionCallback);
                            } else {
                                mSdkCallback.onFailure(ERROR_CODE_CALL_CLOUD_GAME_API_FAILED,response.toString());
                            }
                        }
                        @Override
                        public void onFailed(String msg) {
                            TLog.i(TAG, msg);
                            mSdkCallback.onFailure(ERROR_NETWORK_ERROR, msg);
                        }
                    });
        }
        @Override
        public void onFailure(int code, String msg) {
            TLog.d(TAG, "onFailure code:" + code + " msg:" + msg);
        }
    };

    // 初始化SDK回调
    private final AsyncCallback<Void> mInitSdkCallback = new AsyncCallback<Void>() {
        @Override
        public void onSuccess(Void result) {
            ToastUtils.show(LightDemoActivity.this, "初始化SDK成功");
            mTcrSession = TcrSdk.getInstance().createTcrSession(createSessionConfig());
            mTcrRenderViewImpl = TcrSdk.getInstance().createTcrRenderView(LightDemoActivity.this, mTcrSession,TcrRenderViewType.SURFACE);
            mTcrSession.init(mInitSessionCallback);
        }
        @Override
        public void onFailure(int code, String msg) {
            TLog.d(TAG, "onLoadFailed code:" + code + " msg:" + msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DownloadManagerHelper.getInstance().setContext(this);
        init();
        setContentView(R.layout.activity_pcgame);
        setGameView();
    }

    private void init() {
        mContext = getApplicationContext();
        // 全屏展示
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // 屏幕常亮
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        mCloudGameApi = new CloudGameApi(mContext);
        initSDKPlugin();
    }

    private void initSDKPlugin() {
        File dest = new File(mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                "plugin");
        TLog.d(TAG, "plugin path:" + dest.getAbsolutePath());
        DownloadManagerHelper.getInstance().download("下载插件",
                "使用轻量版SDK",
                TcrSdk.getPluginUrl(),
                dest,
                new DownloadManagerHelper.Listener() {
                    @Override
                    public void onStatusChange(int status) {
                        TLog.d(TAG, "onStatusChange:" + status);
                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            ThreadUtils.runOnMainThread(new Runnable() {
                                @Override
                                public void run() {
                                    TcrSdk.getInstance().init(mContext,
                                            dest.getAbsolutePath(),
                                            mInitSdkCallback);
                                }
                            });
                        }
                    }
                    @Override
                    public void onFailed(String msg) {
                       TLog.d(TAG,"download plugin failed : "+msg);
                    }
                });
    }

    private void setGameView() {
        mSdkCallback = new AsyncCallback<String>() {
            @Override
            public void onSuccess(String s) {
                mTcrSession.setRenderView(mTcrRenderViewImpl);
                mTcrSession.setListener(new TcrSessionListener() {
                    @Override
                    public void onError(int i, String s) {
                    }

                    @Override
                    public void onEvent(String s, String s1) {

                    }
                });
                // 设置操作模式
                setTouchHandler(mTcrSession,mTcrRenderViewImpl);
                if(mTcrRenderViewImpl.getParent() != null) {
                    ((ViewGroup)mTcrRenderViewImpl.getParent()).removeView(mTcrRenderViewImpl);
                }
                ((FrameLayout) LightDemoActivity.this.findViewById(R.id.main)).addView(mTcrRenderViewImpl);
            }
            @Override
            public void onFailure(int code, String msg) {
                TLog.i(TAG, "onFailure code:" + code + " msg: " + msg);
            }
        };
    }

    /**
     * 为不同的云端实例设置处理器
     * 对于端游要使用{@link com.tencent.tcr.sdk.api.PcTouchHandler}
     * 对于手游要使用{@link com.tencent.tcr.sdk.api.MobileTouchHandler}
     */
    private void setTouchHandler(TcrSession session, TcrRenderView renderView) {
        switch (session.getRemoteDeviceMode()) {
            case ANDROID:
                renderView.setOnTouchListener(new MobileTouchHandler());
                break;
            case PC:
                PcTouchHandler pcTouchHandler = new PcTouchHandler();
                pcTouchHandler.enableScaling(1, 5);
                renderView.setOnTouchListener(pcTouchHandler);
                break;
            default:
                Log.e(TAG,"UNKNOWN DeviceMode!!");
        }
    }

    private TcrSessionConfig createSessionConfig() {
        return TcrSessionConfig.builder()
                .connectTimeout(25000)
                .idleThreshold(30)
                .enableAudioTrack(true).build();
    }
}

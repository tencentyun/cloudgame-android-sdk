package com.tencent.simplepcdemo.server.gson;

import com.google.gson.annotations.SerializedName;
import com.tencent.simplepcdemo.Constant;
import com.tencent.simplepcdemo.utils.CommonUtil;

/**
 * 该类封装了停止游戏所需要的参数
 * 客户端需要根据实际需求自定义业务后台的请求参数
 * 业务后台API文档：https://cloud.tencent.com/document/product/1162/40739
 */
public class GameStopParam extends RequestParam{

    @SerializedName("Sign")
    public String sign;

    public GameStopParam(String userId) {
        super(userId);
        this.sign = getSignature();
    }

    private String getSignature() {
        return CommonUtil.getSHA256(requestId + timeStamp + userId + Constant.SOLT);
    }

    @Override
    public String toString() {
        return "StopGameRequestParam{" +
                "sign='" + sign + '\'' +
                ", requestId='" + requestId + '\'' +
                ", userId='" + userId + '\'' +
                ", timeStamp=" + timeStamp +
                '}';
    }
}
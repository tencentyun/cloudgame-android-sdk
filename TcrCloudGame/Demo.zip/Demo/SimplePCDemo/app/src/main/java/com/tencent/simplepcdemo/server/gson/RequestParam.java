package com.tencent.simplepcdemo.server.gson;

import com.google.gson.annotations.SerializedName;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class RequestParam {
    
    @SerializedName("RequestId")
    public String requestId;
    
    @SerializedName("UserId")
    public String userId;
    
    @SerializedName("TimeStamp")
    public long timeStamp;
    
    public static final String SOLT = "DLaB%$bfAc!@ds";


    public RequestParam(String userId) {
        this.userId = userId;
        this.requestId = getRequestId();
        this.timeStamp = getCurrentTimeStamp();
    }

    private static String getRequestId() {
        return UUID.randomUUID().toString();
    }

    private static long getCurrentTimeStamp() {
        return System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return "RequestParam{" +
                "requestId='" + requestId + '\'' +
                ", userId='" + userId + '\'' +
                ", timeStamp=" + timeStamp +
                '}';
    }

    /**
     * 使用SHA256对文本内容{@code input}进行加密。
     */
    public String getSHA256(String input) {
        MessageDigest messageDigest;
        String encodestr = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(input.getBytes(StandardCharsets.UTF_8));
            encodestr = byte2Hex(messageDigest.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return encodestr;
    }

    /**
     * 将字节流转为16进制字符
     */
    private String byte2Hex(byte[] input) {
        StringBuilder stringBuilder = new StringBuilder();
        String temp;
        for (byte b : input) {
            temp = Integer.toHexString(b & 0xFF);
            if (temp.length() == 1) {
                stringBuilder.append("0");
            }
            stringBuilder.append(temp);
        }
        return stringBuilder.toString();
    }
}

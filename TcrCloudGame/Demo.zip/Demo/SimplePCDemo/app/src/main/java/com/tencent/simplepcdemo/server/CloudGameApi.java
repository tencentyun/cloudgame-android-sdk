package com.tencent.simplepcdemo.server;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.tencent.simplepcdemo.Constant;
import com.tencent.simplepcdemo.server.gson.GameStartResponse;
import com.tencent.simplepcdemo.server.gson.RequestParam;
import com.tencent.tcr.TLog;
import com.tencent.simplepcdemo.server.gson.GameStartParam;
import com.tencent.simplepcdemo.server.gson.GameStopParam;
import com.tencent.simplepcdemo.server.gson.ServerResponse;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * 该类用于请求业务后台
 * 客户端请求业务后台，传入client session获取到server session
 * 客户可以根据实际需求实现自己的业务后台
 * 业务后台的API请参考:
 * https://cloud.tencent.com/document/product/1162/40740
 */
public class CloudGameApi {
    private final static String TAG = "CloudGameApi";

    // 业务后台地址
    public static final String SERVER = Constant.SERVER;
    public static final String START_GAME = "/StartGame";
    public static final String STOP_GAME = "/StopGame";
    public static final int REQUEST_SUCCESS = 0;
    private static final int TIMEOUT = 50000;
    private static final int RETRY_TIMES = 0;
    private final RequestQueue mQueue;
    private static final Gson mGson = new Gson();
    // 标识请求来自哪个用户
    private final String mUserID;

    public CloudGameApi(Context context) {
        mQueue = Volley.newRequestQueue(context);
        mUserID = getIdentity(context);
    }

    private static String address(String path) {
        return "https://" + SERVER + path;
    }

    /**
     * 通过自定义全局唯一 ID (GUID) 对应用实例进行唯一标识
     * 参考Google唯一标识符最佳做法：https://developer.android.com/training/articles/user-data-ids?hl=zh-cn
     * 卸载之后UserId会发生更改
     */
    public String getIdentity(Context context) {
        SharedPreferences preference = PreferenceManager.getDefaultSharedPreferences(context);
        String identity = preference.getString("identity", null);
        if (identity == null) {
            identity = UUID.randomUUID().toString();
            SharedPreferences.Editor editor = preference.edit();
            editor.putString("identity", identity);
            editor.apply();
        }
        return identity;
    }

    private static JsonObjectRequest createRequest(String requestAddress, RequestParam param,
            Listener<JSONObject> listener, ErrorListener errorListener) {
        TLog.i(TAG, "createRequest url " + address(requestAddress));
        TLog.i(TAG, "createRequest " + param);
        JSONObject requestJson = null;
        try {
            requestJson = new JSONObject(mGson.toJson(param));
        } catch (JSONException e) {
            TLog.e(TAG, "Create request error " + e.getMessage());
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                address(requestAddress), requestJson, listener, errorListener);
        request.setRetryPolicy(new DefaultRetryPolicy(TIMEOUT, RETRY_TIMES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        return request;
    }


    /**
     * 开始请求业务后台，获取云端游戏实例
     * 该接口调用成功后, 云端会锁定机器实例, 并返回相应的server session
     *
     * @param gameId 游戏体验码
     * @param clientSession sdk初始化成功后返回的client session
     * @param listener 服务端返回结果
     */
    public void startGame(String gameId, String clientSession, final IServerSessionListener listener) {
        RequestParam param = new GameStartParam(mUserID, gameId, clientSession, 30, 1, 5);
        JsonObjectRequest request = createRequest(START_GAME, param, response -> {
            ServerResponse result = mGson.fromJson(response.toString(), GameStartResponse.class);
            onResultCallback(result, listener);
        }, error -> {
            TLog.e(TAG, "request failed, reason is " + (error == null ? "msg is null" : error.getMessage()));
            listener.onFailed((error == null ? "msg is null" : error.getMessage()));
        });
        mQueue.add(request);
    }

    /**
     * 请求业务后台，停止游戏(释放云端实例)
     */
    public void stopGame(final IServerSessionListener listener) {
        RequestParam param = new GameStopParam(mUserID);
        JsonObjectRequest request = createRequest(STOP_GAME, param, response -> {
            ServerResponse result = new Gson().fromJson(response.toString(),
                    ServerResponse.class);
            onResultCallback(result, listener);
        }, volleyError -> {
            TLog.e(TAG, "error: " + volleyError.getMessage());
        });
    }

    private void onResultCallback(ServerResponse result, IServerSessionListener listener) {
        if (result.code == REQUEST_SUCCESS) {
            TLog.i(TAG, "Response success, result is " + result.toString());
            if (listener != null) {
                listener.onSuccess(result);
            }
        } else {
            TLog.e(TAG, "Response error, reason is " + result.toString());
            if (listener != null) {
                listener.onFailed(result.msg);
            }
        }
    }

    // 业务后台返回结果监听
    public interface IServerSessionListener {

        void onFailed(String msg);

        void onSuccess(ServerResponse resp);
    }
}
